"""Test whether a matching onset tile alone determines the next onset bit."""
from check_rails import step

for word, T, x, radius in [('0000101111',594,256,64), ('001011',884,380,186)]:
    n = 6000
    mask, c = (1<<n)-1, n//2
    b = sum(1<<i for i in range(n) if word[(i-c+5)%len(word)]=='1')
    y = b ^ (1<<c)
    for _ in range(T):
        y = step(y,n,mask)
    tile = ((1<<(2*radius+1))-1) << (c+x-radius)
    def output(s):
        for _ in range(882):
            s = step(s,n,mask)
        return (s >> (c+x+378)) & 1
    actual = output(y)
    for p in range(1,9):
        for k in range(1<<p):
            repeat = ((1 << (p*((n+p-1)//p)))-1)//((1<<p)-1)
            alternative = (y & tile) | ((k*repeat) & mask & ~tile)
            if output(alternative) != actual:
                print(word, 'T', T, 'radius', radius, 'exterior_lsb_first',
                      format(k,f'0{p}b')[::-1], 'actual', actual, 'alternative',1-actual)
                break
        else:
            continue
        break
    else:
        raise RuntimeError('no counterexample among tested completions')
