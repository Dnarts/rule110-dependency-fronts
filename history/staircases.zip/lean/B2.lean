import BMedia
namespace Rails
open Rule110Complete Rule110Fin1320Bridge Rule110LocalWindow
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option exponentiation.threshold 16384
def B2tab : Array Nat := #[
0x7647d9,
0x1f647d,
0x48fb23]
def B2 (t : Nat) (x : Int) := if x-(t:Int)*(2)/3<(1154) then Bm2 t x else if (1176)<x-(t:Int)*(2)/3 then Bm0 t x else cell B2tab[t%3]! (x-(t:Int)*(2)/3-(1154))
theorem B2ret (t : Nat) (x : Int) : B2 (t+3) (x+(2)) = B2 t x := by
  unfold B2
  simp only [show x+(2)-((↑(t+3):Int)*(2)/3) = x-((t:Int)*(2)/3) by omega, show (t+3)%3=t%3 by omega, Bm2ret3, Bm0ret3]
private theorem B2check0 : ∀ r : Fin 3, ∀ j : Fin 27, let y := (1152:Int)+j.val+((r.val+0):Int)*(2)/3; step (B2 (r.val+0)) y = B2 ((r.val+0)+1) y := by decide
theorem B2step : ∀ t x, step (B2 t) x = B2 (t+1) x := by
  apply propagate _ 3 (2) (by decide) B2ret
  intro t ht x
  let z := x - (t:Int)*(2)/3
  by_cases hl : z < (1154)-2
  · have h (j : Int) (hj : x-1≤j ∧ j≤x+1) : B2 t j = Bm2 t j := by
      simp only [B2,ite_true,ite_false,show j-(t:Int)*(2)/3<(1154) by dsimp [z] at hl; omega]
    rw [show step (B2 t) x = step (Bm2 t) x by unfold step; rw [h _ (by omega),h _ (by omega),h _ (by omega)], Bm2step]
    simp only [B2,ite_true,ite_false,show x-(↑(t+1):Int)*(2)/3<(1154) by dsimp [z] at hl; omega]
  by_cases hr : (1176)+2 < z
  · have h (j : Int) (hj : x-1≤j ∧ j≤x+1) : B2 t j = Bm0 t j := by
      have hh : (1176)<j-(t:Int)*(2)/3 := by dsimp [z] at hr; omega
      simp only [B2,ite_true,ite_false,hh,show ¬ j-(t:Int)*(2)/3<(1154) by omega]
    rw [show step (B2 t) x = step (Bm0 t) x by unfold step; rw [h _ (by omega),h _ (by omega),h _ (by omega)], Bm0step]
    have hh : (1176)<x-(↑(t+1):Int)*(2)/3 := by dsimp [z] at hr; omega
    simp only [B2,ite_true,ite_false,hh,show ¬ x-(↑(t+1):Int)*(2)/3<(1154) by omega]
  let k : Fin 27 := ⟨(z-(1152)).toNat, by omega⟩
  have tab : ∀ r : Fin 3, ∀ j : Fin 27, let y := (1152:Int)+j.val+(r.val:Int)*(2)/3; step (B2 r.val) y = B2 (r.val+1) y := by
    intro r j
    have h0 := B2check0 ⟨r.val-0, by omega⟩ j
    simpa only [show r.val-0+0=r.val by omega, show ((r.val-0:Nat):Int)+0=(r.val:Int) by omega] using h0
  have h := tab ⟨t,ht⟩ k
  dsimp only at h
  rwa [show (1152:Int)+(k.val:Int)+(t:Int)*(2)/3=x by dsimp [k,z]; omega] at h

end Rails
