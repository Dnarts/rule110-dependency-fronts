import StaircaseA
import StaircaseB
#check Rails.staircaseA
#print axioms Rails.staircaseA
#check Rails.staircaseB
#print axioms Rails.staircaseB
