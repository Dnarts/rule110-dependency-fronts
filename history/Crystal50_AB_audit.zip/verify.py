from pathlib import Path
from collections import deque
cases=Path('cases.txt').read_text().splitlines()
results=Path('exact.txt').read_text().splitlines()
assert len(cases)==len(results)==1948
def transition(c,s,w,r):
    row=[(c>>k)&1 for k in range(4)]+[(s>>k)&1 for k in range(w)]+[r]
    for _ in range(2):
        row=[(b|r)^(l&b&r) for l,b,r in zip(row,row[1:],row[2:])]
    return row[0]==(c>>4),sum(v<<i for i,v in enumerate(row[1:]))
for case,result in zip(cases,results):
    p,x,w,s,*ctx=map(int,case.split())
    pp,xx,ww,status,size,*tail=result.split()
    assert (p,x,w)==tuple(map(int,(pp,xx,ww)))
    if status=='FAIL':
        path,=tail
        for j,ch in enumerate(path):
            ok,s=transition(ctx[j%50],s,w,int(ch))
            assert ok==(j<len(path)-1)
    elif (x,w)==(-350,16):
        seen={(0,s)};q=deque(seen)
        while q:
            j,v=q.popleft()
            for r in (0,1):
                ok,new=transition(ctx[j],v,w,r)
                assert ok
                node=((j+1)%50,new)
                if node not in seen:
                    seen.add(node);q.append(node)
        assert len(seen)==int(size)==5854
        print('Verified closed',p,len(seen),2*len(seen))
