import Base
namespace Rails
open Rule110Complete Rule110Fin1320Bridge Rule110LocalWindow
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option exponentiation.threshold 16384
def Am0tab : Array Nat := #[
0x377,
0x1dc,
0x176,
0x1df,
0x371,
0x1d9,
0x37d,
0x1c7,
0x365,
0x1f7,
0x31d,
0x197,
0x3dd,
0x77,
0x25d]
def Am0 (t : Nat) (x : Int) := cell (Am0tab[t%15]!) (x%10)
theorem Am0step (t : Nat) (x : Int) : step (Am0 t) x = Am0 (t+1) x := by
  have tab : ∀ i : Fin 15, ∀ j : Fin 10, (let t := i.val; let x : Int := j.val; step (Am0 t) x = Am0 (t+1) x) := by decide
  let i : Fin 15 := ⟨t%15,by omega⟩
  let j : Fin 10 := ⟨(x%10).toNat,by omega⟩
  have h := tab i j
  dsimp only at h
  simp only [Am0, step] at h ⊢
  dsimp only [i,j] at h
  simpa only [show ((x%10).toNat:Int) = x%10 by omega, show (x%10)%10=(x)%10 by omega, show (x%10-1)%10=(x-1)%10 by omega, show (x%10+1)%10=(x+1)%10 by omega, show (x%10+(0))%10=(x+(0))%10 by omega, show (t%15)%15=(t)%15 by omega, show (t%15+1)%15=(t+1)%15 by omega] using h
theorem Am0ret273 (t : Nat) (x : Int) : Am0 (t+273) (x+(-28)) = Am0 t x := by
  have tab : ∀ i : Fin 15, ∀ j : Fin 10, (let t := i.val; let x : Int := j.val; Am0 (t+273) (x+(-28)) = Am0 t x) := by decide
  let i : Fin 15 := ⟨t%15,by omega⟩
  let j : Fin 10 := ⟨(x%10).toNat,by omega⟩
  have h := tab i j
  dsimp only at h
  simp only [Am0, step] at h ⊢
  dsimp only [i,j] at h
  simpa only [show ((x%10).toNat:Int) = x%10 by omega, show (x%10)%10=(x)%10 by omega, show (x%10-1)%10=(x-1)%10 by omega, show (x%10+1)%10=(x+1)%10 by omega, show (x%10+(-28))%10=(x+(-28))%10 by omega, show (t%15)%15=(t)%15 by omega, show (t%15+273)%15=(t+273)%15 by omega] using h
theorem Am0ret3 (t : Nat) (x : Int) : Am0 (t+3) (x+(2)) = Am0 t x := by
  have tab : ∀ i : Fin 15, ∀ j : Fin 10, (let t := i.val; let x : Int := j.val; Am0 (t+3) (x+(2)) = Am0 t x) := by decide
  let i : Fin 15 := ⟨t%15,by omega⟩
  let j : Fin 10 := ⟨(x%10).toNat,by omega⟩
  have h := tab i j
  dsimp only at h
  simp only [Am0, step] at h ⊢
  dsimp only [i,j] at h
  simpa only [show ((x%10).toNat:Int) = x%10 by omega, show (x%10)%10=(x)%10 by omega, show (x%10-1)%10=(x-1)%10 by omega, show (x%10+1)%10=(x+1)%10 by omega, show (x%10+(2))%10=(x+(2))%10 by omega, show (t%15)%15=(t)%15 by omega, show (t%15+3)%15=(t+3)%15 by omega] using h
theorem Am0ret882 (t : Nat) (x : Int) : Am0 (t+882) (x+(378)) = Am0 t x := by
  have tab : ∀ i : Fin 15, ∀ j : Fin 10, (let t := i.val; let x : Int := j.val; Am0 (t+882) (x+(378)) = Am0 t x) := by decide
  let i : Fin 15 := ⟨t%15,by omega⟩
  let j : Fin 10 := ⟨(x%10).toNat,by omega⟩
  have h := tab i j
  dsimp only at h
  simp only [Am0, step] at h ⊢
  dsimp only [i,j] at h
  simpa only [show ((x%10).toNat:Int) = x%10 by omega, show (x%10)%10=(x)%10 by omega, show (x%10-1)%10=(x-1)%10 by omega, show (x%10+1)%10=(x+1)%10 by omega, show (x%10+(378))%10=(x+(378))%10 by omega, show (t%15)%15=(t)%15 by omega, show (t%15+882)%15=(t+882)%15 by omega] using h
def Am1tab : Array Nat := #[
0x3ec8,
0x23ec,
0x323e,
0x3b23,
0xfb2,
0x8fb,
0x2c8f]
def Am1 (t : Nat) (x : Int) := cell (Am1tab[t%7]!) (x%14)
theorem Am1step (t : Nat) (x : Int) : step (Am1 t) x = Am1 (t+1) x := by
  have tab : ∀ i : Fin 7, ∀ j : Fin 14, (let t := i.val; let x : Int := j.val; step (Am1 t) x = Am1 (t+1) x) := by decide
  let i : Fin 7 := ⟨t%7,by omega⟩
  let j : Fin 14 := ⟨(x%14).toNat,by omega⟩
  have h := tab i j
  dsimp only at h
  simp only [Am1, step] at h ⊢
  dsimp only [i,j] at h
  simpa only [show ((x%14).toNat:Int) = x%14 by omega, show (x%14)%14=(x)%14 by omega, show (x%14-1)%14=(x-1)%14 by omega, show (x%14+1)%14=(x+1)%14 by omega, show (x%14+(0))%14=(x+(0))%14 by omega, show (t%7)%7=(t)%7 by omega, show (t%7+1)%7=(t+1)%7 by omega] using h
theorem Am1ret273 (t : Nat) (x : Int) : Am1 (t+273) (x+(-28)) = Am1 t x := by
  have tab : ∀ i : Fin 7, ∀ j : Fin 14, (let t := i.val; let x : Int := j.val; Am1 (t+273) (x+(-28)) = Am1 t x) := by decide
  let i : Fin 7 := ⟨t%7,by omega⟩
  let j : Fin 14 := ⟨(x%14).toNat,by omega⟩
  have h := tab i j
  dsimp only at h
  simp only [Am1, step] at h ⊢
  dsimp only [i,j] at h
  simpa only [show ((x%14).toNat:Int) = x%14 by omega, show (x%14)%14=(x)%14 by omega, show (x%14-1)%14=(x-1)%14 by omega, show (x%14+1)%14=(x+1)%14 by omega, show (x%14+(-28))%14=(x+(-28))%14 by omega, show (t%7)%7=(t)%7 by omega, show (t%7+273)%7=(t+273)%7 by omega] using h
theorem Am1ret7 (t : Nat) (x : Int) : Am1 (t+7) (x+(0)) = Am1 t x := by
  have tab : ∀ i : Fin 7, ∀ j : Fin 14, (let t := i.val; let x : Int := j.val; Am1 (t+7) (x+(0)) = Am1 t x) := by decide
  let i : Fin 7 := ⟨t%7,by omega⟩
  let j : Fin 14 := ⟨(x%14).toNat,by omega⟩
  have h := tab i j
  dsimp only at h
  simp only [Am1, step] at h ⊢
  dsimp only [i,j] at h
  simpa only [show ((x%14).toNat:Int) = x%14 by omega, show (x%14)%14=(x)%14 by omega, show (x%14-1)%14=(x-1)%14 by omega, show (x%14+1)%14=(x+1)%14 by omega, show (x%14+(0))%14=(x+(0))%14 by omega, show (t%7)%7=(t)%7 by omega, show (t%7+7)%7=(t+7)%7 by omega] using h
def Am2tab : Array Nat := #[
0x3647,
0x1f64,
0x11f6,
0x191f,
0x3d91,
0x7d9,
0x247d]
def Am2 (t : Nat) (x : Int) := cell (Am2tab[t%7]!) (x%14)
theorem Am2step (t : Nat) (x : Int) : step (Am2 t) x = Am2 (t+1) x := by
  have tab : ∀ i : Fin 7, ∀ j : Fin 14, (let t := i.val; let x : Int := j.val; step (Am2 t) x = Am2 (t+1) x) := by decide
  let i : Fin 7 := ⟨t%7,by omega⟩
  let j : Fin 14 := ⟨(x%14).toNat,by omega⟩
  have h := tab i j
  dsimp only at h
  simp only [Am2, step] at h ⊢
  dsimp only [i,j] at h
  simpa only [show ((x%14).toNat:Int) = x%14 by omega, show (x%14)%14=(x)%14 by omega, show (x%14-1)%14=(x-1)%14 by omega, show (x%14+1)%14=(x+1)%14 by omega, show (x%14+(0))%14=(x+(0))%14 by omega, show (t%7)%7=(t)%7 by omega, show (t%7+1)%7=(t+1)%7 by omega] using h
theorem Am2ret3 (t : Nat) (x : Int) : Am2 (t+3) (x+(2)) = Am2 t x := by
  have tab : ∀ i : Fin 7, ∀ j : Fin 14, (let t := i.val; let x : Int := j.val; Am2 (t+3) (x+(2)) = Am2 t x) := by decide
  let i : Fin 7 := ⟨t%7,by omega⟩
  let j : Fin 14 := ⟨(x%14).toNat,by omega⟩
  have h := tab i j
  dsimp only at h
  simp only [Am2, step] at h ⊢
  dsimp only [i,j] at h
  simpa only [show ((x%14).toNat:Int) = x%14 by omega, show (x%14)%14=(x)%14 by omega, show (x%14-1)%14=(x-1)%14 by omega, show (x%14+1)%14=(x+1)%14 by omega, show (x%14+(2))%14=(x+(2))%14 by omega, show (t%7)%7=(t)%7 by omega, show (t%7+3)%7=(t+3)%7 by omega] using h
theorem Am2ret7 (t : Nat) (x : Int) : Am2 (t+7) (x+(0)) = Am2 t x := by
  have tab : ∀ i : Fin 7, ∀ j : Fin 14, (let t := i.val; let x : Int := j.val; Am2 (t+7) (x+(0)) = Am2 t x) := by decide
  let i : Fin 7 := ⟨t%7,by omega⟩
  let j : Fin 14 := ⟨(x%14).toNat,by omega⟩
  have h := tab i j
  dsimp only at h
  simp only [Am2, step] at h ⊢
  dsimp only [i,j] at h
  simpa only [show ((x%14).toNat:Int) = x%14 by omega, show (x%14)%14=(x)%14 by omega, show (x%14-1)%14=(x-1)%14 by omega, show (x%14+1)%14=(x+1)%14 by omega, show (x%14+(0))%14=(x+(0))%14 by omega, show (t%7)%7=(t)%7 by omega, show (t%7+7)%7=(t+7)%7 by omega] using h
theorem Am2ret882 (t : Nat) (x : Int) : Am2 (t+882) (x+(378)) = Am2 t x := by
  have tab : ∀ i : Fin 7, ∀ j : Fin 14, (let t := i.val; let x : Int := j.val; Am2 (t+882) (x+(378)) = Am2 t x) := by decide
  let i : Fin 7 := ⟨t%7,by omega⟩
  let j : Fin 14 := ⟨(x%14).toNat,by omega⟩
  have h := tab i j
  dsimp only at h
  simp only [Am2, step] at h ⊢
  dsimp only [i,j] at h
  simpa only [show ((x%14).toNat:Int) = x%14 by omega, show (x%14)%14=(x)%14 by omega, show (x%14-1)%14=(x-1)%14 by omega, show (x%14+1)%14=(x+1)%14 by omega, show (x%14+(378))%14=(x+(378))%14 by omega, show (t%7)%7=(t)%7 by omega, show (t%7+882)%7=(t+882)%7 by omega] using h

end Rails
