import CoreGapC

namespace Rails.SectorABC
open Rule110Complete Rule110Fin1320Bridge Rule110LocalWindow Rule110KernelCert

def hit (r c : Nat) : Bool :=
  torHit r c || (Bm0 (2235+r) c != Bm2 (2235+r) c)

set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192

theorem hitCount :
    ((List.range 315).map (fun r => ((List.range 210).filter (hit r)).length)).sum
      = 53550 := by decide

theorem covered (r q : Nat) (c : Fin 210) (z : Int)
    (h : hit r c.val = true)
    (t : Nat) (ht : t = 4000 + r + 315*q)
    (x : Int) (hx : x = (c.val : Int) + 210*z)
    (lo : 0 ≤ x) (hi : x ≤ (↑(t-t/3) : Int)-106) : EssentialAt t (-x) := by
  have hAm0_3240 : Am0 (t-3240) x = Am0 (760+r) c.val := by
    unfold Am0
    rw [show (t-3240)%15=(760+r)%15 by omega,
      show x%10=(c.val:Int)%10 by omega]
  have hAm2_3240 : Am2 (t-3240) x = Am2 (760+r) c.val := by
    unfold Am2
    rw [show (t-3240)%7=(760+r)%7 by omega,
      show x%14=(c.val:Int)%14 by omega]
  have hBm0_1766 : Bm0 (t-1766) x = Bm0 (2234+r) c.val := by
    unfold Bm0
    rw [show (t-1766)%9=(2234+r)%9 by omega,
      show x%6=(c.val:Int)%6 by omega]
  have hBm2_1766 : Bm2 (t-1766) x = Bm2 (2234+r) c.val := by
    unfold Bm2
    rw [show (t-1766)%7=(2234+r)%7 by omega,
      show x%14=(c.val:Int)%14 by omega]
  have hBm0_1765 : Bm0 (t-1765) x = Bm0 (2235+r) c.val := by
    unfold Bm0
    rw [show (t-1765)%9=(2235+r)%9 by omega,
      show x%6=(c.val:Int)%6 by omega]
  have hBm2_1765 : Bm2 (t-1765) x = Bm2 (2235+r) c.val := by
    unfold Bm2
    rw [show (t-1765)%7=(2235+r)%7 by omega,
      show x%14=(c.val:Int)%14 by omega]
  simp only [hit, torHit, Bool.or_eq_true, bne_iff_ne] at h
  rcases h with (ha|hb)|hc
  · have e := essentialA2 (t-3240) x (by omega) (by omega) (by
      rwa [hAm0_3240,hAm2_3240])
    simpa only [show t-3240+3240=t by omega] using e
  · have e := essentialB2 (t-1766) x (by omega) (by omega) (by
      rwa [hBm0_1766,hBm2_1766])
    simpa only [show t-1766+1766=t by omega] using e
  · apply essential (line Cinit)
    have hb := (C_shift_B t (by omega)).1
    rw [show t+1=(t-1765)+1766 by omega, Bbackground] at hb
    have hy := wedgeC2 (t-1765) x (by omega) (by omega)
    rw [show t-1765+1765=t by omega] at hy
    rwa [hb, hy, hBm0_1765, hBm2_1765]

theorem onesWitness : EssentialAt 5460 618 := by
  change EssentialAt 5460 (-(-618 : Int))
  let u := input 1 1 0
  apply essential (line u)
  have h : evolve 5460 (flipZero (line u)) (-618) =
      evolve 5460 (line (defect u)) (-618) := by
    apply Rule110Ether.agree3m _ _ 1820
    intro j hj hk
    apply def_agree <;> omega
  rw [h, ← line_run, ← line_run]
  decide

#print axioms covered
#print axioms onesWitness
end Rails.SectorABC
