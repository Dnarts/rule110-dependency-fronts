import AMedia
namespace Rails
open Rule110Complete Rule110Fin1320Bridge Rule110LocalWindow
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option exponentiation.threshold 16384
def A2tab : Array Nat := #[
0x11f647df647d91f647d9,
0x191f6471f647d91f647d,
0x1ec8fb2c8fb23ec8fb23]
def A2 (t : Nat) (x : Int) := if x-(t:Int)*(2)/3<(2084) then Am2 t x else if (2160)<x-(t:Int)*(2)/3 then Am0 t x else cell A2tab[t%3]! (x-(t:Int)*(2)/3-(2084))
theorem A2ret (t : Nat) (x : Int) : A2 (t+3) (x+(2)) = A2 t x := by
  unfold A2
  simp only [show x+(2)-((↑(t+3):Int)*(2)/3) = x-((t:Int)*(2)/3) by omega, show (t+3)%3=t%3 by omega, Am2ret3, Am0ret3]
private theorem A2check0 : ∀ r : Fin 3, ∀ j : Fin 81, let y := (2082:Int)+j.val+((r.val+0):Int)*(2)/3; step (A2 (r.val+0)) y = A2 ((r.val+0)+1) y := by decide
theorem A2step : ∀ t x, step (A2 t) x = A2 (t+1) x := by
  apply propagate _ 3 (2) (by decide) A2ret
  intro t ht x
  let z := x - (t:Int)*(2)/3
  by_cases hl : z < (2084)-2
  · have h (j : Int) (hj : x-1≤j ∧ j≤x+1) : A2 t j = Am2 t j := by
      simp only [A2,ite_true,ite_false,show j-(t:Int)*(2)/3<(2084) by dsimp [z] at hl; omega]
    rw [show step (A2 t) x = step (Am2 t) x by unfold step; rw [h _ (by omega),h _ (by omega),h _ (by omega)], Am2step]
    simp only [A2,ite_true,ite_false,show x-(↑(t+1):Int)*(2)/3<(2084) by dsimp [z] at hl; omega]
  by_cases hr : (2160)+2 < z
  · have h (j : Int) (hj : x-1≤j ∧ j≤x+1) : A2 t j = Am0 t j := by
      have hh : (2160)<j-(t:Int)*(2)/3 := by dsimp [z] at hr; omega
      simp only [A2,ite_true,ite_false,hh,show ¬ j-(t:Int)*(2)/3<(2084) by omega]
    rw [show step (A2 t) x = step (Am0 t) x by unfold step; rw [h _ (by omega),h _ (by omega),h _ (by omega)], Am0step]
    have hh : (2160)<x-(↑(t+1):Int)*(2)/3 := by dsimp [z] at hr; omega
    simp only [A2,ite_true,ite_false,hh,show ¬ x-(↑(t+1):Int)*(2)/3<(2084) by omega]
  let k : Fin 81 := ⟨(z-(2082)).toNat, by omega⟩
  have tab : ∀ r : Fin 3, ∀ j : Fin 81, let y := (2082:Int)+j.val+(r.val:Int)*(2)/3; step (A2 r.val) y = A2 (r.val+1) y := by
    intro r j
    have h0 := A2check0 ⟨r.val-0, by omega⟩ j
    simpa only [show r.val-0+0=r.val by omega, show ((r.val-0:Nat):Int)+0=(r.val:Int) by omega] using h0
  have h := tab ⟨t,ht⟩ k
  dsimp only at h
  rwa [show (2082:Int)+(k.val:Int)+(t:Int)*(2)/3=x by dsimp [k,z]; omega] at h

end Rails
