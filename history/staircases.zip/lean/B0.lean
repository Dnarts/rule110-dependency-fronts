import BMedia
namespace Rails
open Rule110Complete Rule110Fin1320Bridge Rule110LocalWindow
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option exponentiation.threshold 16384
def B0tab : Array Nat := #[
0x3b27,
0x1f6b,
0x31fe,
0x1903,
0x1d82,
0x2f87,
0x38c4,
0xce6,
0xeb7,
0x17fb,
0x3c0e,
0x60b,
0x270e,
0x2b16,
0x3f9f,
0x20d1,
0x30f9,
0x388d,
0x199e,
0x1dd3,
0x177b,
0x3dce,
0xed7,
0xbfd,
0x2e07,
0x3b05,
0x1f0f,
0x3188,
0x19cc,
0x3d6e,
0x7fb,
0x81d,
0x2c17,
0x3e1c,
0x2316,
0x273e,
0x35a3,
0x1ff2,
0x101b,
0x303c,
0x3826,
0xc37,
0xe3d,
0x164e,
0x3f6b,
0x1fe,
0x2103,
0x3183,
0x3385,
0x3ac7,
0x2fe5,
0x3837,
0x187b,
0x1c4f,
0x1668,
0x3f7c,
0x38d,
0x2cf,
0x23e9,
0x323d]
def B0 (t : Nat) (x : Int) := if x-(t:Int)*(-14)/60<(-416) then Bm0 t x else if (-403)<x-(t:Int)*(-14)/60 then Bm1 t x else cell B0tab[t%60]! (x-(t:Int)*(-14)/60-(-416))
theorem B0ret (t : Nat) (x : Int) : B0 (t+60) (x+(-14)) = B0 t x := by
  unfold B0
  simp only [show x+(-14)-((↑(t+60):Int)*(-14)/60) = x-((t:Int)*(-14)/60) by omega, show (t+60)%60=t%60 by omega, Bm0ret60, Bm1ret60]
private theorem B0check0 : ∀ r : Fin 8, ∀ j : Fin 18, let y := (-418:Int)+j.val+((r.val+0):Int)*(-14)/60; step (B0 (r.val+0)) y = B0 ((r.val+0)+1) y := by decide
private theorem B0check8 : ∀ r : Fin 8, ∀ j : Fin 18, let y := (-418:Int)+j.val+((r.val+8):Int)*(-14)/60; step (B0 (r.val+8)) y = B0 ((r.val+8)+1) y := by decide
private theorem B0check16 : ∀ r : Fin 8, ∀ j : Fin 18, let y := (-418:Int)+j.val+((r.val+16):Int)*(-14)/60; step (B0 (r.val+16)) y = B0 ((r.val+16)+1) y := by decide
private theorem B0check24 : ∀ r : Fin 8, ∀ j : Fin 18, let y := (-418:Int)+j.val+((r.val+24):Int)*(-14)/60; step (B0 (r.val+24)) y = B0 ((r.val+24)+1) y := by decide
private theorem B0check32 : ∀ r : Fin 8, ∀ j : Fin 18, let y := (-418:Int)+j.val+((r.val+32):Int)*(-14)/60; step (B0 (r.val+32)) y = B0 ((r.val+32)+1) y := by decide
private theorem B0check40 : ∀ r : Fin 8, ∀ j : Fin 18, let y := (-418:Int)+j.val+((r.val+40):Int)*(-14)/60; step (B0 (r.val+40)) y = B0 ((r.val+40)+1) y := by decide
private theorem B0check48 : ∀ r : Fin 8, ∀ j : Fin 18, let y := (-418:Int)+j.val+((r.val+48):Int)*(-14)/60; step (B0 (r.val+48)) y = B0 ((r.val+48)+1) y := by decide
private theorem B0check56 : ∀ r : Fin 4, ∀ j : Fin 18, let y := (-418:Int)+j.val+((r.val+56):Int)*(-14)/60; step (B0 (r.val+56)) y = B0 ((r.val+56)+1) y := by decide
theorem B0step : ∀ t x, step (B0 t) x = B0 (t+1) x := by
  apply propagate _ 60 (-14) (by decide) B0ret
  intro t ht x
  let z := x - (t:Int)*(-14)/60
  by_cases hl : z < (-416)-2
  · have h (j : Int) (hj : x-1≤j ∧ j≤x+1) : B0 t j = Bm0 t j := by
      simp only [B0,ite_true,ite_false,show j-(t:Int)*(-14)/60<(-416) by dsimp [z] at hl; omega]
    rw [show step (B0 t) x = step (Bm0 t) x by unfold step; rw [h _ (by omega),h _ (by omega),h _ (by omega)], Bm0step]
    simp only [B0,ite_true,ite_false,show x-(↑(t+1):Int)*(-14)/60<(-416) by dsimp [z] at hl; omega]
  by_cases hr : (-403)+2 < z
  · have h (j : Int) (hj : x-1≤j ∧ j≤x+1) : B0 t j = Bm1 t j := by
      have hh : (-403)<j-(t:Int)*(-14)/60 := by dsimp [z] at hr; omega
      simp only [B0,ite_true,ite_false,hh,show ¬ j-(t:Int)*(-14)/60<(-416) by omega]
    rw [show step (B0 t) x = step (Bm1 t) x by unfold step; rw [h _ (by omega),h _ (by omega),h _ (by omega)], Bm1step]
    have hh : (-403)<x-(↑(t+1):Int)*(-14)/60 := by dsimp [z] at hr; omega
    simp only [B0,ite_true,ite_false,hh,show ¬ x-(↑(t+1):Int)*(-14)/60<(-416) by omega]
  let k : Fin 18 := ⟨(z-(-418)).toNat, by omega⟩
  have tab : ∀ r : Fin 60, ∀ j : Fin 18, let y := (-418:Int)+j.val+(r.val:Int)*(-14)/60; step (B0 r.val) y = B0 (r.val+1) y := by
    intro r j
    by_cases h : r.val < 8
    ·   have h0 := B0check0 ⟨r.val-0, by omega⟩ j
        simpa only [show r.val-0+0=r.val by omega, show ((r.val-0:Nat):Int)+0=(r.val:Int) by omega] using h0
    by_cases h : r.val < 16
    ·   have h0 := B0check8 ⟨r.val-8, by omega⟩ j
        simpa only [show r.val-8+8=r.val by omega, show ((r.val-8:Nat):Int)+8=(r.val:Int) by omega] using h0
    by_cases h : r.val < 24
    ·   have h0 := B0check16 ⟨r.val-16, by omega⟩ j
        simpa only [show r.val-16+16=r.val by omega, show ((r.val-16:Nat):Int)+16=(r.val:Int) by omega] using h0
    by_cases h : r.val < 32
    ·   have h0 := B0check24 ⟨r.val-24, by omega⟩ j
        simpa only [show r.val-24+24=r.val by omega, show ((r.val-24:Nat):Int)+24=(r.val:Int) by omega] using h0
    by_cases h : r.val < 40
    ·   have h0 := B0check32 ⟨r.val-32, by omega⟩ j
        simpa only [show r.val-32+32=r.val by omega, show ((r.val-32:Nat):Int)+32=(r.val:Int) by omega] using h0
    by_cases h : r.val < 48
    ·   have h0 := B0check40 ⟨r.val-40, by omega⟩ j
        simpa only [show r.val-40+40=r.val by omega, show ((r.val-40:Nat):Int)+40=(r.val:Int) by omega] using h0
    by_cases h : r.val < 56
    ·   have h0 := B0check48 ⟨r.val-48, by omega⟩ j
        simpa only [show r.val-48+48=r.val by omega, show ((r.val-48:Nat):Int)+48=(r.val:Int) by omega] using h0
    have h0 := B0check56 ⟨r.val-56, by omega⟩ j
    simpa only [show r.val-56+56=r.val by omega, show ((r.val-56:Nat):Int)+56=(r.val:Int) by omega] using h0
  have h := tab ⟨t,ht⟩ k
  dsimp only at h
  rwa [show (-418:Int)+(k.val:Int)+(t:Int)*(-14)/60=x by dsimp [k,z]; omega] at h

end Rails
