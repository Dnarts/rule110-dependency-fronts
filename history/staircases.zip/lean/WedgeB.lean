import StaircaseB
namespace Rails
open Rule110Complete Rule110LocalWindow Rule110Fin1320Bridge Rule110FrontGlue
theorem wedgeB1 (t : Nat) (x : Int) (hl : -403+(t:Int)*(-14)/60<x) (hr : x < -174+(t:Int)*(-36)/513) : evolve (t+1766) (flipZero (line Binit)) x = Bm1 t x := by
  rw [Browall]
  unfold Brow splice Bcut BcutR
  by_cases cut : x ≤ Bcut t <;> unfold Bcut at cut <;> simp only [cut,ite_true,ite_false,B0,B1,B2]
  all_goals by_cases cut2 : x ≤ BcutR t <;> unfold BcutR at cut2 <;> simp (disch := omega) only [ite_eq_left,ite_eq_right] <;> omega
theorem essentialB1 (t : Nat) (x : Int) (hl : -403+(t:Int)*(-14)/60<x) (hr : x < -174+(t:Int)*(-36)/513) (hd : Bm0 t x ≠ Bm1 t x) : Rule110KernelCert.EssentialAt (t+1766) (-x) := by
  apply essential (line Binit)
  rwa [Bbackground,wedgeB1 t x hl hr]
#print axioms essentialB1
theorem wedgeB2 (t : Nat) (x : Int) (hl : -108+(t:Int)*(-36)/513<x) (hr : x<1154+(t:Int)*2/3) : evolve (t+1766) (flipZero (line Binit)) x = Bm2 t x := by
  rw [Browall]
  unfold Brow splice Bcut BcutR
  by_cases cut : x ≤ Bcut t <;> unfold Bcut at cut <;> simp only [cut,ite_true,ite_false,B0,B1,B2]
  all_goals by_cases cut2 : x ≤ BcutR t <;> unfold BcutR at cut2 <;> simp (disch := omega) only [ite_eq_left,ite_eq_right] <;> omega
theorem essentialB2 (t : Nat) (x : Int) (hl : -108+(t:Int)*(-36)/513<x) (hr : x<1154+(t:Int)*2/3) (hd : Bm0 t x ≠ Bm2 t x) : Rule110KernelCert.EssentialAt (t+1766) (-x) := by
  apply essential (line Binit)
  rwa [Bbackground,wedgeB2 t x hl hr]
#print axioms essentialB2
end Rails
