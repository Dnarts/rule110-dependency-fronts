#include <algorithm>
#include <iostream>
#include <string>
#include <unordered_set>
#include <vector>

int shrink(int row) {
    int center = row >> 1;
    int right = row >> 2;
    return (center | right) ^ (row & center & right);
}

struct Node {
    int window, residue, parent, input;
};

int main() {
    int phase, position, width, start, context[50];
    while (std::cin >> phase >> position >> width >> start) {
        for (int &value : context) std::cin >> value;
        std::vector<Node> nodes{{start, 0, -1, -1}};
        std::vector<int> pending{0};
        std::unordered_set<int> seen{start};
        std::string failure;
        while (!pending.empty() && failure.empty()) {
            int index = pending.back();
            pending.pop_back();
            Node node = nodes[index];
            int c = context[node.residue];
            int nextResidue = (node.residue + 1) % 50;
            for (int bit : {0, 1}) {
                int row = (c & 15) | (node.window << 4) | (bit << (4 + width));
                int result = shrink(shrink(row));
                if ((result & 1) != (c >> 4)) {
                    failure += char('0' + bit);
                    for (int k = index; nodes[k].parent >= 0; k = nodes[k].parent)
                        failure += char('0' + nodes[k].input);
                    std::reverse(failure.begin(), failure.end());
                    break;
                }
                int window = (result >> 1) & ((1 << width) - 1);
                if (seen.insert((nextResidue << width) | window).second) {
                    pending.push_back(nodes.size());
                    nodes.push_back({window, nextResidue, index, bit});
                }
            }
        }
        std::cout << phase << ' ' << position << ' ' << width << ' '
                  << (failure.empty() ? "CLOSED" : "FAIL") << ' '
                  << seen.size() << ' ' << failure << '\n';
    }
}
