#!/usr/bin/env python3
"""Proof-carrying Lean checkpoint generator for Rule 110.

Writes two Lean modules. This Python code is an *untrusted producer*;
Lean's kernel must check the generated propositions and their semantic links.
"""
from pathlib import Path
from hashlib import sha256
import json
import argparse

RING = 1320
CENTER = RING // 2
T0 = 300
PRE_BLOCK = 10
LEFT_DT = 30
LEFT_W = 106
LEFT_CRYSTAL = 167
LEFT_WORDS = ("0001111001", "1011", "001011")
RIGHT_DT = 40
RIGHT_W = 8
RIGHT_SELECTED = (
    ("01", 0), ("001", 0), ("00001", 3), ("00101", 2),
    ("00111", 1), ("0000001001", 4),
)


def step_anf(s: int, n: int = RING) -> int:
    mask = (1 << n) - 1
    l = ((s << 1) | (s >> (n - 1))) & mask
    r = ((s >> 1) | ((s & 1) << (n - 1))) & mask
    return (s ^ r ^ (s & r) ^ (l & s & r)) & mask


def init_state(word: str, phase: int, n: int = RING):
    center = n // 2
    b = sum(1 << i for i in range(n) if word[(i - center + phase) % len(word)] == "1")
    return b, b ^ (1 << center)


def fmt_bv(val: int) -> str:
    return f"0x{val:0330x}#1320"


def fmt_bool_list(word: str) -> str:
    return "[" + ", ".join("true" if ch == "1" else "false" for ch in word) + "]"


def evolve_checkpoints(b0: int, y0: int, end_t: int):
    b_map = {0: b0}
    y_map = {0: y0}
    b, y = b0, y0
    for t in range(1, end_t + 1):
        b = step_anf(b)
        y = step_anf(y)
        if (t <= T0 and t % PRE_BLOCK == 0) or (t > T0):
            b_map[t] = b
            y_map[t] = y
    return b_map, y_map


def build_side_module(side, phases, dt, crystal_depth, strip_width, out_file):
    end_t = T0 + 2 * dt
    lines = [
        "import Rule110KernelCertificate", "", "/-!",
        f"# Proof-Carrying Checkpoint Certificate ({side.upper()} boundary)",
        "Untrusted external checkpoints. Every initial state and short step is checked with `decide`.",
        "Note: translating these facts into the half-ray hypotheses remains a separate proof task.",
        "-/", "",
        f"namespace Rule110KernelCert.{side.capitalize()}Checkpoints", "",
        "open Rule110KernelCert", "",
        "theorem ringEvolveBV_add (a b : Nat) (u : RingBV) :",
        "    ringEvolveBV (a + b) u = ringEvolveBV a (ringEvolveBV b u) := by",
        "  induction a with",
        "  | zero => simp [ringEvolveBV]",
        "  | succ a ih => simp [Nat.succ_add, ringEvolveBV, ih]", "",
    ]
    meta = {"side": side, "phases": len(phases), "final_t": end_t, "checks": {"step": 0, "initial": 0, "evolve": 0, "bg_shift": 0, "tile": 0, "coverage": 0}}
    for pi, (word, ph) in enumerate(phases):
        b0, y0 = init_state(word, ph)
        bs, ys = evolve_checkpoints(b0, y0, end_t)
        times = sorted(bs)
        ns = f"Phase{pi}"
        lines += [f"namespace {ns}", f"def word : List Bool := {fmt_bool_list(word)}", f"def ph : Nat := {ph}", ""]
        for t in times:
            lines += [f"def B_{t} : RingBV := {fmt_bv(bs[t])}", f"def Y_{t} : RingBV := {fmt_bv(ys[t])}"]
        lines += [
            "", "theorem init_B_ok : initRingBV word ph = B_0 := by decide",
            "theorem init_Y_ok : flipCenterBV B_0 = Y_0 := by decide", "",
        ]
        meta["checks"]["initial"] += 2
        for t1, t2 in zip(times, times[1:]):
            delta = t2 - t1
            assert delta in (1, 10)
            lines += [
                f"theorem step_B_{t1}_{t2} : ringEvolveBV {delta} B_{t1} = B_{t2} := by decide",
                f"theorem step_Y_{t1}_{t2} : ringEvolveBV {delta} Y_{t1} = Y_{t2} := by decide",
            ]
            meta["checks"]["step"] += 2
        lines += ["", "theorem evolve_B_0 : ringEvolveBV 0 (initRingBV word ph) = B_0 := init_B_ok",
                  "theorem evolve_Y_0 : ringEvolveBV 0 (flipCenterBV (initRingBV word ph)) = Y_0 := by",
                  "  simp [ringEvolveBV, init_B_ok, init_Y_ok]"]
        meta["checks"]["evolve"] += 2
        for prev_t, t in zip(times, times[1:]):
            delta = t - prev_t
            lines += [
                f"theorem evolve_B_{t} : ringEvolveBV {t} (initRingBV word ph) = B_{t} := by",
                f"  have h : {t} = {delta} + {prev_t} := rfl",
                f"  rw [h, ringEvolveBV_add, evolve_B_{prev_t}, step_B_{prev_t}_{t}]",
                f"theorem evolve_Y_{t} : ringEvolveBV {t} (flipCenterBV (initRingBV word ph)) = Y_{t} := by",
                f"  have h : {t} = {delta} + {prev_t} := rfl",
                f"  rw [h, ringEvolveBV_add, evolve_Y_{prev_t}, step_Y_{prev_t}_{t}]",
            ]
            meta["checks"]["evolve"] += 2
        for offset in range(dt):
            t = T0 + offset
            n = t + dt
            if side == "left":
                lines += [
                    f"theorem bg_shift_{t} : B_{n} = rotL 20 B_{t} := by decide",
                    f"theorem tile_eq_{t} : extractDown Y_{t} (660 + edgeNat {t}) {crystal_depth} = "
                    f"extractDown Y_{n} (660 + edgeNat {n}) {crystal_depth} := by decide",
                ]
            else:
                lines += [
                    f"theorem bg_shift_{t} : B_{n} = rotR 40 B_{t} := by decide",
                    f"theorem tile_eq_{t} : extractUp Y_{t} (660 - {t}) {crystal_depth} = "
                    f"extractUp Y_{n} (660 - {n}) {crystal_depth} := by decide",
                ]
            meta["checks"]["bg_shift"] += 1
            meta["checks"]["tile"] += 1
        lines += [f"end {ns}", ""]
    fullmask = (1 << strip_width) - 1
    for off in range(dt):
        t = T0 + off
        terms = []
        for pi in range(len(phases)):
            ns = f"Phase{pi}"
            expr = (f"extractDown ({ns}.B_{t} ^^^ {ns}.Y_{t}) (660 + edgeNat {t}) {strip_width}"
                    if side == "left" else
                    f"extractUp ({ns}.B_{t} ^^^ {ns}.Y_{t}) (660 - {t}) {strip_width}")
            terms.append(expr)
        lines.append(f"theorem base_cov_{t} : ({' ||| '.join(terms)}) = {fullmask} := by decide")
        meta["checks"]["coverage"] += 1
    lines += ["", f"end Rule110KernelCert.{side.capitalize()}Checkpoints", ""]
    Path(out_file).write_text("\n".join(lines), encoding="utf-8")
    meta.update({"file":Path(out_file).name, "bytes":Path(out_file).stat().st_size,
                 "sha256":sha256(Path(out_file).read_bytes()).hexdigest()})
    return meta


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--output-dir", default=".")
    args = ap.parse_args()
    out = Path(args.output_dir)
    out.mkdir(exist_ok=True, parents=True)
    left_phases = [(w, ph) for w in LEFT_WORDS for ph in range(len(w))]
    metadata = [
        build_side_module("left", left_phases, LEFT_DT, LEFT_CRYSTAL, LEFT_W, str(out/"Rule110LeftCheckpoints.lean")),
        build_side_module("right", list(RIGHT_SELECTED), RIGHT_DT, RIGHT_W, RIGHT_W, str(out/"Rule110RightCheckpoints.lean")),
    ]
    (out/"checkpoint_manifest.json").write_text(json.dumps(metadata, indent=2, ensure_ascii=False)+"\n", encoding="utf-8")
    for x in metadata:
        print(f"Generated {x['file']}: {x['phases']} phases, {x['bytes']:,} bytes, {x['checks']}")

if __name__ == "__main__":
    main()
