# Rule 110 Continuation · Hebrew edition

Source: [published English TeX](https://github.com/Dnarts/rule110-dependency-fronts/blob/main/continuation/paper/rule110-continuation-en.tex) and its [verification supplement](https://github.com/Dnarts/rule110-dependency-fronts/blob/main/continuation/paper/verification-status.tex), compared with the [author's Russian PDF](https://github.com/Dnarts/rule110-dependency-fronts/blob/main/continuation/paper/rule110-continuation-ru.pdf). Figures are the original vector PDFs. This edition translates the existing results and does not independently rerun Lean.

Build from this directory with XeLaTeX, Polyglossia, bidi, Liberation Serif, and DejaVu Sans Mono. Hebrew uses the bundled Noto Sans Hebrew (OFL; regular and bold instances):
```sh
xelatex -halt-on-error -interaction=nonstopmode rule110-continuation-he.tex
xelatex -halt-on-error -interaction=nonstopmode rule110-continuation-he.tex
```
