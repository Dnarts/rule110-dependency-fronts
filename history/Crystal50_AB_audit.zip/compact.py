from pathlib import Path
import re
src=Path('Crystal50Graph.lean').read_text()
a=src.index('def valid');b=src.index('def row0_0')
src=src[:a]+'''structure Row where
  size : Nat
  bits : Nat
  deriving Inhabited

def entry (row : Row) (i : Nat) := (row.bits >>> (36*i)) % (2^36)
def valid (p : Phase) (j : Nat) (src dst : Row) :=
  let prefixBits := ctx p j
  let want := Cm p (2452+2*j) (-352-(j:Int))
  (List.range src.size).all fun k => [0,1].all fun r =>
    let code := entry src k
    let v := shrink (shrink (prefixBits + (code%65536)*16 + r*1048576))
    let i := (code >>> (16+10*r)) % 1024
    i < dst.size && v.testBit 0 == want && (v >>> 1) % 65536 == (entry dst i)%65536

'''+src[b:]
def pack(m):
    v=list(map(int,m[2].split(', ')))
    assert max(v)<2**36
    return f'def {m[1]} : Row := ⟨{len(v)}, {hex(sum(n<<(36*i) for i,n in enumerate(v)))}⟩'
src=re.sub(r'def (row\d+_\d+) : Array Nat := #\[([^\]]+)\]',pack,src)
src=re.sub(r'\((row\d+_0)\[(\d+)\]!\)',r'(entry \1 \2)',src)
Path('Crystal50Packed.lean').write_text(src)
