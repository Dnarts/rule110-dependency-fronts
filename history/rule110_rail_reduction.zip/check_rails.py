"""Finite certificates for infinite Rule 110 rays. Run: python check_rails.py"""
import argparse
import json

PHASES = [("0000101111", 594, 140), ("001011", 884, 210)]


def cell(a, b, c):
    return (110 >> (4*a + 2*b + c)) & 1


def apex(pattern):
    bits = [(pattern >> i) & 1 for i in range(7)]
    for _ in range(3):
        bits = [cell(*bits[i:i+3]) for i in range(len(bits)-2)]
    return bits[0]


def step(s, n, mask):
    left = ((s << 1) & mask) | (s >> (n-1))
    right = (s >> 1) | ((s & 1) << (n-1))
    return (~left & right) | (s & ~right) | (left & ~s & right)


def run(word, onset, depth, last):
    period = len(word)
    end = onset + 882*last + 3
    # Both the center and ring size are multiples of the background period.
    n = 2 * period * ((end + period + 3) // period + 1)
    center = n // 2
    mask = (1 << n) - 1
    b = int(''.join(word[(i-center+5) % period] for i in reversed(range(n))), 2)
    y = b ^ (1 << center)
    rows = []
    previous = None
    for t in range(end+1):
        if t >= onset and (t-onset) % 882 in (0, 3):
            index, delta = divmod(t-onset, 882)
            T = onset + 882*index
            x = T - T//3 - depth - 210*index
            if delta == 0:
                old_b, old_y = b, y
                if previous is not None:
                    # Compare the two unflipped/defect pairs in physical x,
                    # aligned by the proposed macro translation +378.
                    mism = (b ^ (previous[0] << 378)) | (y ^ (previous[1] << 378))
                    # Only seek a mismatch where both rings represent the line.
                    lo = max(-T, -(T-882)+378)
                    hi = min(T, T-882+378)
                    nearby = (mism >> (center+lo)) & ((1 << (hi-lo+1))-1)
                    mid = x-lo
                    left = nearby & ((1 << mid)-1)
                    right = nearby >> mid
                    differences = []
                    if left:
                        differences.append(lo+left.bit_length()-1)
                    if right:
                        differences.append(x+(right & -right).bit_length()-1)
                    closest = min(differences, key=lambda k: abs(k-x), default=None)
                else:
                    closest = None
                previous = (b, y)
            else:
                # For s > T+1 both defects are outside their light cones.
                # The next period of background bits therefore covers the infinite tail.
                stop = T+1+period
                keep = (1 << (stop-x+1))-1
                for old, new in ((old_b,b), (old_y,y)):
                    assert not ((((old >> (center+x)) ^ (new >> (center+x+2))) & keep)), (word,index,"tail")
                assert ((old_y ^ old_b) >> (center+x)) & 1, (word,index,"witness")
                rows.append(dict(n=index, t=T, physical_x=x, input_j=-x,
                                 macro_nearest_mismatch_x=closest))
        if t < end:
            b, y = step(b,n,mask), step(y,n,mask)
    return rows


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--last", type=int, default=32)
    args = parser.parse_args()
    if not __debug__ or args.last < 0:
        parser.error("use ordinary Python and a nonnegative --last")
    # Index zero is the leftmost input, at output coordinate minus three.
    assert all(apex(m) == apex(m ^ 1) for m in range(0,128,2))
    print(json.dumps({w:run(w,t,d,args.last) for w,t,d in PHASES}, indent=2))
