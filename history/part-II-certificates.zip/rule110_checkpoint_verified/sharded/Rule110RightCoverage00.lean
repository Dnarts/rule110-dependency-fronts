import Rule110RightPhase00
import Rule110RightPhase01
import Rule110RightPhase02
import Rule110RightPhase03
import Rule110RightPhase04
import Rule110RightPhase05

set_option exponentiation.threshold 2048
set_option maxRecDepth 10000
set_option maxHeartbeats 4000000

namespace Rule110KernelCert.RightCheckpoints

theorem base_cov_300 : (extractUp (Phase0.B_300 ^^^ Phase0.Y_300) (660 - 300) 8 ||| extractUp (Phase1.B_300 ^^^ Phase1.Y_300) (660 - 300) 8 ||| extractUp (Phase2.B_300 ^^^ Phase2.Y_300) (660 - 300) 8 ||| extractUp (Phase3.B_300 ^^^ Phase3.Y_300) (660 - 300) 8 ||| extractUp (Phase4.B_300 ^^^ Phase4.Y_300) (660 - 300) 8 ||| extractUp (Phase5.B_300 ^^^ Phase5.Y_300) (660 - 300) 8) = 255 := by decide
theorem base_cov_301 : (extractUp (Phase0.B_301 ^^^ Phase0.Y_301) (660 - 301) 8 ||| extractUp (Phase1.B_301 ^^^ Phase1.Y_301) (660 - 301) 8 ||| extractUp (Phase2.B_301 ^^^ Phase2.Y_301) (660 - 301) 8 ||| extractUp (Phase3.B_301 ^^^ Phase3.Y_301) (660 - 301) 8 ||| extractUp (Phase4.B_301 ^^^ Phase4.Y_301) (660 - 301) 8 ||| extractUp (Phase5.B_301 ^^^ Phase5.Y_301) (660 - 301) 8) = 255 := by decide
theorem base_cov_302 : (extractUp (Phase0.B_302 ^^^ Phase0.Y_302) (660 - 302) 8 ||| extractUp (Phase1.B_302 ^^^ Phase1.Y_302) (660 - 302) 8 ||| extractUp (Phase2.B_302 ^^^ Phase2.Y_302) (660 - 302) 8 ||| extractUp (Phase3.B_302 ^^^ Phase3.Y_302) (660 - 302) 8 ||| extractUp (Phase4.B_302 ^^^ Phase4.Y_302) (660 - 302) 8 ||| extractUp (Phase5.B_302 ^^^ Phase5.Y_302) (660 - 302) 8) = 255 := by decide
theorem base_cov_303 : (extractUp (Phase0.B_303 ^^^ Phase0.Y_303) (660 - 303) 8 ||| extractUp (Phase1.B_303 ^^^ Phase1.Y_303) (660 - 303) 8 ||| extractUp (Phase2.B_303 ^^^ Phase2.Y_303) (660 - 303) 8 ||| extractUp (Phase3.B_303 ^^^ Phase3.Y_303) (660 - 303) 8 ||| extractUp (Phase4.B_303 ^^^ Phase4.Y_303) (660 - 303) 8 ||| extractUp (Phase5.B_303 ^^^ Phase5.Y_303) (660 - 303) 8) = 255 := by decide
theorem base_cov_304 : (extractUp (Phase0.B_304 ^^^ Phase0.Y_304) (660 - 304) 8 ||| extractUp (Phase1.B_304 ^^^ Phase1.Y_304) (660 - 304) 8 ||| extractUp (Phase2.B_304 ^^^ Phase2.Y_304) (660 - 304) 8 ||| extractUp (Phase3.B_304 ^^^ Phase3.Y_304) (660 - 304) 8 ||| extractUp (Phase4.B_304 ^^^ Phase4.Y_304) (660 - 304) 8 ||| extractUp (Phase5.B_304 ^^^ Phase5.Y_304) (660 - 304) 8) = 255 := by decide
theorem base_cov_305 : (extractUp (Phase0.B_305 ^^^ Phase0.Y_305) (660 - 305) 8 ||| extractUp (Phase1.B_305 ^^^ Phase1.Y_305) (660 - 305) 8 ||| extractUp (Phase2.B_305 ^^^ Phase2.Y_305) (660 - 305) 8 ||| extractUp (Phase3.B_305 ^^^ Phase3.Y_305) (660 - 305) 8 ||| extractUp (Phase4.B_305 ^^^ Phase4.Y_305) (660 - 305) 8 ||| extractUp (Phase5.B_305 ^^^ Phase5.Y_305) (660 - 305) 8) = 255 := by decide
theorem base_cov_306 : (extractUp (Phase0.B_306 ^^^ Phase0.Y_306) (660 - 306) 8 ||| extractUp (Phase1.B_306 ^^^ Phase1.Y_306) (660 - 306) 8 ||| extractUp (Phase2.B_306 ^^^ Phase2.Y_306) (660 - 306) 8 ||| extractUp (Phase3.B_306 ^^^ Phase3.Y_306) (660 - 306) 8 ||| extractUp (Phase4.B_306 ^^^ Phase4.Y_306) (660 - 306) 8 ||| extractUp (Phase5.B_306 ^^^ Phase5.Y_306) (660 - 306) 8) = 255 := by decide
theorem base_cov_307 : (extractUp (Phase0.B_307 ^^^ Phase0.Y_307) (660 - 307) 8 ||| extractUp (Phase1.B_307 ^^^ Phase1.Y_307) (660 - 307) 8 ||| extractUp (Phase2.B_307 ^^^ Phase2.Y_307) (660 - 307) 8 ||| extractUp (Phase3.B_307 ^^^ Phase3.Y_307) (660 - 307) 8 ||| extractUp (Phase4.B_307 ^^^ Phase4.Y_307) (660 - 307) 8 ||| extractUp (Phase5.B_307 ^^^ Phase5.Y_307) (660 - 307) 8) = 255 := by decide
theorem base_cov_308 : (extractUp (Phase0.B_308 ^^^ Phase0.Y_308) (660 - 308) 8 ||| extractUp (Phase1.B_308 ^^^ Phase1.Y_308) (660 - 308) 8 ||| extractUp (Phase2.B_308 ^^^ Phase2.Y_308) (660 - 308) 8 ||| extractUp (Phase3.B_308 ^^^ Phase3.Y_308) (660 - 308) 8 ||| extractUp (Phase4.B_308 ^^^ Phase4.Y_308) (660 - 308) 8 ||| extractUp (Phase5.B_308 ^^^ Phase5.Y_308) (660 - 308) 8) = 255 := by decide
theorem base_cov_309 : (extractUp (Phase0.B_309 ^^^ Phase0.Y_309) (660 - 309) 8 ||| extractUp (Phase1.B_309 ^^^ Phase1.Y_309) (660 - 309) 8 ||| extractUp (Phase2.B_309 ^^^ Phase2.Y_309) (660 - 309) 8 ||| extractUp (Phase3.B_309 ^^^ Phase3.Y_309) (660 - 309) 8 ||| extractUp (Phase4.B_309 ^^^ Phase4.Y_309) (660 - 309) 8 ||| extractUp (Phase5.B_309 ^^^ Phase5.Y_309) (660 - 309) 8) = 255 := by decide
theorem base_cov_310 : (extractUp (Phase0.B_310 ^^^ Phase0.Y_310) (660 - 310) 8 ||| extractUp (Phase1.B_310 ^^^ Phase1.Y_310) (660 - 310) 8 ||| extractUp (Phase2.B_310 ^^^ Phase2.Y_310) (660 - 310) 8 ||| extractUp (Phase3.B_310 ^^^ Phase3.Y_310) (660 - 310) 8 ||| extractUp (Phase4.B_310 ^^^ Phase4.Y_310) (660 - 310) 8 ||| extractUp (Phase5.B_310 ^^^ Phase5.Y_310) (660 - 310) 8) = 255 := by decide
theorem base_cov_311 : (extractUp (Phase0.B_311 ^^^ Phase0.Y_311) (660 - 311) 8 ||| extractUp (Phase1.B_311 ^^^ Phase1.Y_311) (660 - 311) 8 ||| extractUp (Phase2.B_311 ^^^ Phase2.Y_311) (660 - 311) 8 ||| extractUp (Phase3.B_311 ^^^ Phase3.Y_311) (660 - 311) 8 ||| extractUp (Phase4.B_311 ^^^ Phase4.Y_311) (660 - 311) 8 ||| extractUp (Phase5.B_311 ^^^ Phase5.Y_311) (660 - 311) 8) = 255 := by decide
theorem base_cov_312 : (extractUp (Phase0.B_312 ^^^ Phase0.Y_312) (660 - 312) 8 ||| extractUp (Phase1.B_312 ^^^ Phase1.Y_312) (660 - 312) 8 ||| extractUp (Phase2.B_312 ^^^ Phase2.Y_312) (660 - 312) 8 ||| extractUp (Phase3.B_312 ^^^ Phase3.Y_312) (660 - 312) 8 ||| extractUp (Phase4.B_312 ^^^ Phase4.Y_312) (660 - 312) 8 ||| extractUp (Phase5.B_312 ^^^ Phase5.Y_312) (660 - 312) 8) = 255 := by decide
theorem base_cov_313 : (extractUp (Phase0.B_313 ^^^ Phase0.Y_313) (660 - 313) 8 ||| extractUp (Phase1.B_313 ^^^ Phase1.Y_313) (660 - 313) 8 ||| extractUp (Phase2.B_313 ^^^ Phase2.Y_313) (660 - 313) 8 ||| extractUp (Phase3.B_313 ^^^ Phase3.Y_313) (660 - 313) 8 ||| extractUp (Phase4.B_313 ^^^ Phase4.Y_313) (660 - 313) 8 ||| extractUp (Phase5.B_313 ^^^ Phase5.Y_313) (660 - 313) 8) = 255 := by decide
theorem base_cov_314 : (extractUp (Phase0.B_314 ^^^ Phase0.Y_314) (660 - 314) 8 ||| extractUp (Phase1.B_314 ^^^ Phase1.Y_314) (660 - 314) 8 ||| extractUp (Phase2.B_314 ^^^ Phase2.Y_314) (660 - 314) 8 ||| extractUp (Phase3.B_314 ^^^ Phase3.Y_314) (660 - 314) 8 ||| extractUp (Phase4.B_314 ^^^ Phase4.Y_314) (660 - 314) 8 ||| extractUp (Phase5.B_314 ^^^ Phase5.Y_314) (660 - 314) 8) = 255 := by decide
theorem base_cov_315 : (extractUp (Phase0.B_315 ^^^ Phase0.Y_315) (660 - 315) 8 ||| extractUp (Phase1.B_315 ^^^ Phase1.Y_315) (660 - 315) 8 ||| extractUp (Phase2.B_315 ^^^ Phase2.Y_315) (660 - 315) 8 ||| extractUp (Phase3.B_315 ^^^ Phase3.Y_315) (660 - 315) 8 ||| extractUp (Phase4.B_315 ^^^ Phase4.Y_315) (660 - 315) 8 ||| extractUp (Phase5.B_315 ^^^ Phase5.Y_315) (660 - 315) 8) = 255 := by decide
theorem base_cov_316 : (extractUp (Phase0.B_316 ^^^ Phase0.Y_316) (660 - 316) 8 ||| extractUp (Phase1.B_316 ^^^ Phase1.Y_316) (660 - 316) 8 ||| extractUp (Phase2.B_316 ^^^ Phase2.Y_316) (660 - 316) 8 ||| extractUp (Phase3.B_316 ^^^ Phase3.Y_316) (660 - 316) 8 ||| extractUp (Phase4.B_316 ^^^ Phase4.Y_316) (660 - 316) 8 ||| extractUp (Phase5.B_316 ^^^ Phase5.Y_316) (660 - 316) 8) = 255 := by decide
theorem base_cov_317 : (extractUp (Phase0.B_317 ^^^ Phase0.Y_317) (660 - 317) 8 ||| extractUp (Phase1.B_317 ^^^ Phase1.Y_317) (660 - 317) 8 ||| extractUp (Phase2.B_317 ^^^ Phase2.Y_317) (660 - 317) 8 ||| extractUp (Phase3.B_317 ^^^ Phase3.Y_317) (660 - 317) 8 ||| extractUp (Phase4.B_317 ^^^ Phase4.Y_317) (660 - 317) 8 ||| extractUp (Phase5.B_317 ^^^ Phase5.Y_317) (660 - 317) 8) = 255 := by decide
theorem base_cov_318 : (extractUp (Phase0.B_318 ^^^ Phase0.Y_318) (660 - 318) 8 ||| extractUp (Phase1.B_318 ^^^ Phase1.Y_318) (660 - 318) 8 ||| extractUp (Phase2.B_318 ^^^ Phase2.Y_318) (660 - 318) 8 ||| extractUp (Phase3.B_318 ^^^ Phase3.Y_318) (660 - 318) 8 ||| extractUp (Phase4.B_318 ^^^ Phase4.Y_318) (660 - 318) 8 ||| extractUp (Phase5.B_318 ^^^ Phase5.Y_318) (660 - 318) 8) = 255 := by decide
theorem base_cov_319 : (extractUp (Phase0.B_319 ^^^ Phase0.Y_319) (660 - 319) 8 ||| extractUp (Phase1.B_319 ^^^ Phase1.Y_319) (660 - 319) 8 ||| extractUp (Phase2.B_319 ^^^ Phase2.Y_319) (660 - 319) 8 ||| extractUp (Phase3.B_319 ^^^ Phase3.Y_319) (660 - 319) 8 ||| extractUp (Phase4.B_319 ^^^ Phase4.Y_319) (660 - 319) 8 ||| extractUp (Phase5.B_319 ^^^ Phase5.Y_319) (660 - 319) 8) = 255 := by decide
theorem base_cov_320 : (extractUp (Phase0.B_320 ^^^ Phase0.Y_320) (660 - 320) 8 ||| extractUp (Phase1.B_320 ^^^ Phase1.Y_320) (660 - 320) 8 ||| extractUp (Phase2.B_320 ^^^ Phase2.Y_320) (660 - 320) 8 ||| extractUp (Phase3.B_320 ^^^ Phase3.Y_320) (660 - 320) 8 ||| extractUp (Phase4.B_320 ^^^ Phase4.Y_320) (660 - 320) 8 ||| extractUp (Phase5.B_320 ^^^ Phase5.Y_320) (660 - 320) 8) = 255 := by decide
theorem base_cov_321 : (extractUp (Phase0.B_321 ^^^ Phase0.Y_321) (660 - 321) 8 ||| extractUp (Phase1.B_321 ^^^ Phase1.Y_321) (660 - 321) 8 ||| extractUp (Phase2.B_321 ^^^ Phase2.Y_321) (660 - 321) 8 ||| extractUp (Phase3.B_321 ^^^ Phase3.Y_321) (660 - 321) 8 ||| extractUp (Phase4.B_321 ^^^ Phase4.Y_321) (660 - 321) 8 ||| extractUp (Phase5.B_321 ^^^ Phase5.Y_321) (660 - 321) 8) = 255 := by decide
theorem base_cov_322 : (extractUp (Phase0.B_322 ^^^ Phase0.Y_322) (660 - 322) 8 ||| extractUp (Phase1.B_322 ^^^ Phase1.Y_322) (660 - 322) 8 ||| extractUp (Phase2.B_322 ^^^ Phase2.Y_322) (660 - 322) 8 ||| extractUp (Phase3.B_322 ^^^ Phase3.Y_322) (660 - 322) 8 ||| extractUp (Phase4.B_322 ^^^ Phase4.Y_322) (660 - 322) 8 ||| extractUp (Phase5.B_322 ^^^ Phase5.Y_322) (660 - 322) 8) = 255 := by decide
theorem base_cov_323 : (extractUp (Phase0.B_323 ^^^ Phase0.Y_323) (660 - 323) 8 ||| extractUp (Phase1.B_323 ^^^ Phase1.Y_323) (660 - 323) 8 ||| extractUp (Phase2.B_323 ^^^ Phase2.Y_323) (660 - 323) 8 ||| extractUp (Phase3.B_323 ^^^ Phase3.Y_323) (660 - 323) 8 ||| extractUp (Phase4.B_323 ^^^ Phase4.Y_323) (660 - 323) 8 ||| extractUp (Phase5.B_323 ^^^ Phase5.Y_323) (660 - 323) 8) = 255 := by decide
theorem base_cov_324 : (extractUp (Phase0.B_324 ^^^ Phase0.Y_324) (660 - 324) 8 ||| extractUp (Phase1.B_324 ^^^ Phase1.Y_324) (660 - 324) 8 ||| extractUp (Phase2.B_324 ^^^ Phase2.Y_324) (660 - 324) 8 ||| extractUp (Phase3.B_324 ^^^ Phase3.Y_324) (660 - 324) 8 ||| extractUp (Phase4.B_324 ^^^ Phase4.Y_324) (660 - 324) 8 ||| extractUp (Phase5.B_324 ^^^ Phase5.Y_324) (660 - 324) 8) = 255 := by decide
theorem base_cov_325 : (extractUp (Phase0.B_325 ^^^ Phase0.Y_325) (660 - 325) 8 ||| extractUp (Phase1.B_325 ^^^ Phase1.Y_325) (660 - 325) 8 ||| extractUp (Phase2.B_325 ^^^ Phase2.Y_325) (660 - 325) 8 ||| extractUp (Phase3.B_325 ^^^ Phase3.Y_325) (660 - 325) 8 ||| extractUp (Phase4.B_325 ^^^ Phase4.Y_325) (660 - 325) 8 ||| extractUp (Phase5.B_325 ^^^ Phase5.Y_325) (660 - 325) 8) = 255 := by decide
theorem base_cov_326 : (extractUp (Phase0.B_326 ^^^ Phase0.Y_326) (660 - 326) 8 ||| extractUp (Phase1.B_326 ^^^ Phase1.Y_326) (660 - 326) 8 ||| extractUp (Phase2.B_326 ^^^ Phase2.Y_326) (660 - 326) 8 ||| extractUp (Phase3.B_326 ^^^ Phase3.Y_326) (660 - 326) 8 ||| extractUp (Phase4.B_326 ^^^ Phase4.Y_326) (660 - 326) 8 ||| extractUp (Phase5.B_326 ^^^ Phase5.Y_326) (660 - 326) 8) = 255 := by decide
theorem base_cov_327 : (extractUp (Phase0.B_327 ^^^ Phase0.Y_327) (660 - 327) 8 ||| extractUp (Phase1.B_327 ^^^ Phase1.Y_327) (660 - 327) 8 ||| extractUp (Phase2.B_327 ^^^ Phase2.Y_327) (660 - 327) 8 ||| extractUp (Phase3.B_327 ^^^ Phase3.Y_327) (660 - 327) 8 ||| extractUp (Phase4.B_327 ^^^ Phase4.Y_327) (660 - 327) 8 ||| extractUp (Phase5.B_327 ^^^ Phase5.Y_327) (660 - 327) 8) = 255 := by decide
theorem base_cov_328 : (extractUp (Phase0.B_328 ^^^ Phase0.Y_328) (660 - 328) 8 ||| extractUp (Phase1.B_328 ^^^ Phase1.Y_328) (660 - 328) 8 ||| extractUp (Phase2.B_328 ^^^ Phase2.Y_328) (660 - 328) 8 ||| extractUp (Phase3.B_328 ^^^ Phase3.Y_328) (660 - 328) 8 ||| extractUp (Phase4.B_328 ^^^ Phase4.Y_328) (660 - 328) 8 ||| extractUp (Phase5.B_328 ^^^ Phase5.Y_328) (660 - 328) 8) = 255 := by decide
theorem base_cov_329 : (extractUp (Phase0.B_329 ^^^ Phase0.Y_329) (660 - 329) 8 ||| extractUp (Phase1.B_329 ^^^ Phase1.Y_329) (660 - 329) 8 ||| extractUp (Phase2.B_329 ^^^ Phase2.Y_329) (660 - 329) 8 ||| extractUp (Phase3.B_329 ^^^ Phase3.Y_329) (660 - 329) 8 ||| extractUp (Phase4.B_329 ^^^ Phase4.Y_329) (660 - 329) 8 ||| extractUp (Phase5.B_329 ^^^ Phase5.Y_329) (660 - 329) 8) = 255 := by decide
theorem base_cov_330 : (extractUp (Phase0.B_330 ^^^ Phase0.Y_330) (660 - 330) 8 ||| extractUp (Phase1.B_330 ^^^ Phase1.Y_330) (660 - 330) 8 ||| extractUp (Phase2.B_330 ^^^ Phase2.Y_330) (660 - 330) 8 ||| extractUp (Phase3.B_330 ^^^ Phase3.Y_330) (660 - 330) 8 ||| extractUp (Phase4.B_330 ^^^ Phase4.Y_330) (660 - 330) 8 ||| extractUp (Phase5.B_330 ^^^ Phase5.Y_330) (660 - 330) 8) = 255 := by decide
theorem base_cov_331 : (extractUp (Phase0.B_331 ^^^ Phase0.Y_331) (660 - 331) 8 ||| extractUp (Phase1.B_331 ^^^ Phase1.Y_331) (660 - 331) 8 ||| extractUp (Phase2.B_331 ^^^ Phase2.Y_331) (660 - 331) 8 ||| extractUp (Phase3.B_331 ^^^ Phase3.Y_331) (660 - 331) 8 ||| extractUp (Phase4.B_331 ^^^ Phase4.Y_331) (660 - 331) 8 ||| extractUp (Phase5.B_331 ^^^ Phase5.Y_331) (660 - 331) 8) = 255 := by decide
theorem base_cov_332 : (extractUp (Phase0.B_332 ^^^ Phase0.Y_332) (660 - 332) 8 ||| extractUp (Phase1.B_332 ^^^ Phase1.Y_332) (660 - 332) 8 ||| extractUp (Phase2.B_332 ^^^ Phase2.Y_332) (660 - 332) 8 ||| extractUp (Phase3.B_332 ^^^ Phase3.Y_332) (660 - 332) 8 ||| extractUp (Phase4.B_332 ^^^ Phase4.Y_332) (660 - 332) 8 ||| extractUp (Phase5.B_332 ^^^ Phase5.Y_332) (660 - 332) 8) = 255 := by decide
theorem base_cov_333 : (extractUp (Phase0.B_333 ^^^ Phase0.Y_333) (660 - 333) 8 ||| extractUp (Phase1.B_333 ^^^ Phase1.Y_333) (660 - 333) 8 ||| extractUp (Phase2.B_333 ^^^ Phase2.Y_333) (660 - 333) 8 ||| extractUp (Phase3.B_333 ^^^ Phase3.Y_333) (660 - 333) 8 ||| extractUp (Phase4.B_333 ^^^ Phase4.Y_333) (660 - 333) 8 ||| extractUp (Phase5.B_333 ^^^ Phase5.Y_333) (660 - 333) 8) = 255 := by decide
theorem base_cov_334 : (extractUp (Phase0.B_334 ^^^ Phase0.Y_334) (660 - 334) 8 ||| extractUp (Phase1.B_334 ^^^ Phase1.Y_334) (660 - 334) 8 ||| extractUp (Phase2.B_334 ^^^ Phase2.Y_334) (660 - 334) 8 ||| extractUp (Phase3.B_334 ^^^ Phase3.Y_334) (660 - 334) 8 ||| extractUp (Phase4.B_334 ^^^ Phase4.Y_334) (660 - 334) 8 ||| extractUp (Phase5.B_334 ^^^ Phase5.Y_334) (660 - 334) 8) = 255 := by decide
theorem base_cov_335 : (extractUp (Phase0.B_335 ^^^ Phase0.Y_335) (660 - 335) 8 ||| extractUp (Phase1.B_335 ^^^ Phase1.Y_335) (660 - 335) 8 ||| extractUp (Phase2.B_335 ^^^ Phase2.Y_335) (660 - 335) 8 ||| extractUp (Phase3.B_335 ^^^ Phase3.Y_335) (660 - 335) 8 ||| extractUp (Phase4.B_335 ^^^ Phase4.Y_335) (660 - 335) 8 ||| extractUp (Phase5.B_335 ^^^ Phase5.Y_335) (660 - 335) 8) = 255 := by decide
theorem base_cov_336 : (extractUp (Phase0.B_336 ^^^ Phase0.Y_336) (660 - 336) 8 ||| extractUp (Phase1.B_336 ^^^ Phase1.Y_336) (660 - 336) 8 ||| extractUp (Phase2.B_336 ^^^ Phase2.Y_336) (660 - 336) 8 ||| extractUp (Phase3.B_336 ^^^ Phase3.Y_336) (660 - 336) 8 ||| extractUp (Phase4.B_336 ^^^ Phase4.Y_336) (660 - 336) 8 ||| extractUp (Phase5.B_336 ^^^ Phase5.Y_336) (660 - 336) 8) = 255 := by decide
theorem base_cov_337 : (extractUp (Phase0.B_337 ^^^ Phase0.Y_337) (660 - 337) 8 ||| extractUp (Phase1.B_337 ^^^ Phase1.Y_337) (660 - 337) 8 ||| extractUp (Phase2.B_337 ^^^ Phase2.Y_337) (660 - 337) 8 ||| extractUp (Phase3.B_337 ^^^ Phase3.Y_337) (660 - 337) 8 ||| extractUp (Phase4.B_337 ^^^ Phase4.Y_337) (660 - 337) 8 ||| extractUp (Phase5.B_337 ^^^ Phase5.Y_337) (660 - 337) 8) = 255 := by decide
theorem base_cov_338 : (extractUp (Phase0.B_338 ^^^ Phase0.Y_338) (660 - 338) 8 ||| extractUp (Phase1.B_338 ^^^ Phase1.Y_338) (660 - 338) 8 ||| extractUp (Phase2.B_338 ^^^ Phase2.Y_338) (660 - 338) 8 ||| extractUp (Phase3.B_338 ^^^ Phase3.Y_338) (660 - 338) 8 ||| extractUp (Phase4.B_338 ^^^ Phase4.Y_338) (660 - 338) 8 ||| extractUp (Phase5.B_338 ^^^ Phase5.Y_338) (660 - 338) 8) = 255 := by decide
theorem base_cov_339 : (extractUp (Phase0.B_339 ^^^ Phase0.Y_339) (660 - 339) 8 ||| extractUp (Phase1.B_339 ^^^ Phase1.Y_339) (660 - 339) 8 ||| extractUp (Phase2.B_339 ^^^ Phase2.Y_339) (660 - 339) 8 ||| extractUp (Phase3.B_339 ^^^ Phase3.Y_339) (660 - 339) 8 ||| extractUp (Phase4.B_339 ^^^ Phase4.Y_339) (660 - 339) 8 ||| extractUp (Phase5.B_339 ^^^ Phase5.Y_339) (660 - 339) 8) = 255 := by decide

theorem coverage_300 (k : Nat) (hk : k < 8) :
    ∃ u : RingBV, Repeats rightPos 8 40 u ∧ Differs u 300 (rightPos 300 k) := by
  have full : (255 : Nat).testBit k = true := by
    change (2 ^ 8 - 1 : Nat).testBit k = true
    exact (Nat.testBit_two_pow_sub_one 8 k).trans (decide_eq_true hk)
  have h := congrArg (fun bits : Nat => bits.testBit k) base_cov_300
  simp only [full, Nat.testBit_or, Bool.or_eq_true] at h
  rcases h with (((((h0 | h1) | h2) | h3) | h4) | h5)
  · exact ⟨initRingBV Phase0.word Phase0.ph, Phase0.repeats,
      rightDiff_from_row _ _ _ 300 k (by decide) (by decide) hk
        Phase0.evolve_B_300 Phase0.evolve_Y_300 h0⟩
  · exact ⟨initRingBV Phase1.word Phase1.ph, Phase1.repeats,
      rightDiff_from_row _ _ _ 300 k (by decide) (by decide) hk
        Phase1.evolve_B_300 Phase1.evolve_Y_300 h1⟩
  · exact ⟨initRingBV Phase2.word Phase2.ph, Phase2.repeats,
      rightDiff_from_row _ _ _ 300 k (by decide) (by decide) hk
        Phase2.evolve_B_300 Phase2.evolve_Y_300 h2⟩
  · exact ⟨initRingBV Phase3.word Phase3.ph, Phase3.repeats,
      rightDiff_from_row _ _ _ 300 k (by decide) (by decide) hk
        Phase3.evolve_B_300 Phase3.evolve_Y_300 h3⟩
  · exact ⟨initRingBV Phase4.word Phase4.ph, Phase4.repeats,
      rightDiff_from_row _ _ _ 300 k (by decide) (by decide) hk
        Phase4.evolve_B_300 Phase4.evolve_Y_300 h4⟩
  · exact ⟨initRingBV Phase5.word Phase5.ph, Phase5.repeats,
      rightDiff_from_row _ _ _ 300 k (by decide) (by decide) hk
        Phase5.evolve_B_300 Phase5.evolve_Y_300 h5⟩

theorem coverage_301 (k : Nat) (hk : k < 8) :
    ∃ u : RingBV, Repeats rightPos 8 40 u ∧ Differs u 301 (rightPos 301 k) := by
  have full : (255 : Nat).testBit k = true := by
    change (2 ^ 8 - 1 : Nat).testBit k = true
    exact (Nat.testBit_two_pow_sub_one 8 k).trans (decide_eq_true hk)
  have h := congrArg (fun bits : Nat => bits.testBit k) base_cov_301
  simp only [full, Nat.testBit_or, Bool.or_eq_true] at h
  rcases h with (((((h0 | h1) | h2) | h3) | h4) | h5)
  · exact ⟨initRingBV Phase0.word Phase0.ph, Phase0.repeats,
      rightDiff_from_row _ _ _ 301 k (by decide) (by decide) hk
        Phase0.evolve_B_301 Phase0.evolve_Y_301 h0⟩
  · exact ⟨initRingBV Phase1.word Phase1.ph, Phase1.repeats,
      rightDiff_from_row _ _ _ 301 k (by decide) (by decide) hk
        Phase1.evolve_B_301 Phase1.evolve_Y_301 h1⟩
  · exact ⟨initRingBV Phase2.word Phase2.ph, Phase2.repeats,
      rightDiff_from_row _ _ _ 301 k (by decide) (by decide) hk
        Phase2.evolve_B_301 Phase2.evolve_Y_301 h2⟩
  · exact ⟨initRingBV Phase3.word Phase3.ph, Phase3.repeats,
      rightDiff_from_row _ _ _ 301 k (by decide) (by decide) hk
        Phase3.evolve_B_301 Phase3.evolve_Y_301 h3⟩
  · exact ⟨initRingBV Phase4.word Phase4.ph, Phase4.repeats,
      rightDiff_from_row _ _ _ 301 k (by decide) (by decide) hk
        Phase4.evolve_B_301 Phase4.evolve_Y_301 h4⟩
  · exact ⟨initRingBV Phase5.word Phase5.ph, Phase5.repeats,
      rightDiff_from_row _ _ _ 301 k (by decide) (by decide) hk
        Phase5.evolve_B_301 Phase5.evolve_Y_301 h5⟩

theorem coverage_302 (k : Nat) (hk : k < 8) :
    ∃ u : RingBV, Repeats rightPos 8 40 u ∧ Differs u 302 (rightPos 302 k) := by
  have full : (255 : Nat).testBit k = true := by
    change (2 ^ 8 - 1 : Nat).testBit k = true
    exact (Nat.testBit_two_pow_sub_one 8 k).trans (decide_eq_true hk)
  have h := congrArg (fun bits : Nat => bits.testBit k) base_cov_302
  simp only [full, Nat.testBit_or, Bool.or_eq_true] at h
  rcases h with (((((h0 | h1) | h2) | h3) | h4) | h5)
  · exact ⟨initRingBV Phase0.word Phase0.ph, Phase0.repeats,
      rightDiff_from_row _ _ _ 302 k (by decide) (by decide) hk
        Phase0.evolve_B_302 Phase0.evolve_Y_302 h0⟩
  · exact ⟨initRingBV Phase1.word Phase1.ph, Phase1.repeats,
      rightDiff_from_row _ _ _ 302 k (by decide) (by decide) hk
        Phase1.evolve_B_302 Phase1.evolve_Y_302 h1⟩
  · exact ⟨initRingBV Phase2.word Phase2.ph, Phase2.repeats,
      rightDiff_from_row _ _ _ 302 k (by decide) (by decide) hk
        Phase2.evolve_B_302 Phase2.evolve_Y_302 h2⟩
  · exact ⟨initRingBV Phase3.word Phase3.ph, Phase3.repeats,
      rightDiff_from_row _ _ _ 302 k (by decide) (by decide) hk
        Phase3.evolve_B_302 Phase3.evolve_Y_302 h3⟩
  · exact ⟨initRingBV Phase4.word Phase4.ph, Phase4.repeats,
      rightDiff_from_row _ _ _ 302 k (by decide) (by decide) hk
        Phase4.evolve_B_302 Phase4.evolve_Y_302 h4⟩
  · exact ⟨initRingBV Phase5.word Phase5.ph, Phase5.repeats,
      rightDiff_from_row _ _ _ 302 k (by decide) (by decide) hk
        Phase5.evolve_B_302 Phase5.evolve_Y_302 h5⟩

theorem coverage_303 (k : Nat) (hk : k < 8) :
    ∃ u : RingBV, Repeats rightPos 8 40 u ∧ Differs u 303 (rightPos 303 k) := by
  have full : (255 : Nat).testBit k = true := by
    change (2 ^ 8 - 1 : Nat).testBit k = true
    exact (Nat.testBit_two_pow_sub_one 8 k).trans (decide_eq_true hk)
  have h := congrArg (fun bits : Nat => bits.testBit k) base_cov_303
  simp only [full, Nat.testBit_or, Bool.or_eq_true] at h
  rcases h with (((((h0 | h1) | h2) | h3) | h4) | h5)
  · exact ⟨initRingBV Phase0.word Phase0.ph, Phase0.repeats,
      rightDiff_from_row _ _ _ 303 k (by decide) (by decide) hk
        Phase0.evolve_B_303 Phase0.evolve_Y_303 h0⟩
  · exact ⟨initRingBV Phase1.word Phase1.ph, Phase1.repeats,
      rightDiff_from_row _ _ _ 303 k (by decide) (by decide) hk
        Phase1.evolve_B_303 Phase1.evolve_Y_303 h1⟩
  · exact ⟨initRingBV Phase2.word Phase2.ph, Phase2.repeats,
      rightDiff_from_row _ _ _ 303 k (by decide) (by decide) hk
        Phase2.evolve_B_303 Phase2.evolve_Y_303 h2⟩
  · exact ⟨initRingBV Phase3.word Phase3.ph, Phase3.repeats,
      rightDiff_from_row _ _ _ 303 k (by decide) (by decide) hk
        Phase3.evolve_B_303 Phase3.evolve_Y_303 h3⟩
  · exact ⟨initRingBV Phase4.word Phase4.ph, Phase4.repeats,
      rightDiff_from_row _ _ _ 303 k (by decide) (by decide) hk
        Phase4.evolve_B_303 Phase4.evolve_Y_303 h4⟩
  · exact ⟨initRingBV Phase5.word Phase5.ph, Phase5.repeats,
      rightDiff_from_row _ _ _ 303 k (by decide) (by decide) hk
        Phase5.evolve_B_303 Phase5.evolve_Y_303 h5⟩

theorem coverage_304 (k : Nat) (hk : k < 8) :
    ∃ u : RingBV, Repeats rightPos 8 40 u ∧ Differs u 304 (rightPos 304 k) := by
  have full : (255 : Nat).testBit k = true := by
    change (2 ^ 8 - 1 : Nat).testBit k = true
    exact (Nat.testBit_two_pow_sub_one 8 k).trans (decide_eq_true hk)
  have h := congrArg (fun bits : Nat => bits.testBit k) base_cov_304
  simp only [full, Nat.testBit_or, Bool.or_eq_true] at h
  rcases h with (((((h0 | h1) | h2) | h3) | h4) | h5)
  · exact ⟨initRingBV Phase0.word Phase0.ph, Phase0.repeats,
      rightDiff_from_row _ _ _ 304 k (by decide) (by decide) hk
        Phase0.evolve_B_304 Phase0.evolve_Y_304 h0⟩
  · exact ⟨initRingBV Phase1.word Phase1.ph, Phase1.repeats,
      rightDiff_from_row _ _ _ 304 k (by decide) (by decide) hk
        Phase1.evolve_B_304 Phase1.evolve_Y_304 h1⟩
  · exact ⟨initRingBV Phase2.word Phase2.ph, Phase2.repeats,
      rightDiff_from_row _ _ _ 304 k (by decide) (by decide) hk
        Phase2.evolve_B_304 Phase2.evolve_Y_304 h2⟩
  · exact ⟨initRingBV Phase3.word Phase3.ph, Phase3.repeats,
      rightDiff_from_row _ _ _ 304 k (by decide) (by decide) hk
        Phase3.evolve_B_304 Phase3.evolve_Y_304 h3⟩
  · exact ⟨initRingBV Phase4.word Phase4.ph, Phase4.repeats,
      rightDiff_from_row _ _ _ 304 k (by decide) (by decide) hk
        Phase4.evolve_B_304 Phase4.evolve_Y_304 h4⟩
  · exact ⟨initRingBV Phase5.word Phase5.ph, Phase5.repeats,
      rightDiff_from_row _ _ _ 304 k (by decide) (by decide) hk
        Phase5.evolve_B_304 Phase5.evolve_Y_304 h5⟩

theorem coverage_305 (k : Nat) (hk : k < 8) :
    ∃ u : RingBV, Repeats rightPos 8 40 u ∧ Differs u 305 (rightPos 305 k) := by
  have full : (255 : Nat).testBit k = true := by
    change (2 ^ 8 - 1 : Nat).testBit k = true
    exact (Nat.testBit_two_pow_sub_one 8 k).trans (decide_eq_true hk)
  have h := congrArg (fun bits : Nat => bits.testBit k) base_cov_305
  simp only [full, Nat.testBit_or, Bool.or_eq_true] at h
  rcases h with (((((h0 | h1) | h2) | h3) | h4) | h5)
  · exact ⟨initRingBV Phase0.word Phase0.ph, Phase0.repeats,
      rightDiff_from_row _ _ _ 305 k (by decide) (by decide) hk
        Phase0.evolve_B_305 Phase0.evolve_Y_305 h0⟩
  · exact ⟨initRingBV Phase1.word Phase1.ph, Phase1.repeats,
      rightDiff_from_row _ _ _ 305 k (by decide) (by decide) hk
        Phase1.evolve_B_305 Phase1.evolve_Y_305 h1⟩
  · exact ⟨initRingBV Phase2.word Phase2.ph, Phase2.repeats,
      rightDiff_from_row _ _ _ 305 k (by decide) (by decide) hk
        Phase2.evolve_B_305 Phase2.evolve_Y_305 h2⟩
  · exact ⟨initRingBV Phase3.word Phase3.ph, Phase3.repeats,
      rightDiff_from_row _ _ _ 305 k (by decide) (by decide) hk
        Phase3.evolve_B_305 Phase3.evolve_Y_305 h3⟩
  · exact ⟨initRingBV Phase4.word Phase4.ph, Phase4.repeats,
      rightDiff_from_row _ _ _ 305 k (by decide) (by decide) hk
        Phase4.evolve_B_305 Phase4.evolve_Y_305 h4⟩
  · exact ⟨initRingBV Phase5.word Phase5.ph, Phase5.repeats,
      rightDiff_from_row _ _ _ 305 k (by decide) (by decide) hk
        Phase5.evolve_B_305 Phase5.evolve_Y_305 h5⟩

theorem coverage_306 (k : Nat) (hk : k < 8) :
    ∃ u : RingBV, Repeats rightPos 8 40 u ∧ Differs u 306 (rightPos 306 k) := by
  have full : (255 : Nat).testBit k = true := by
    change (2 ^ 8 - 1 : Nat).testBit k = true
    exact (Nat.testBit_two_pow_sub_one 8 k).trans (decide_eq_true hk)
  have h := congrArg (fun bits : Nat => bits.testBit k) base_cov_306
  simp only [full, Nat.testBit_or, Bool.or_eq_true] at h
  rcases h with (((((h0 | h1) | h2) | h3) | h4) | h5)
  · exact ⟨initRingBV Phase0.word Phase0.ph, Phase0.repeats,
      rightDiff_from_row _ _ _ 306 k (by decide) (by decide) hk
        Phase0.evolve_B_306 Phase0.evolve_Y_306 h0⟩
  · exact ⟨initRingBV Phase1.word Phase1.ph, Phase1.repeats,
      rightDiff_from_row _ _ _ 306 k (by decide) (by decide) hk
        Phase1.evolve_B_306 Phase1.evolve_Y_306 h1⟩
  · exact ⟨initRingBV Phase2.word Phase2.ph, Phase2.repeats,
      rightDiff_from_row _ _ _ 306 k (by decide) (by decide) hk
        Phase2.evolve_B_306 Phase2.evolve_Y_306 h2⟩
  · exact ⟨initRingBV Phase3.word Phase3.ph, Phase3.repeats,
      rightDiff_from_row _ _ _ 306 k (by decide) (by decide) hk
        Phase3.evolve_B_306 Phase3.evolve_Y_306 h3⟩
  · exact ⟨initRingBV Phase4.word Phase4.ph, Phase4.repeats,
      rightDiff_from_row _ _ _ 306 k (by decide) (by decide) hk
        Phase4.evolve_B_306 Phase4.evolve_Y_306 h4⟩
  · exact ⟨initRingBV Phase5.word Phase5.ph, Phase5.repeats,
      rightDiff_from_row _ _ _ 306 k (by decide) (by decide) hk
        Phase5.evolve_B_306 Phase5.evolve_Y_306 h5⟩

theorem coverage_307 (k : Nat) (hk : k < 8) :
    ∃ u : RingBV, Repeats rightPos 8 40 u ∧ Differs u 307 (rightPos 307 k) := by
  have full : (255 : Nat).testBit k = true := by
    change (2 ^ 8 - 1 : Nat).testBit k = true
    exact (Nat.testBit_two_pow_sub_one 8 k).trans (decide_eq_true hk)
  have h := congrArg (fun bits : Nat => bits.testBit k) base_cov_307
  simp only [full, Nat.testBit_or, Bool.or_eq_true] at h
  rcases h with (((((h0 | h1) | h2) | h3) | h4) | h5)
  · exact ⟨initRingBV Phase0.word Phase0.ph, Phase0.repeats,
      rightDiff_from_row _ _ _ 307 k (by decide) (by decide) hk
        Phase0.evolve_B_307 Phase0.evolve_Y_307 h0⟩
  · exact ⟨initRingBV Phase1.word Phase1.ph, Phase1.repeats,
      rightDiff_from_row _ _ _ 307 k (by decide) (by decide) hk
        Phase1.evolve_B_307 Phase1.evolve_Y_307 h1⟩
  · exact ⟨initRingBV Phase2.word Phase2.ph, Phase2.repeats,
      rightDiff_from_row _ _ _ 307 k (by decide) (by decide) hk
        Phase2.evolve_B_307 Phase2.evolve_Y_307 h2⟩
  · exact ⟨initRingBV Phase3.word Phase3.ph, Phase3.repeats,
      rightDiff_from_row _ _ _ 307 k (by decide) (by decide) hk
        Phase3.evolve_B_307 Phase3.evolve_Y_307 h3⟩
  · exact ⟨initRingBV Phase4.word Phase4.ph, Phase4.repeats,
      rightDiff_from_row _ _ _ 307 k (by decide) (by decide) hk
        Phase4.evolve_B_307 Phase4.evolve_Y_307 h4⟩
  · exact ⟨initRingBV Phase5.word Phase5.ph, Phase5.repeats,
      rightDiff_from_row _ _ _ 307 k (by decide) (by decide) hk
        Phase5.evolve_B_307 Phase5.evolve_Y_307 h5⟩

theorem coverage_308 (k : Nat) (hk : k < 8) :
    ∃ u : RingBV, Repeats rightPos 8 40 u ∧ Differs u 308 (rightPos 308 k) := by
  have full : (255 : Nat).testBit k = true := by
    change (2 ^ 8 - 1 : Nat).testBit k = true
    exact (Nat.testBit_two_pow_sub_one 8 k).trans (decide_eq_true hk)
  have h := congrArg (fun bits : Nat => bits.testBit k) base_cov_308
  simp only [full, Nat.testBit_or, Bool.or_eq_true] at h
  rcases h with (((((h0 | h1) | h2) | h3) | h4) | h5)
  · exact ⟨initRingBV Phase0.word Phase0.ph, Phase0.repeats,
      rightDiff_from_row _ _ _ 308 k (by decide) (by decide) hk
        Phase0.evolve_B_308 Phase0.evolve_Y_308 h0⟩
  · exact ⟨initRingBV Phase1.word Phase1.ph, Phase1.repeats,
      rightDiff_from_row _ _ _ 308 k (by decide) (by decide) hk
        Phase1.evolve_B_308 Phase1.evolve_Y_308 h1⟩
  · exact ⟨initRingBV Phase2.word Phase2.ph, Phase2.repeats,
      rightDiff_from_row _ _ _ 308 k (by decide) (by decide) hk
        Phase2.evolve_B_308 Phase2.evolve_Y_308 h2⟩
  · exact ⟨initRingBV Phase3.word Phase3.ph, Phase3.repeats,
      rightDiff_from_row _ _ _ 308 k (by decide) (by decide) hk
        Phase3.evolve_B_308 Phase3.evolve_Y_308 h3⟩
  · exact ⟨initRingBV Phase4.word Phase4.ph, Phase4.repeats,
      rightDiff_from_row _ _ _ 308 k (by decide) (by decide) hk
        Phase4.evolve_B_308 Phase4.evolve_Y_308 h4⟩
  · exact ⟨initRingBV Phase5.word Phase5.ph, Phase5.repeats,
      rightDiff_from_row _ _ _ 308 k (by decide) (by decide) hk
        Phase5.evolve_B_308 Phase5.evolve_Y_308 h5⟩

theorem coverage_309 (k : Nat) (hk : k < 8) :
    ∃ u : RingBV, Repeats rightPos 8 40 u ∧ Differs u 309 (rightPos 309 k) := by
  have full : (255 : Nat).testBit k = true := by
    change (2 ^ 8 - 1 : Nat).testBit k = true
    exact (Nat.testBit_two_pow_sub_one 8 k).trans (decide_eq_true hk)
  have h := congrArg (fun bits : Nat => bits.testBit k) base_cov_309
  simp only [full, Nat.testBit_or, Bool.or_eq_true] at h
  rcases h with (((((h0 | h1) | h2) | h3) | h4) | h5)
  · exact ⟨initRingBV Phase0.word Phase0.ph, Phase0.repeats,
      rightDiff_from_row _ _ _ 309 k (by decide) (by decide) hk
        Phase0.evolve_B_309 Phase0.evolve_Y_309 h0⟩
  · exact ⟨initRingBV Phase1.word Phase1.ph, Phase1.repeats,
      rightDiff_from_row _ _ _ 309 k (by decide) (by decide) hk
        Phase1.evolve_B_309 Phase1.evolve_Y_309 h1⟩
  · exact ⟨initRingBV Phase2.word Phase2.ph, Phase2.repeats,
      rightDiff_from_row _ _ _ 309 k (by decide) (by decide) hk
        Phase2.evolve_B_309 Phase2.evolve_Y_309 h2⟩
  · exact ⟨initRingBV Phase3.word Phase3.ph, Phase3.repeats,
      rightDiff_from_row _ _ _ 309 k (by decide) (by decide) hk
        Phase3.evolve_B_309 Phase3.evolve_Y_309 h3⟩
  · exact ⟨initRingBV Phase4.word Phase4.ph, Phase4.repeats,
      rightDiff_from_row _ _ _ 309 k (by decide) (by decide) hk
        Phase4.evolve_B_309 Phase4.evolve_Y_309 h4⟩
  · exact ⟨initRingBV Phase5.word Phase5.ph, Phase5.repeats,
      rightDiff_from_row _ _ _ 309 k (by decide) (by decide) hk
        Phase5.evolve_B_309 Phase5.evolve_Y_309 h5⟩

theorem coverage_310 (k : Nat) (hk : k < 8) :
    ∃ u : RingBV, Repeats rightPos 8 40 u ∧ Differs u 310 (rightPos 310 k) := by
  have full : (255 : Nat).testBit k = true := by
    change (2 ^ 8 - 1 : Nat).testBit k = true
    exact (Nat.testBit_two_pow_sub_one 8 k).trans (decide_eq_true hk)
  have h := congrArg (fun bits : Nat => bits.testBit k) base_cov_310
  simp only [full, Nat.testBit_or, Bool.or_eq_true] at h
  rcases h with (((((h0 | h1) | h2) | h3) | h4) | h5)
  · exact ⟨initRingBV Phase0.word Phase0.ph, Phase0.repeats,
      rightDiff_from_row _ _ _ 310 k (by decide) (by decide) hk
        Phase0.evolve_B_310 Phase0.evolve_Y_310 h0⟩
  · exact ⟨initRingBV Phase1.word Phase1.ph, Phase1.repeats,
      rightDiff_from_row _ _ _ 310 k (by decide) (by decide) hk
        Phase1.evolve_B_310 Phase1.evolve_Y_310 h1⟩
  · exact ⟨initRingBV Phase2.word Phase2.ph, Phase2.repeats,
      rightDiff_from_row _ _ _ 310 k (by decide) (by decide) hk
        Phase2.evolve_B_310 Phase2.evolve_Y_310 h2⟩
  · exact ⟨initRingBV Phase3.word Phase3.ph, Phase3.repeats,
      rightDiff_from_row _ _ _ 310 k (by decide) (by decide) hk
        Phase3.evolve_B_310 Phase3.evolve_Y_310 h3⟩
  · exact ⟨initRingBV Phase4.word Phase4.ph, Phase4.repeats,
      rightDiff_from_row _ _ _ 310 k (by decide) (by decide) hk
        Phase4.evolve_B_310 Phase4.evolve_Y_310 h4⟩
  · exact ⟨initRingBV Phase5.word Phase5.ph, Phase5.repeats,
      rightDiff_from_row _ _ _ 310 k (by decide) (by decide) hk
        Phase5.evolve_B_310 Phase5.evolve_Y_310 h5⟩

theorem coverage_311 (k : Nat) (hk : k < 8) :
    ∃ u : RingBV, Repeats rightPos 8 40 u ∧ Differs u 311 (rightPos 311 k) := by
  have full : (255 : Nat).testBit k = true := by
    change (2 ^ 8 - 1 : Nat).testBit k = true
    exact (Nat.testBit_two_pow_sub_one 8 k).trans (decide_eq_true hk)
  have h := congrArg (fun bits : Nat => bits.testBit k) base_cov_311
  simp only [full, Nat.testBit_or, Bool.or_eq_true] at h
  rcases h with (((((h0 | h1) | h2) | h3) | h4) | h5)
  · exact ⟨initRingBV Phase0.word Phase0.ph, Phase0.repeats,
      rightDiff_from_row _ _ _ 311 k (by decide) (by decide) hk
        Phase0.evolve_B_311 Phase0.evolve_Y_311 h0⟩
  · exact ⟨initRingBV Phase1.word Phase1.ph, Phase1.repeats,
      rightDiff_from_row _ _ _ 311 k (by decide) (by decide) hk
        Phase1.evolve_B_311 Phase1.evolve_Y_311 h1⟩
  · exact ⟨initRingBV Phase2.word Phase2.ph, Phase2.repeats,
      rightDiff_from_row _ _ _ 311 k (by decide) (by decide) hk
        Phase2.evolve_B_311 Phase2.evolve_Y_311 h2⟩
  · exact ⟨initRingBV Phase3.word Phase3.ph, Phase3.repeats,
      rightDiff_from_row _ _ _ 311 k (by decide) (by decide) hk
        Phase3.evolve_B_311 Phase3.evolve_Y_311 h3⟩
  · exact ⟨initRingBV Phase4.word Phase4.ph, Phase4.repeats,
      rightDiff_from_row _ _ _ 311 k (by decide) (by decide) hk
        Phase4.evolve_B_311 Phase4.evolve_Y_311 h4⟩
  · exact ⟨initRingBV Phase5.word Phase5.ph, Phase5.repeats,
      rightDiff_from_row _ _ _ 311 k (by decide) (by decide) hk
        Phase5.evolve_B_311 Phase5.evolve_Y_311 h5⟩

theorem coverage_312 (k : Nat) (hk : k < 8) :
    ∃ u : RingBV, Repeats rightPos 8 40 u ∧ Differs u 312 (rightPos 312 k) := by
  have full : (255 : Nat).testBit k = true := by
    change (2 ^ 8 - 1 : Nat).testBit k = true
    exact (Nat.testBit_two_pow_sub_one 8 k).trans (decide_eq_true hk)
  have h := congrArg (fun bits : Nat => bits.testBit k) base_cov_312
  simp only [full, Nat.testBit_or, Bool.or_eq_true] at h
  rcases h with (((((h0 | h1) | h2) | h3) | h4) | h5)
  · exact ⟨initRingBV Phase0.word Phase0.ph, Phase0.repeats,
      rightDiff_from_row _ _ _ 312 k (by decide) (by decide) hk
        Phase0.evolve_B_312 Phase0.evolve_Y_312 h0⟩
  · exact ⟨initRingBV Phase1.word Phase1.ph, Phase1.repeats,
      rightDiff_from_row _ _ _ 312 k (by decide) (by decide) hk
        Phase1.evolve_B_312 Phase1.evolve_Y_312 h1⟩
  · exact ⟨initRingBV Phase2.word Phase2.ph, Phase2.repeats,
      rightDiff_from_row _ _ _ 312 k (by decide) (by decide) hk
        Phase2.evolve_B_312 Phase2.evolve_Y_312 h2⟩
  · exact ⟨initRingBV Phase3.word Phase3.ph, Phase3.repeats,
      rightDiff_from_row _ _ _ 312 k (by decide) (by decide) hk
        Phase3.evolve_B_312 Phase3.evolve_Y_312 h3⟩
  · exact ⟨initRingBV Phase4.word Phase4.ph, Phase4.repeats,
      rightDiff_from_row _ _ _ 312 k (by decide) (by decide) hk
        Phase4.evolve_B_312 Phase4.evolve_Y_312 h4⟩
  · exact ⟨initRingBV Phase5.word Phase5.ph, Phase5.repeats,
      rightDiff_from_row _ _ _ 312 k (by decide) (by decide) hk
        Phase5.evolve_B_312 Phase5.evolve_Y_312 h5⟩

theorem coverage_313 (k : Nat) (hk : k < 8) :
    ∃ u : RingBV, Repeats rightPos 8 40 u ∧ Differs u 313 (rightPos 313 k) := by
  have full : (255 : Nat).testBit k = true := by
    change (2 ^ 8 - 1 : Nat).testBit k = true
    exact (Nat.testBit_two_pow_sub_one 8 k).trans (decide_eq_true hk)
  have h := congrArg (fun bits : Nat => bits.testBit k) base_cov_313
  simp only [full, Nat.testBit_or, Bool.or_eq_true] at h
  rcases h with (((((h0 | h1) | h2) | h3) | h4) | h5)
  · exact ⟨initRingBV Phase0.word Phase0.ph, Phase0.repeats,
      rightDiff_from_row _ _ _ 313 k (by decide) (by decide) hk
        Phase0.evolve_B_313 Phase0.evolve_Y_313 h0⟩
  · exact ⟨initRingBV Phase1.word Phase1.ph, Phase1.repeats,
      rightDiff_from_row _ _ _ 313 k (by decide) (by decide) hk
        Phase1.evolve_B_313 Phase1.evolve_Y_313 h1⟩
  · exact ⟨initRingBV Phase2.word Phase2.ph, Phase2.repeats,
      rightDiff_from_row _ _ _ 313 k (by decide) (by decide) hk
        Phase2.evolve_B_313 Phase2.evolve_Y_313 h2⟩
  · exact ⟨initRingBV Phase3.word Phase3.ph, Phase3.repeats,
      rightDiff_from_row _ _ _ 313 k (by decide) (by decide) hk
        Phase3.evolve_B_313 Phase3.evolve_Y_313 h3⟩
  · exact ⟨initRingBV Phase4.word Phase4.ph, Phase4.repeats,
      rightDiff_from_row _ _ _ 313 k (by decide) (by decide) hk
        Phase4.evolve_B_313 Phase4.evolve_Y_313 h4⟩
  · exact ⟨initRingBV Phase5.word Phase5.ph, Phase5.repeats,
      rightDiff_from_row _ _ _ 313 k (by decide) (by decide) hk
        Phase5.evolve_B_313 Phase5.evolve_Y_313 h5⟩

theorem coverage_314 (k : Nat) (hk : k < 8) :
    ∃ u : RingBV, Repeats rightPos 8 40 u ∧ Differs u 314 (rightPos 314 k) := by
  have full : (255 : Nat).testBit k = true := by
    change (2 ^ 8 - 1 : Nat).testBit k = true
    exact (Nat.testBit_two_pow_sub_one 8 k).trans (decide_eq_true hk)
  have h := congrArg (fun bits : Nat => bits.testBit k) base_cov_314
  simp only [full, Nat.testBit_or, Bool.or_eq_true] at h
  rcases h with (((((h0 | h1) | h2) | h3) | h4) | h5)
  · exact ⟨initRingBV Phase0.word Phase0.ph, Phase0.repeats,
      rightDiff_from_row _ _ _ 314 k (by decide) (by decide) hk
        Phase0.evolve_B_314 Phase0.evolve_Y_314 h0⟩
  · exact ⟨initRingBV Phase1.word Phase1.ph, Phase1.repeats,
      rightDiff_from_row _ _ _ 314 k (by decide) (by decide) hk
        Phase1.evolve_B_314 Phase1.evolve_Y_314 h1⟩
  · exact ⟨initRingBV Phase2.word Phase2.ph, Phase2.repeats,
      rightDiff_from_row _ _ _ 314 k (by decide) (by decide) hk
        Phase2.evolve_B_314 Phase2.evolve_Y_314 h2⟩
  · exact ⟨initRingBV Phase3.word Phase3.ph, Phase3.repeats,
      rightDiff_from_row _ _ _ 314 k (by decide) (by decide) hk
        Phase3.evolve_B_314 Phase3.evolve_Y_314 h3⟩
  · exact ⟨initRingBV Phase4.word Phase4.ph, Phase4.repeats,
      rightDiff_from_row _ _ _ 314 k (by decide) (by decide) hk
        Phase4.evolve_B_314 Phase4.evolve_Y_314 h4⟩
  · exact ⟨initRingBV Phase5.word Phase5.ph, Phase5.repeats,
      rightDiff_from_row _ _ _ 314 k (by decide) (by decide) hk
        Phase5.evolve_B_314 Phase5.evolve_Y_314 h5⟩

theorem coverage_315 (k : Nat) (hk : k < 8) :
    ∃ u : RingBV, Repeats rightPos 8 40 u ∧ Differs u 315 (rightPos 315 k) := by
  have full : (255 : Nat).testBit k = true := by
    change (2 ^ 8 - 1 : Nat).testBit k = true
    exact (Nat.testBit_two_pow_sub_one 8 k).trans (decide_eq_true hk)
  have h := congrArg (fun bits : Nat => bits.testBit k) base_cov_315
  simp only [full, Nat.testBit_or, Bool.or_eq_true] at h
  rcases h with (((((h0 | h1) | h2) | h3) | h4) | h5)
  · exact ⟨initRingBV Phase0.word Phase0.ph, Phase0.repeats,
      rightDiff_from_row _ _ _ 315 k (by decide) (by decide) hk
        Phase0.evolve_B_315 Phase0.evolve_Y_315 h0⟩
  · exact ⟨initRingBV Phase1.word Phase1.ph, Phase1.repeats,
      rightDiff_from_row _ _ _ 315 k (by decide) (by decide) hk
        Phase1.evolve_B_315 Phase1.evolve_Y_315 h1⟩
  · exact ⟨initRingBV Phase2.word Phase2.ph, Phase2.repeats,
      rightDiff_from_row _ _ _ 315 k (by decide) (by decide) hk
        Phase2.evolve_B_315 Phase2.evolve_Y_315 h2⟩
  · exact ⟨initRingBV Phase3.word Phase3.ph, Phase3.repeats,
      rightDiff_from_row _ _ _ 315 k (by decide) (by decide) hk
        Phase3.evolve_B_315 Phase3.evolve_Y_315 h3⟩
  · exact ⟨initRingBV Phase4.word Phase4.ph, Phase4.repeats,
      rightDiff_from_row _ _ _ 315 k (by decide) (by decide) hk
        Phase4.evolve_B_315 Phase4.evolve_Y_315 h4⟩
  · exact ⟨initRingBV Phase5.word Phase5.ph, Phase5.repeats,
      rightDiff_from_row _ _ _ 315 k (by decide) (by decide) hk
        Phase5.evolve_B_315 Phase5.evolve_Y_315 h5⟩

theorem coverage_316 (k : Nat) (hk : k < 8) :
    ∃ u : RingBV, Repeats rightPos 8 40 u ∧ Differs u 316 (rightPos 316 k) := by
  have full : (255 : Nat).testBit k = true := by
    change (2 ^ 8 - 1 : Nat).testBit k = true
    exact (Nat.testBit_two_pow_sub_one 8 k).trans (decide_eq_true hk)
  have h := congrArg (fun bits : Nat => bits.testBit k) base_cov_316
  simp only [full, Nat.testBit_or, Bool.or_eq_true] at h
  rcases h with (((((h0 | h1) | h2) | h3) | h4) | h5)
  · exact ⟨initRingBV Phase0.word Phase0.ph, Phase0.repeats,
      rightDiff_from_row _ _ _ 316 k (by decide) (by decide) hk
        Phase0.evolve_B_316 Phase0.evolve_Y_316 h0⟩
  · exact ⟨initRingBV Phase1.word Phase1.ph, Phase1.repeats,
      rightDiff_from_row _ _ _ 316 k (by decide) (by decide) hk
        Phase1.evolve_B_316 Phase1.evolve_Y_316 h1⟩
  · exact ⟨initRingBV Phase2.word Phase2.ph, Phase2.repeats,
      rightDiff_from_row _ _ _ 316 k (by decide) (by decide) hk
        Phase2.evolve_B_316 Phase2.evolve_Y_316 h2⟩
  · exact ⟨initRingBV Phase3.word Phase3.ph, Phase3.repeats,
      rightDiff_from_row _ _ _ 316 k (by decide) (by decide) hk
        Phase3.evolve_B_316 Phase3.evolve_Y_316 h3⟩
  · exact ⟨initRingBV Phase4.word Phase4.ph, Phase4.repeats,
      rightDiff_from_row _ _ _ 316 k (by decide) (by decide) hk
        Phase4.evolve_B_316 Phase4.evolve_Y_316 h4⟩
  · exact ⟨initRingBV Phase5.word Phase5.ph, Phase5.repeats,
      rightDiff_from_row _ _ _ 316 k (by decide) (by decide) hk
        Phase5.evolve_B_316 Phase5.evolve_Y_316 h5⟩

theorem coverage_317 (k : Nat) (hk : k < 8) :
    ∃ u : RingBV, Repeats rightPos 8 40 u ∧ Differs u 317 (rightPos 317 k) := by
  have full : (255 : Nat).testBit k = true := by
    change (2 ^ 8 - 1 : Nat).testBit k = true
    exact (Nat.testBit_two_pow_sub_one 8 k).trans (decide_eq_true hk)
  have h := congrArg (fun bits : Nat => bits.testBit k) base_cov_317
  simp only [full, Nat.testBit_or, Bool.or_eq_true] at h
  rcases h with (((((h0 | h1) | h2) | h3) | h4) | h5)
  · exact ⟨initRingBV Phase0.word Phase0.ph, Phase0.repeats,
      rightDiff_from_row _ _ _ 317 k (by decide) (by decide) hk
        Phase0.evolve_B_317 Phase0.evolve_Y_317 h0⟩
  · exact ⟨initRingBV Phase1.word Phase1.ph, Phase1.repeats,
      rightDiff_from_row _ _ _ 317 k (by decide) (by decide) hk
        Phase1.evolve_B_317 Phase1.evolve_Y_317 h1⟩
  · exact ⟨initRingBV Phase2.word Phase2.ph, Phase2.repeats,
      rightDiff_from_row _ _ _ 317 k (by decide) (by decide) hk
        Phase2.evolve_B_317 Phase2.evolve_Y_317 h2⟩
  · exact ⟨initRingBV Phase3.word Phase3.ph, Phase3.repeats,
      rightDiff_from_row _ _ _ 317 k (by decide) (by decide) hk
        Phase3.evolve_B_317 Phase3.evolve_Y_317 h3⟩
  · exact ⟨initRingBV Phase4.word Phase4.ph, Phase4.repeats,
      rightDiff_from_row _ _ _ 317 k (by decide) (by decide) hk
        Phase4.evolve_B_317 Phase4.evolve_Y_317 h4⟩
  · exact ⟨initRingBV Phase5.word Phase5.ph, Phase5.repeats,
      rightDiff_from_row _ _ _ 317 k (by decide) (by decide) hk
        Phase5.evolve_B_317 Phase5.evolve_Y_317 h5⟩

theorem coverage_318 (k : Nat) (hk : k < 8) :
    ∃ u : RingBV, Repeats rightPos 8 40 u ∧ Differs u 318 (rightPos 318 k) := by
  have full : (255 : Nat).testBit k = true := by
    change (2 ^ 8 - 1 : Nat).testBit k = true
    exact (Nat.testBit_two_pow_sub_one 8 k).trans (decide_eq_true hk)
  have h := congrArg (fun bits : Nat => bits.testBit k) base_cov_318
  simp only [full, Nat.testBit_or, Bool.or_eq_true] at h
  rcases h with (((((h0 | h1) | h2) | h3) | h4) | h5)
  · exact ⟨initRingBV Phase0.word Phase0.ph, Phase0.repeats,
      rightDiff_from_row _ _ _ 318 k (by decide) (by decide) hk
        Phase0.evolve_B_318 Phase0.evolve_Y_318 h0⟩
  · exact ⟨initRingBV Phase1.word Phase1.ph, Phase1.repeats,
      rightDiff_from_row _ _ _ 318 k (by decide) (by decide) hk
        Phase1.evolve_B_318 Phase1.evolve_Y_318 h1⟩
  · exact ⟨initRingBV Phase2.word Phase2.ph, Phase2.repeats,
      rightDiff_from_row _ _ _ 318 k (by decide) (by decide) hk
        Phase2.evolve_B_318 Phase2.evolve_Y_318 h2⟩
  · exact ⟨initRingBV Phase3.word Phase3.ph, Phase3.repeats,
      rightDiff_from_row _ _ _ 318 k (by decide) (by decide) hk
        Phase3.evolve_B_318 Phase3.evolve_Y_318 h3⟩
  · exact ⟨initRingBV Phase4.word Phase4.ph, Phase4.repeats,
      rightDiff_from_row _ _ _ 318 k (by decide) (by decide) hk
        Phase4.evolve_B_318 Phase4.evolve_Y_318 h4⟩
  · exact ⟨initRingBV Phase5.word Phase5.ph, Phase5.repeats,
      rightDiff_from_row _ _ _ 318 k (by decide) (by decide) hk
        Phase5.evolve_B_318 Phase5.evolve_Y_318 h5⟩

theorem coverage_319 (k : Nat) (hk : k < 8) :
    ∃ u : RingBV, Repeats rightPos 8 40 u ∧ Differs u 319 (rightPos 319 k) := by
  have full : (255 : Nat).testBit k = true := by
    change (2 ^ 8 - 1 : Nat).testBit k = true
    exact (Nat.testBit_two_pow_sub_one 8 k).trans (decide_eq_true hk)
  have h := congrArg (fun bits : Nat => bits.testBit k) base_cov_319
  simp only [full, Nat.testBit_or, Bool.or_eq_true] at h
  rcases h with (((((h0 | h1) | h2) | h3) | h4) | h5)
  · exact ⟨initRingBV Phase0.word Phase0.ph, Phase0.repeats,
      rightDiff_from_row _ _ _ 319 k (by decide) (by decide) hk
        Phase0.evolve_B_319 Phase0.evolve_Y_319 h0⟩
  · exact ⟨initRingBV Phase1.word Phase1.ph, Phase1.repeats,
      rightDiff_from_row _ _ _ 319 k (by decide) (by decide) hk
        Phase1.evolve_B_319 Phase1.evolve_Y_319 h1⟩
  · exact ⟨initRingBV Phase2.word Phase2.ph, Phase2.repeats,
      rightDiff_from_row _ _ _ 319 k (by decide) (by decide) hk
        Phase2.evolve_B_319 Phase2.evolve_Y_319 h2⟩
  · exact ⟨initRingBV Phase3.word Phase3.ph, Phase3.repeats,
      rightDiff_from_row _ _ _ 319 k (by decide) (by decide) hk
        Phase3.evolve_B_319 Phase3.evolve_Y_319 h3⟩
  · exact ⟨initRingBV Phase4.word Phase4.ph, Phase4.repeats,
      rightDiff_from_row _ _ _ 319 k (by decide) (by decide) hk
        Phase4.evolve_B_319 Phase4.evolve_Y_319 h4⟩
  · exact ⟨initRingBV Phase5.word Phase5.ph, Phase5.repeats,
      rightDiff_from_row _ _ _ 319 k (by decide) (by decide) hk
        Phase5.evolve_B_319 Phase5.evolve_Y_319 h5⟩

theorem coverage_320 (k : Nat) (hk : k < 8) :
    ∃ u : RingBV, Repeats rightPos 8 40 u ∧ Differs u 320 (rightPos 320 k) := by
  have full : (255 : Nat).testBit k = true := by
    change (2 ^ 8 - 1 : Nat).testBit k = true
    exact (Nat.testBit_two_pow_sub_one 8 k).trans (decide_eq_true hk)
  have h := congrArg (fun bits : Nat => bits.testBit k) base_cov_320
  simp only [full, Nat.testBit_or, Bool.or_eq_true] at h
  rcases h with (((((h0 | h1) | h2) | h3) | h4) | h5)
  · exact ⟨initRingBV Phase0.word Phase0.ph, Phase0.repeats,
      rightDiff_from_row _ _ _ 320 k (by decide) (by decide) hk
        Phase0.evolve_B_320 Phase0.evolve_Y_320 h0⟩
  · exact ⟨initRingBV Phase1.word Phase1.ph, Phase1.repeats,
      rightDiff_from_row _ _ _ 320 k (by decide) (by decide) hk
        Phase1.evolve_B_320 Phase1.evolve_Y_320 h1⟩
  · exact ⟨initRingBV Phase2.word Phase2.ph, Phase2.repeats,
      rightDiff_from_row _ _ _ 320 k (by decide) (by decide) hk
        Phase2.evolve_B_320 Phase2.evolve_Y_320 h2⟩
  · exact ⟨initRingBV Phase3.word Phase3.ph, Phase3.repeats,
      rightDiff_from_row _ _ _ 320 k (by decide) (by decide) hk
        Phase3.evolve_B_320 Phase3.evolve_Y_320 h3⟩
  · exact ⟨initRingBV Phase4.word Phase4.ph, Phase4.repeats,
      rightDiff_from_row _ _ _ 320 k (by decide) (by decide) hk
        Phase4.evolve_B_320 Phase4.evolve_Y_320 h4⟩
  · exact ⟨initRingBV Phase5.word Phase5.ph, Phase5.repeats,
      rightDiff_from_row _ _ _ 320 k (by decide) (by decide) hk
        Phase5.evolve_B_320 Phase5.evolve_Y_320 h5⟩

theorem coverage_321 (k : Nat) (hk : k < 8) :
    ∃ u : RingBV, Repeats rightPos 8 40 u ∧ Differs u 321 (rightPos 321 k) := by
  have full : (255 : Nat).testBit k = true := by
    change (2 ^ 8 - 1 : Nat).testBit k = true
    exact (Nat.testBit_two_pow_sub_one 8 k).trans (decide_eq_true hk)
  have h := congrArg (fun bits : Nat => bits.testBit k) base_cov_321
  simp only [full, Nat.testBit_or, Bool.or_eq_true] at h
  rcases h with (((((h0 | h1) | h2) | h3) | h4) | h5)
  · exact ⟨initRingBV Phase0.word Phase0.ph, Phase0.repeats,
      rightDiff_from_row _ _ _ 321 k (by decide) (by decide) hk
        Phase0.evolve_B_321 Phase0.evolve_Y_321 h0⟩
  · exact ⟨initRingBV Phase1.word Phase1.ph, Phase1.repeats,
      rightDiff_from_row _ _ _ 321 k (by decide) (by decide) hk
        Phase1.evolve_B_321 Phase1.evolve_Y_321 h1⟩
  · exact ⟨initRingBV Phase2.word Phase2.ph, Phase2.repeats,
      rightDiff_from_row _ _ _ 321 k (by decide) (by decide) hk
        Phase2.evolve_B_321 Phase2.evolve_Y_321 h2⟩
  · exact ⟨initRingBV Phase3.word Phase3.ph, Phase3.repeats,
      rightDiff_from_row _ _ _ 321 k (by decide) (by decide) hk
        Phase3.evolve_B_321 Phase3.evolve_Y_321 h3⟩
  · exact ⟨initRingBV Phase4.word Phase4.ph, Phase4.repeats,
      rightDiff_from_row _ _ _ 321 k (by decide) (by decide) hk
        Phase4.evolve_B_321 Phase4.evolve_Y_321 h4⟩
  · exact ⟨initRingBV Phase5.word Phase5.ph, Phase5.repeats,
      rightDiff_from_row _ _ _ 321 k (by decide) (by decide) hk
        Phase5.evolve_B_321 Phase5.evolve_Y_321 h5⟩

theorem coverage_322 (k : Nat) (hk : k < 8) :
    ∃ u : RingBV, Repeats rightPos 8 40 u ∧ Differs u 322 (rightPos 322 k) := by
  have full : (255 : Nat).testBit k = true := by
    change (2 ^ 8 - 1 : Nat).testBit k = true
    exact (Nat.testBit_two_pow_sub_one 8 k).trans (decide_eq_true hk)
  have h := congrArg (fun bits : Nat => bits.testBit k) base_cov_322
  simp only [full, Nat.testBit_or, Bool.or_eq_true] at h
  rcases h with (((((h0 | h1) | h2) | h3) | h4) | h5)
  · exact ⟨initRingBV Phase0.word Phase0.ph, Phase0.repeats,
      rightDiff_from_row _ _ _ 322 k (by decide) (by decide) hk
        Phase0.evolve_B_322 Phase0.evolve_Y_322 h0⟩
  · exact ⟨initRingBV Phase1.word Phase1.ph, Phase1.repeats,
      rightDiff_from_row _ _ _ 322 k (by decide) (by decide) hk
        Phase1.evolve_B_322 Phase1.evolve_Y_322 h1⟩
  · exact ⟨initRingBV Phase2.word Phase2.ph, Phase2.repeats,
      rightDiff_from_row _ _ _ 322 k (by decide) (by decide) hk
        Phase2.evolve_B_322 Phase2.evolve_Y_322 h2⟩
  · exact ⟨initRingBV Phase3.word Phase3.ph, Phase3.repeats,
      rightDiff_from_row _ _ _ 322 k (by decide) (by decide) hk
        Phase3.evolve_B_322 Phase3.evolve_Y_322 h3⟩
  · exact ⟨initRingBV Phase4.word Phase4.ph, Phase4.repeats,
      rightDiff_from_row _ _ _ 322 k (by decide) (by decide) hk
        Phase4.evolve_B_322 Phase4.evolve_Y_322 h4⟩
  · exact ⟨initRingBV Phase5.word Phase5.ph, Phase5.repeats,
      rightDiff_from_row _ _ _ 322 k (by decide) (by decide) hk
        Phase5.evolve_B_322 Phase5.evolve_Y_322 h5⟩

theorem coverage_323 (k : Nat) (hk : k < 8) :
    ∃ u : RingBV, Repeats rightPos 8 40 u ∧ Differs u 323 (rightPos 323 k) := by
  have full : (255 : Nat).testBit k = true := by
    change (2 ^ 8 - 1 : Nat).testBit k = true
    exact (Nat.testBit_two_pow_sub_one 8 k).trans (decide_eq_true hk)
  have h := congrArg (fun bits : Nat => bits.testBit k) base_cov_323
  simp only [full, Nat.testBit_or, Bool.or_eq_true] at h
  rcases h with (((((h0 | h1) | h2) | h3) | h4) | h5)
  · exact ⟨initRingBV Phase0.word Phase0.ph, Phase0.repeats,
      rightDiff_from_row _ _ _ 323 k (by decide) (by decide) hk
        Phase0.evolve_B_323 Phase0.evolve_Y_323 h0⟩
  · exact ⟨initRingBV Phase1.word Phase1.ph, Phase1.repeats,
      rightDiff_from_row _ _ _ 323 k (by decide) (by decide) hk
        Phase1.evolve_B_323 Phase1.evolve_Y_323 h1⟩
  · exact ⟨initRingBV Phase2.word Phase2.ph, Phase2.repeats,
      rightDiff_from_row _ _ _ 323 k (by decide) (by decide) hk
        Phase2.evolve_B_323 Phase2.evolve_Y_323 h2⟩
  · exact ⟨initRingBV Phase3.word Phase3.ph, Phase3.repeats,
      rightDiff_from_row _ _ _ 323 k (by decide) (by decide) hk
        Phase3.evolve_B_323 Phase3.evolve_Y_323 h3⟩
  · exact ⟨initRingBV Phase4.word Phase4.ph, Phase4.repeats,
      rightDiff_from_row _ _ _ 323 k (by decide) (by decide) hk
        Phase4.evolve_B_323 Phase4.evolve_Y_323 h4⟩
  · exact ⟨initRingBV Phase5.word Phase5.ph, Phase5.repeats,
      rightDiff_from_row _ _ _ 323 k (by decide) (by decide) hk
        Phase5.evolve_B_323 Phase5.evolve_Y_323 h5⟩

theorem coverage_324 (k : Nat) (hk : k < 8) :
    ∃ u : RingBV, Repeats rightPos 8 40 u ∧ Differs u 324 (rightPos 324 k) := by
  have full : (255 : Nat).testBit k = true := by
    change (2 ^ 8 - 1 : Nat).testBit k = true
    exact (Nat.testBit_two_pow_sub_one 8 k).trans (decide_eq_true hk)
  have h := congrArg (fun bits : Nat => bits.testBit k) base_cov_324
  simp only [full, Nat.testBit_or, Bool.or_eq_true] at h
  rcases h with (((((h0 | h1) | h2) | h3) | h4) | h5)
  · exact ⟨initRingBV Phase0.word Phase0.ph, Phase0.repeats,
      rightDiff_from_row _ _ _ 324 k (by decide) (by decide) hk
        Phase0.evolve_B_324 Phase0.evolve_Y_324 h0⟩
  · exact ⟨initRingBV Phase1.word Phase1.ph, Phase1.repeats,
      rightDiff_from_row _ _ _ 324 k (by decide) (by decide) hk
        Phase1.evolve_B_324 Phase1.evolve_Y_324 h1⟩
  · exact ⟨initRingBV Phase2.word Phase2.ph, Phase2.repeats,
      rightDiff_from_row _ _ _ 324 k (by decide) (by decide) hk
        Phase2.evolve_B_324 Phase2.evolve_Y_324 h2⟩
  · exact ⟨initRingBV Phase3.word Phase3.ph, Phase3.repeats,
      rightDiff_from_row _ _ _ 324 k (by decide) (by decide) hk
        Phase3.evolve_B_324 Phase3.evolve_Y_324 h3⟩
  · exact ⟨initRingBV Phase4.word Phase4.ph, Phase4.repeats,
      rightDiff_from_row _ _ _ 324 k (by decide) (by decide) hk
        Phase4.evolve_B_324 Phase4.evolve_Y_324 h4⟩
  · exact ⟨initRingBV Phase5.word Phase5.ph, Phase5.repeats,
      rightDiff_from_row _ _ _ 324 k (by decide) (by decide) hk
        Phase5.evolve_B_324 Phase5.evolve_Y_324 h5⟩

theorem coverage_325 (k : Nat) (hk : k < 8) :
    ∃ u : RingBV, Repeats rightPos 8 40 u ∧ Differs u 325 (rightPos 325 k) := by
  have full : (255 : Nat).testBit k = true := by
    change (2 ^ 8 - 1 : Nat).testBit k = true
    exact (Nat.testBit_two_pow_sub_one 8 k).trans (decide_eq_true hk)
  have h := congrArg (fun bits : Nat => bits.testBit k) base_cov_325
  simp only [full, Nat.testBit_or, Bool.or_eq_true] at h
  rcases h with (((((h0 | h1) | h2) | h3) | h4) | h5)
  · exact ⟨initRingBV Phase0.word Phase0.ph, Phase0.repeats,
      rightDiff_from_row _ _ _ 325 k (by decide) (by decide) hk
        Phase0.evolve_B_325 Phase0.evolve_Y_325 h0⟩
  · exact ⟨initRingBV Phase1.word Phase1.ph, Phase1.repeats,
      rightDiff_from_row _ _ _ 325 k (by decide) (by decide) hk
        Phase1.evolve_B_325 Phase1.evolve_Y_325 h1⟩
  · exact ⟨initRingBV Phase2.word Phase2.ph, Phase2.repeats,
      rightDiff_from_row _ _ _ 325 k (by decide) (by decide) hk
        Phase2.evolve_B_325 Phase2.evolve_Y_325 h2⟩
  · exact ⟨initRingBV Phase3.word Phase3.ph, Phase3.repeats,
      rightDiff_from_row _ _ _ 325 k (by decide) (by decide) hk
        Phase3.evolve_B_325 Phase3.evolve_Y_325 h3⟩
  · exact ⟨initRingBV Phase4.word Phase4.ph, Phase4.repeats,
      rightDiff_from_row _ _ _ 325 k (by decide) (by decide) hk
        Phase4.evolve_B_325 Phase4.evolve_Y_325 h4⟩
  · exact ⟨initRingBV Phase5.word Phase5.ph, Phase5.repeats,
      rightDiff_from_row _ _ _ 325 k (by decide) (by decide) hk
        Phase5.evolve_B_325 Phase5.evolve_Y_325 h5⟩

theorem coverage_326 (k : Nat) (hk : k < 8) :
    ∃ u : RingBV, Repeats rightPos 8 40 u ∧ Differs u 326 (rightPos 326 k) := by
  have full : (255 : Nat).testBit k = true := by
    change (2 ^ 8 - 1 : Nat).testBit k = true
    exact (Nat.testBit_two_pow_sub_one 8 k).trans (decide_eq_true hk)
  have h := congrArg (fun bits : Nat => bits.testBit k) base_cov_326
  simp only [full, Nat.testBit_or, Bool.or_eq_true] at h
  rcases h with (((((h0 | h1) | h2) | h3) | h4) | h5)
  · exact ⟨initRingBV Phase0.word Phase0.ph, Phase0.repeats,
      rightDiff_from_row _ _ _ 326 k (by decide) (by decide) hk
        Phase0.evolve_B_326 Phase0.evolve_Y_326 h0⟩
  · exact ⟨initRingBV Phase1.word Phase1.ph, Phase1.repeats,
      rightDiff_from_row _ _ _ 326 k (by decide) (by decide) hk
        Phase1.evolve_B_326 Phase1.evolve_Y_326 h1⟩
  · exact ⟨initRingBV Phase2.word Phase2.ph, Phase2.repeats,
      rightDiff_from_row _ _ _ 326 k (by decide) (by decide) hk
        Phase2.evolve_B_326 Phase2.evolve_Y_326 h2⟩
  · exact ⟨initRingBV Phase3.word Phase3.ph, Phase3.repeats,
      rightDiff_from_row _ _ _ 326 k (by decide) (by decide) hk
        Phase3.evolve_B_326 Phase3.evolve_Y_326 h3⟩
  · exact ⟨initRingBV Phase4.word Phase4.ph, Phase4.repeats,
      rightDiff_from_row _ _ _ 326 k (by decide) (by decide) hk
        Phase4.evolve_B_326 Phase4.evolve_Y_326 h4⟩
  · exact ⟨initRingBV Phase5.word Phase5.ph, Phase5.repeats,
      rightDiff_from_row _ _ _ 326 k (by decide) (by decide) hk
        Phase5.evolve_B_326 Phase5.evolve_Y_326 h5⟩

theorem coverage_327 (k : Nat) (hk : k < 8) :
    ∃ u : RingBV, Repeats rightPos 8 40 u ∧ Differs u 327 (rightPos 327 k) := by
  have full : (255 : Nat).testBit k = true := by
    change (2 ^ 8 - 1 : Nat).testBit k = true
    exact (Nat.testBit_two_pow_sub_one 8 k).trans (decide_eq_true hk)
  have h := congrArg (fun bits : Nat => bits.testBit k) base_cov_327
  simp only [full, Nat.testBit_or, Bool.or_eq_true] at h
  rcases h with (((((h0 | h1) | h2) | h3) | h4) | h5)
  · exact ⟨initRingBV Phase0.word Phase0.ph, Phase0.repeats,
      rightDiff_from_row _ _ _ 327 k (by decide) (by decide) hk
        Phase0.evolve_B_327 Phase0.evolve_Y_327 h0⟩
  · exact ⟨initRingBV Phase1.word Phase1.ph, Phase1.repeats,
      rightDiff_from_row _ _ _ 327 k (by decide) (by decide) hk
        Phase1.evolve_B_327 Phase1.evolve_Y_327 h1⟩
  · exact ⟨initRingBV Phase2.word Phase2.ph, Phase2.repeats,
      rightDiff_from_row _ _ _ 327 k (by decide) (by decide) hk
        Phase2.evolve_B_327 Phase2.evolve_Y_327 h2⟩
  · exact ⟨initRingBV Phase3.word Phase3.ph, Phase3.repeats,
      rightDiff_from_row _ _ _ 327 k (by decide) (by decide) hk
        Phase3.evolve_B_327 Phase3.evolve_Y_327 h3⟩
  · exact ⟨initRingBV Phase4.word Phase4.ph, Phase4.repeats,
      rightDiff_from_row _ _ _ 327 k (by decide) (by decide) hk
        Phase4.evolve_B_327 Phase4.evolve_Y_327 h4⟩
  · exact ⟨initRingBV Phase5.word Phase5.ph, Phase5.repeats,
      rightDiff_from_row _ _ _ 327 k (by decide) (by decide) hk
        Phase5.evolve_B_327 Phase5.evolve_Y_327 h5⟩

theorem coverage_328 (k : Nat) (hk : k < 8) :
    ∃ u : RingBV, Repeats rightPos 8 40 u ∧ Differs u 328 (rightPos 328 k) := by
  have full : (255 : Nat).testBit k = true := by
    change (2 ^ 8 - 1 : Nat).testBit k = true
    exact (Nat.testBit_two_pow_sub_one 8 k).trans (decide_eq_true hk)
  have h := congrArg (fun bits : Nat => bits.testBit k) base_cov_328
  simp only [full, Nat.testBit_or, Bool.or_eq_true] at h
  rcases h with (((((h0 | h1) | h2) | h3) | h4) | h5)
  · exact ⟨initRingBV Phase0.word Phase0.ph, Phase0.repeats,
      rightDiff_from_row _ _ _ 328 k (by decide) (by decide) hk
        Phase0.evolve_B_328 Phase0.evolve_Y_328 h0⟩
  · exact ⟨initRingBV Phase1.word Phase1.ph, Phase1.repeats,
      rightDiff_from_row _ _ _ 328 k (by decide) (by decide) hk
        Phase1.evolve_B_328 Phase1.evolve_Y_328 h1⟩
  · exact ⟨initRingBV Phase2.word Phase2.ph, Phase2.repeats,
      rightDiff_from_row _ _ _ 328 k (by decide) (by decide) hk
        Phase2.evolve_B_328 Phase2.evolve_Y_328 h2⟩
  · exact ⟨initRingBV Phase3.word Phase3.ph, Phase3.repeats,
      rightDiff_from_row _ _ _ 328 k (by decide) (by decide) hk
        Phase3.evolve_B_328 Phase3.evolve_Y_328 h3⟩
  · exact ⟨initRingBV Phase4.word Phase4.ph, Phase4.repeats,
      rightDiff_from_row _ _ _ 328 k (by decide) (by decide) hk
        Phase4.evolve_B_328 Phase4.evolve_Y_328 h4⟩
  · exact ⟨initRingBV Phase5.word Phase5.ph, Phase5.repeats,
      rightDiff_from_row _ _ _ 328 k (by decide) (by decide) hk
        Phase5.evolve_B_328 Phase5.evolve_Y_328 h5⟩

theorem coverage_329 (k : Nat) (hk : k < 8) :
    ∃ u : RingBV, Repeats rightPos 8 40 u ∧ Differs u 329 (rightPos 329 k) := by
  have full : (255 : Nat).testBit k = true := by
    change (2 ^ 8 - 1 : Nat).testBit k = true
    exact (Nat.testBit_two_pow_sub_one 8 k).trans (decide_eq_true hk)
  have h := congrArg (fun bits : Nat => bits.testBit k) base_cov_329
  simp only [full, Nat.testBit_or, Bool.or_eq_true] at h
  rcases h with (((((h0 | h1) | h2) | h3) | h4) | h5)
  · exact ⟨initRingBV Phase0.word Phase0.ph, Phase0.repeats,
      rightDiff_from_row _ _ _ 329 k (by decide) (by decide) hk
        Phase0.evolve_B_329 Phase0.evolve_Y_329 h0⟩
  · exact ⟨initRingBV Phase1.word Phase1.ph, Phase1.repeats,
      rightDiff_from_row _ _ _ 329 k (by decide) (by decide) hk
        Phase1.evolve_B_329 Phase1.evolve_Y_329 h1⟩
  · exact ⟨initRingBV Phase2.word Phase2.ph, Phase2.repeats,
      rightDiff_from_row _ _ _ 329 k (by decide) (by decide) hk
        Phase2.evolve_B_329 Phase2.evolve_Y_329 h2⟩
  · exact ⟨initRingBV Phase3.word Phase3.ph, Phase3.repeats,
      rightDiff_from_row _ _ _ 329 k (by decide) (by decide) hk
        Phase3.evolve_B_329 Phase3.evolve_Y_329 h3⟩
  · exact ⟨initRingBV Phase4.word Phase4.ph, Phase4.repeats,
      rightDiff_from_row _ _ _ 329 k (by decide) (by decide) hk
        Phase4.evolve_B_329 Phase4.evolve_Y_329 h4⟩
  · exact ⟨initRingBV Phase5.word Phase5.ph, Phase5.repeats,
      rightDiff_from_row _ _ _ 329 k (by decide) (by decide) hk
        Phase5.evolve_B_329 Phase5.evolve_Y_329 h5⟩

theorem coverage_330 (k : Nat) (hk : k < 8) :
    ∃ u : RingBV, Repeats rightPos 8 40 u ∧ Differs u 330 (rightPos 330 k) := by
  have full : (255 : Nat).testBit k = true := by
    change (2 ^ 8 - 1 : Nat).testBit k = true
    exact (Nat.testBit_two_pow_sub_one 8 k).trans (decide_eq_true hk)
  have h := congrArg (fun bits : Nat => bits.testBit k) base_cov_330
  simp only [full, Nat.testBit_or, Bool.or_eq_true] at h
  rcases h with (((((h0 | h1) | h2) | h3) | h4) | h5)
  · exact ⟨initRingBV Phase0.word Phase0.ph, Phase0.repeats,
      rightDiff_from_row _ _ _ 330 k (by decide) (by decide) hk
        Phase0.evolve_B_330 Phase0.evolve_Y_330 h0⟩
  · exact ⟨initRingBV Phase1.word Phase1.ph, Phase1.repeats,
      rightDiff_from_row _ _ _ 330 k (by decide) (by decide) hk
        Phase1.evolve_B_330 Phase1.evolve_Y_330 h1⟩
  · exact ⟨initRingBV Phase2.word Phase2.ph, Phase2.repeats,
      rightDiff_from_row _ _ _ 330 k (by decide) (by decide) hk
        Phase2.evolve_B_330 Phase2.evolve_Y_330 h2⟩
  · exact ⟨initRingBV Phase3.word Phase3.ph, Phase3.repeats,
      rightDiff_from_row _ _ _ 330 k (by decide) (by decide) hk
        Phase3.evolve_B_330 Phase3.evolve_Y_330 h3⟩
  · exact ⟨initRingBV Phase4.word Phase4.ph, Phase4.repeats,
      rightDiff_from_row _ _ _ 330 k (by decide) (by decide) hk
        Phase4.evolve_B_330 Phase4.evolve_Y_330 h4⟩
  · exact ⟨initRingBV Phase5.word Phase5.ph, Phase5.repeats,
      rightDiff_from_row _ _ _ 330 k (by decide) (by decide) hk
        Phase5.evolve_B_330 Phase5.evolve_Y_330 h5⟩

theorem coverage_331 (k : Nat) (hk : k < 8) :
    ∃ u : RingBV, Repeats rightPos 8 40 u ∧ Differs u 331 (rightPos 331 k) := by
  have full : (255 : Nat).testBit k = true := by
    change (2 ^ 8 - 1 : Nat).testBit k = true
    exact (Nat.testBit_two_pow_sub_one 8 k).trans (decide_eq_true hk)
  have h := congrArg (fun bits : Nat => bits.testBit k) base_cov_331
  simp only [full, Nat.testBit_or, Bool.or_eq_true] at h
  rcases h with (((((h0 | h1) | h2) | h3) | h4) | h5)
  · exact ⟨initRingBV Phase0.word Phase0.ph, Phase0.repeats,
      rightDiff_from_row _ _ _ 331 k (by decide) (by decide) hk
        Phase0.evolve_B_331 Phase0.evolve_Y_331 h0⟩
  · exact ⟨initRingBV Phase1.word Phase1.ph, Phase1.repeats,
      rightDiff_from_row _ _ _ 331 k (by decide) (by decide) hk
        Phase1.evolve_B_331 Phase1.evolve_Y_331 h1⟩
  · exact ⟨initRingBV Phase2.word Phase2.ph, Phase2.repeats,
      rightDiff_from_row _ _ _ 331 k (by decide) (by decide) hk
        Phase2.evolve_B_331 Phase2.evolve_Y_331 h2⟩
  · exact ⟨initRingBV Phase3.word Phase3.ph, Phase3.repeats,
      rightDiff_from_row _ _ _ 331 k (by decide) (by decide) hk
        Phase3.evolve_B_331 Phase3.evolve_Y_331 h3⟩
  · exact ⟨initRingBV Phase4.word Phase4.ph, Phase4.repeats,
      rightDiff_from_row _ _ _ 331 k (by decide) (by decide) hk
        Phase4.evolve_B_331 Phase4.evolve_Y_331 h4⟩
  · exact ⟨initRingBV Phase5.word Phase5.ph, Phase5.repeats,
      rightDiff_from_row _ _ _ 331 k (by decide) (by decide) hk
        Phase5.evolve_B_331 Phase5.evolve_Y_331 h5⟩

theorem coverage_332 (k : Nat) (hk : k < 8) :
    ∃ u : RingBV, Repeats rightPos 8 40 u ∧ Differs u 332 (rightPos 332 k) := by
  have full : (255 : Nat).testBit k = true := by
    change (2 ^ 8 - 1 : Nat).testBit k = true
    exact (Nat.testBit_two_pow_sub_one 8 k).trans (decide_eq_true hk)
  have h := congrArg (fun bits : Nat => bits.testBit k) base_cov_332
  simp only [full, Nat.testBit_or, Bool.or_eq_true] at h
  rcases h with (((((h0 | h1) | h2) | h3) | h4) | h5)
  · exact ⟨initRingBV Phase0.word Phase0.ph, Phase0.repeats,
      rightDiff_from_row _ _ _ 332 k (by decide) (by decide) hk
        Phase0.evolve_B_332 Phase0.evolve_Y_332 h0⟩
  · exact ⟨initRingBV Phase1.word Phase1.ph, Phase1.repeats,
      rightDiff_from_row _ _ _ 332 k (by decide) (by decide) hk
        Phase1.evolve_B_332 Phase1.evolve_Y_332 h1⟩
  · exact ⟨initRingBV Phase2.word Phase2.ph, Phase2.repeats,
      rightDiff_from_row _ _ _ 332 k (by decide) (by decide) hk
        Phase2.evolve_B_332 Phase2.evolve_Y_332 h2⟩
  · exact ⟨initRingBV Phase3.word Phase3.ph, Phase3.repeats,
      rightDiff_from_row _ _ _ 332 k (by decide) (by decide) hk
        Phase3.evolve_B_332 Phase3.evolve_Y_332 h3⟩
  · exact ⟨initRingBV Phase4.word Phase4.ph, Phase4.repeats,
      rightDiff_from_row _ _ _ 332 k (by decide) (by decide) hk
        Phase4.evolve_B_332 Phase4.evolve_Y_332 h4⟩
  · exact ⟨initRingBV Phase5.word Phase5.ph, Phase5.repeats,
      rightDiff_from_row _ _ _ 332 k (by decide) (by decide) hk
        Phase5.evolve_B_332 Phase5.evolve_Y_332 h5⟩

theorem coverage_333 (k : Nat) (hk : k < 8) :
    ∃ u : RingBV, Repeats rightPos 8 40 u ∧ Differs u 333 (rightPos 333 k) := by
  have full : (255 : Nat).testBit k = true := by
    change (2 ^ 8 - 1 : Nat).testBit k = true
    exact (Nat.testBit_two_pow_sub_one 8 k).trans (decide_eq_true hk)
  have h := congrArg (fun bits : Nat => bits.testBit k) base_cov_333
  simp only [full, Nat.testBit_or, Bool.or_eq_true] at h
  rcases h with (((((h0 | h1) | h2) | h3) | h4) | h5)
  · exact ⟨initRingBV Phase0.word Phase0.ph, Phase0.repeats,
      rightDiff_from_row _ _ _ 333 k (by decide) (by decide) hk
        Phase0.evolve_B_333 Phase0.evolve_Y_333 h0⟩
  · exact ⟨initRingBV Phase1.word Phase1.ph, Phase1.repeats,
      rightDiff_from_row _ _ _ 333 k (by decide) (by decide) hk
        Phase1.evolve_B_333 Phase1.evolve_Y_333 h1⟩
  · exact ⟨initRingBV Phase2.word Phase2.ph, Phase2.repeats,
      rightDiff_from_row _ _ _ 333 k (by decide) (by decide) hk
        Phase2.evolve_B_333 Phase2.evolve_Y_333 h2⟩
  · exact ⟨initRingBV Phase3.word Phase3.ph, Phase3.repeats,
      rightDiff_from_row _ _ _ 333 k (by decide) (by decide) hk
        Phase3.evolve_B_333 Phase3.evolve_Y_333 h3⟩
  · exact ⟨initRingBV Phase4.word Phase4.ph, Phase4.repeats,
      rightDiff_from_row _ _ _ 333 k (by decide) (by decide) hk
        Phase4.evolve_B_333 Phase4.evolve_Y_333 h4⟩
  · exact ⟨initRingBV Phase5.word Phase5.ph, Phase5.repeats,
      rightDiff_from_row _ _ _ 333 k (by decide) (by decide) hk
        Phase5.evolve_B_333 Phase5.evolve_Y_333 h5⟩

theorem coverage_334 (k : Nat) (hk : k < 8) :
    ∃ u : RingBV, Repeats rightPos 8 40 u ∧ Differs u 334 (rightPos 334 k) := by
  have full : (255 : Nat).testBit k = true := by
    change (2 ^ 8 - 1 : Nat).testBit k = true
    exact (Nat.testBit_two_pow_sub_one 8 k).trans (decide_eq_true hk)
  have h := congrArg (fun bits : Nat => bits.testBit k) base_cov_334
  simp only [full, Nat.testBit_or, Bool.or_eq_true] at h
  rcases h with (((((h0 | h1) | h2) | h3) | h4) | h5)
  · exact ⟨initRingBV Phase0.word Phase0.ph, Phase0.repeats,
      rightDiff_from_row _ _ _ 334 k (by decide) (by decide) hk
        Phase0.evolve_B_334 Phase0.evolve_Y_334 h0⟩
  · exact ⟨initRingBV Phase1.word Phase1.ph, Phase1.repeats,
      rightDiff_from_row _ _ _ 334 k (by decide) (by decide) hk
        Phase1.evolve_B_334 Phase1.evolve_Y_334 h1⟩
  · exact ⟨initRingBV Phase2.word Phase2.ph, Phase2.repeats,
      rightDiff_from_row _ _ _ 334 k (by decide) (by decide) hk
        Phase2.evolve_B_334 Phase2.evolve_Y_334 h2⟩
  · exact ⟨initRingBV Phase3.word Phase3.ph, Phase3.repeats,
      rightDiff_from_row _ _ _ 334 k (by decide) (by decide) hk
        Phase3.evolve_B_334 Phase3.evolve_Y_334 h3⟩
  · exact ⟨initRingBV Phase4.word Phase4.ph, Phase4.repeats,
      rightDiff_from_row _ _ _ 334 k (by decide) (by decide) hk
        Phase4.evolve_B_334 Phase4.evolve_Y_334 h4⟩
  · exact ⟨initRingBV Phase5.word Phase5.ph, Phase5.repeats,
      rightDiff_from_row _ _ _ 334 k (by decide) (by decide) hk
        Phase5.evolve_B_334 Phase5.evolve_Y_334 h5⟩

theorem coverage_335 (k : Nat) (hk : k < 8) :
    ∃ u : RingBV, Repeats rightPos 8 40 u ∧ Differs u 335 (rightPos 335 k) := by
  have full : (255 : Nat).testBit k = true := by
    change (2 ^ 8 - 1 : Nat).testBit k = true
    exact (Nat.testBit_two_pow_sub_one 8 k).trans (decide_eq_true hk)
  have h := congrArg (fun bits : Nat => bits.testBit k) base_cov_335
  simp only [full, Nat.testBit_or, Bool.or_eq_true] at h
  rcases h with (((((h0 | h1) | h2) | h3) | h4) | h5)
  · exact ⟨initRingBV Phase0.word Phase0.ph, Phase0.repeats,
      rightDiff_from_row _ _ _ 335 k (by decide) (by decide) hk
        Phase0.evolve_B_335 Phase0.evolve_Y_335 h0⟩
  · exact ⟨initRingBV Phase1.word Phase1.ph, Phase1.repeats,
      rightDiff_from_row _ _ _ 335 k (by decide) (by decide) hk
        Phase1.evolve_B_335 Phase1.evolve_Y_335 h1⟩
  · exact ⟨initRingBV Phase2.word Phase2.ph, Phase2.repeats,
      rightDiff_from_row _ _ _ 335 k (by decide) (by decide) hk
        Phase2.evolve_B_335 Phase2.evolve_Y_335 h2⟩
  · exact ⟨initRingBV Phase3.word Phase3.ph, Phase3.repeats,
      rightDiff_from_row _ _ _ 335 k (by decide) (by decide) hk
        Phase3.evolve_B_335 Phase3.evolve_Y_335 h3⟩
  · exact ⟨initRingBV Phase4.word Phase4.ph, Phase4.repeats,
      rightDiff_from_row _ _ _ 335 k (by decide) (by decide) hk
        Phase4.evolve_B_335 Phase4.evolve_Y_335 h4⟩
  · exact ⟨initRingBV Phase5.word Phase5.ph, Phase5.repeats,
      rightDiff_from_row _ _ _ 335 k (by decide) (by decide) hk
        Phase5.evolve_B_335 Phase5.evolve_Y_335 h5⟩

theorem coverage_336 (k : Nat) (hk : k < 8) :
    ∃ u : RingBV, Repeats rightPos 8 40 u ∧ Differs u 336 (rightPos 336 k) := by
  have full : (255 : Nat).testBit k = true := by
    change (2 ^ 8 - 1 : Nat).testBit k = true
    exact (Nat.testBit_two_pow_sub_one 8 k).trans (decide_eq_true hk)
  have h := congrArg (fun bits : Nat => bits.testBit k) base_cov_336
  simp only [full, Nat.testBit_or, Bool.or_eq_true] at h
  rcases h with (((((h0 | h1) | h2) | h3) | h4) | h5)
  · exact ⟨initRingBV Phase0.word Phase0.ph, Phase0.repeats,
      rightDiff_from_row _ _ _ 336 k (by decide) (by decide) hk
        Phase0.evolve_B_336 Phase0.evolve_Y_336 h0⟩
  · exact ⟨initRingBV Phase1.word Phase1.ph, Phase1.repeats,
      rightDiff_from_row _ _ _ 336 k (by decide) (by decide) hk
        Phase1.evolve_B_336 Phase1.evolve_Y_336 h1⟩
  · exact ⟨initRingBV Phase2.word Phase2.ph, Phase2.repeats,
      rightDiff_from_row _ _ _ 336 k (by decide) (by decide) hk
        Phase2.evolve_B_336 Phase2.evolve_Y_336 h2⟩
  · exact ⟨initRingBV Phase3.word Phase3.ph, Phase3.repeats,
      rightDiff_from_row _ _ _ 336 k (by decide) (by decide) hk
        Phase3.evolve_B_336 Phase3.evolve_Y_336 h3⟩
  · exact ⟨initRingBV Phase4.word Phase4.ph, Phase4.repeats,
      rightDiff_from_row _ _ _ 336 k (by decide) (by decide) hk
        Phase4.evolve_B_336 Phase4.evolve_Y_336 h4⟩
  · exact ⟨initRingBV Phase5.word Phase5.ph, Phase5.repeats,
      rightDiff_from_row _ _ _ 336 k (by decide) (by decide) hk
        Phase5.evolve_B_336 Phase5.evolve_Y_336 h5⟩

theorem coverage_337 (k : Nat) (hk : k < 8) :
    ∃ u : RingBV, Repeats rightPos 8 40 u ∧ Differs u 337 (rightPos 337 k) := by
  have full : (255 : Nat).testBit k = true := by
    change (2 ^ 8 - 1 : Nat).testBit k = true
    exact (Nat.testBit_two_pow_sub_one 8 k).trans (decide_eq_true hk)
  have h := congrArg (fun bits : Nat => bits.testBit k) base_cov_337
  simp only [full, Nat.testBit_or, Bool.or_eq_true] at h
  rcases h with (((((h0 | h1) | h2) | h3) | h4) | h5)
  · exact ⟨initRingBV Phase0.word Phase0.ph, Phase0.repeats,
      rightDiff_from_row _ _ _ 337 k (by decide) (by decide) hk
        Phase0.evolve_B_337 Phase0.evolve_Y_337 h0⟩
  · exact ⟨initRingBV Phase1.word Phase1.ph, Phase1.repeats,
      rightDiff_from_row _ _ _ 337 k (by decide) (by decide) hk
        Phase1.evolve_B_337 Phase1.evolve_Y_337 h1⟩
  · exact ⟨initRingBV Phase2.word Phase2.ph, Phase2.repeats,
      rightDiff_from_row _ _ _ 337 k (by decide) (by decide) hk
        Phase2.evolve_B_337 Phase2.evolve_Y_337 h2⟩
  · exact ⟨initRingBV Phase3.word Phase3.ph, Phase3.repeats,
      rightDiff_from_row _ _ _ 337 k (by decide) (by decide) hk
        Phase3.evolve_B_337 Phase3.evolve_Y_337 h3⟩
  · exact ⟨initRingBV Phase4.word Phase4.ph, Phase4.repeats,
      rightDiff_from_row _ _ _ 337 k (by decide) (by decide) hk
        Phase4.evolve_B_337 Phase4.evolve_Y_337 h4⟩
  · exact ⟨initRingBV Phase5.word Phase5.ph, Phase5.repeats,
      rightDiff_from_row _ _ _ 337 k (by decide) (by decide) hk
        Phase5.evolve_B_337 Phase5.evolve_Y_337 h5⟩

theorem coverage_338 (k : Nat) (hk : k < 8) :
    ∃ u : RingBV, Repeats rightPos 8 40 u ∧ Differs u 338 (rightPos 338 k) := by
  have full : (255 : Nat).testBit k = true := by
    change (2 ^ 8 - 1 : Nat).testBit k = true
    exact (Nat.testBit_two_pow_sub_one 8 k).trans (decide_eq_true hk)
  have h := congrArg (fun bits : Nat => bits.testBit k) base_cov_338
  simp only [full, Nat.testBit_or, Bool.or_eq_true] at h
  rcases h with (((((h0 | h1) | h2) | h3) | h4) | h5)
  · exact ⟨initRingBV Phase0.word Phase0.ph, Phase0.repeats,
      rightDiff_from_row _ _ _ 338 k (by decide) (by decide) hk
        Phase0.evolve_B_338 Phase0.evolve_Y_338 h0⟩
  · exact ⟨initRingBV Phase1.word Phase1.ph, Phase1.repeats,
      rightDiff_from_row _ _ _ 338 k (by decide) (by decide) hk
        Phase1.evolve_B_338 Phase1.evolve_Y_338 h1⟩
  · exact ⟨initRingBV Phase2.word Phase2.ph, Phase2.repeats,
      rightDiff_from_row _ _ _ 338 k (by decide) (by decide) hk
        Phase2.evolve_B_338 Phase2.evolve_Y_338 h2⟩
  · exact ⟨initRingBV Phase3.word Phase3.ph, Phase3.repeats,
      rightDiff_from_row _ _ _ 338 k (by decide) (by decide) hk
        Phase3.evolve_B_338 Phase3.evolve_Y_338 h3⟩
  · exact ⟨initRingBV Phase4.word Phase4.ph, Phase4.repeats,
      rightDiff_from_row _ _ _ 338 k (by decide) (by decide) hk
        Phase4.evolve_B_338 Phase4.evolve_Y_338 h4⟩
  · exact ⟨initRingBV Phase5.word Phase5.ph, Phase5.repeats,
      rightDiff_from_row _ _ _ 338 k (by decide) (by decide) hk
        Phase5.evolve_B_338 Phase5.evolve_Y_338 h5⟩

theorem coverage_339 (k : Nat) (hk : k < 8) :
    ∃ u : RingBV, Repeats rightPos 8 40 u ∧ Differs u 339 (rightPos 339 k) := by
  have full : (255 : Nat).testBit k = true := by
    change (2 ^ 8 - 1 : Nat).testBit k = true
    exact (Nat.testBit_two_pow_sub_one 8 k).trans (decide_eq_true hk)
  have h := congrArg (fun bits : Nat => bits.testBit k) base_cov_339
  simp only [full, Nat.testBit_or, Bool.or_eq_true] at h
  rcases h with (((((h0 | h1) | h2) | h3) | h4) | h5)
  · exact ⟨initRingBV Phase0.word Phase0.ph, Phase0.repeats,
      rightDiff_from_row _ _ _ 339 k (by decide) (by decide) hk
        Phase0.evolve_B_339 Phase0.evolve_Y_339 h0⟩
  · exact ⟨initRingBV Phase1.word Phase1.ph, Phase1.repeats,
      rightDiff_from_row _ _ _ 339 k (by decide) (by decide) hk
        Phase1.evolve_B_339 Phase1.evolve_Y_339 h1⟩
  · exact ⟨initRingBV Phase2.word Phase2.ph, Phase2.repeats,
      rightDiff_from_row _ _ _ 339 k (by decide) (by decide) hk
        Phase2.evolve_B_339 Phase2.evolve_Y_339 h2⟩
  · exact ⟨initRingBV Phase3.word Phase3.ph, Phase3.repeats,
      rightDiff_from_row _ _ _ 339 k (by decide) (by decide) hk
        Phase3.evolve_B_339 Phase3.evolve_Y_339 h3⟩
  · exact ⟨initRingBV Phase4.word Phase4.ph, Phase4.repeats,
      rightDiff_from_row _ _ _ 339 k (by decide) (by decide) hk
        Phase4.evolve_B_339 Phase4.evolve_Y_339 h4⟩
  · exact ⟨initRingBV Phase5.word Phase5.ph, Phase5.repeats,
      rightDiff_from_row _ _ _ 339 k (by decide) (by decide) hk
        Phase5.evolve_B_339 Phase5.evolve_Y_339 h5⟩

end Rule110KernelCert.RightCheckpoints
