"""Generate the finite case splits connecting checkpoint rows to strip lemmas."""

from generate_checkpoint_cert import LEFT_CRYSTAL, LEFT_DT, LEFT_W, RIGHT_DT, RIGHT_W, T0


def residue_cases(period: int, names: list[str]) -> str:
    alternatives = " ∨ ".join(f"r = {r}" for r in range(period))
    patterns = " | ".join("rfl" for _ in names)
    branches = "\n".join(f"  · exact {name}" for name in names)
    return f"  have cases_r : {alternatives} := by omega\n  rcases cases_r with {patterns}\n{branches}"


def phase_proofs(side: str) -> str:
    left = side == "Left"
    side = side.lower()
    period, width = (LEFT_DT, LEFT_W) if left else (RIGHT_DT, RIGHT_W)
    chain = []
    for t in range(T0, T0 + period):
        nxt = t + period
        chain.append(
            f"private theorem ray_{t} : {side.capitalize()}Q "
            f"(flipZero (background (initRingBV word ph))) {LEFT_CRYSTAL if left else RIGHT_W} {t} :=\n"
            f"  {side}Q_from_row _ _ _ {t} (by decide) (by decide)\n"
            f"    ({side}Bg_from_row _ _ _ {t} evolve_B_{t} evolve_B_{nxt} bg_shift_{t})\n"
            f"    evolve_Y_{t} evolve_Y_{nxt} tile_eq_{t}"
        )
    chain.append(
        f"theorem repeats : Repeats {side}Pos {width} {period} (initRingBV word ph) := by\n"
        f"  apply {side}Repeats_of_base _\n"
        f"    ({side}Bg_from_row _ _ _ {T0} evolve_B_{T0} evolve_B_{T0 + period} bg_shift_{T0})\n"
        f"  intro r hr\n"
        + residue_cases(period, [f"ray_{T0 + r}" for r in range(period)])
    )
    return "\n\n".join(chain) + "\n\n"


def coverage_proofs(side: str, phases: int, times: range) -> str:
    left = side == "Left"
    side = side.lower()
    period, width = (LEFT_DT, LEFT_W) if left else (RIGHT_DT, RIGHT_W)
    pattern = "h0"
    for p in range(1, phases):
        pattern = f"({pattern} | h{p})"
    chain = []
    for t in times:
        proofs = []
        for p in range(phases):
            ns = f"Phase{p}"
            proofs.append(
                f"  · exact ⟨initRingBV {ns}.word {ns}.ph, {ns}.repeats,\n"
                f"      {side}Diff_from_row _ _ _ {t} k (by decide) (by decide) hk\n"
                f"        {ns}.evolve_B_{t} {ns}.evolve_Y_{t} h{p}⟩"
            )
        chain.append(
            f"theorem coverage_{t} (k : Nat) (hk : k < {width}) :\n"
            f"    ∃ u : RingBV, Repeats {side}Pos {width} {period} u ∧ Differs u {t} ({side}Pos {t} k) := by\n"
            f"  have full : ({(1 << width) - 1} : Nat).testBit k = true := by\n"
            f"    change (2 ^ {width} - 1 : Nat).testBit k = true\n"
            f"    exact (Nat.testBit_two_pow_sub_one {width} k).trans (decide_eq_true hk)\n"
            f"  have h := congrArg (fun bits : Nat => bits.testBit k) base_cov_{t}\n"
            "  simp only [full, Nat.testBit_or, Bool.or_eq_true] at h\n"
            f"  rcases h with {pattern}\n"
            + "\n".join(proofs)
        )
    return "\n\n".join(chain) + "\n\n"


def coverage_dispatch(side: str) -> str:
    period, width = (LEFT_DT, LEFT_W) if side == "Left" else (RIGHT_DT, RIGHT_W)
    side = side.lower()
    return (
        f"theorem strip_base (r k : Nat) (hr : r < {period}) (hk : k < {width}) :\n"
        f"    ∃ u : RingBV, Repeats {side}Pos {width} {period} u ∧ Differs u (300 + r) ({side}Pos (300 + r) k) := by\n"
        + residue_cases(period, [f"coverage_{T0 + r} k hk" for r in range(period)])
        + "\n\n"
    )
