#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p .build
export LEAN_PATH="$PWD/.build"
modules=(
  Rule110Complete
  Rule110Fin1320Bridge
  Rule110Ether
  Rule110LocalWindow
  Rule110DomainWallA
  Rule110FrontGlue
  Rule110KernelCertificate
  Rule110BitVecBridge
  Rule110HalfRayClosure
  Rule110CheckpointSoundness
  Base
  Bridge
  AMedia
  ASnapshot
  AEarly1
  AEarly2
  AEarly3
  AEarly4
  AInit
  A0
  A1
  A2
  StaircaseA
  BMedia
  BInit
  B0
  B1
  B2
  StaircaseB
  Audit
  WedgeA
  WedgeB
  CoreAudit
  CoreGap
)
for module in "${modules[@]}"; do
  lean -j1 -o ".build/$module.olean" "$module.lean"
done
