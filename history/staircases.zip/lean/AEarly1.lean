import Bridge
import AMedia
import ASnapshot
namespace Rails
open Rule110Complete Rule110Fin1320Bridge Rule110LocalWindow
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option exponentiation.threshold 16384
private def check (x : Int) := line Abg3240 x = Am0 0 x
private instance (x : Int) : Decidable (check x) := by unfold check; infer_instance
private theorem check_0 : ∀ j : Fin 128, check ((j.val:Int)+0) := by decide
private theorem check_128 : ∀ j : Fin 128, check ((j.val:Int)+128) := by decide
private theorem check_256 : ∀ j : Fin 128, check ((j.val:Int)+256) := by decide
private theorem check_384 : ∀ j : Fin 128, check ((j.val:Int)+384) := by decide
private theorem check_512 : ∀ j : Fin 128, check ((j.val:Int)+512) := by decide
private theorem check_640 : ∀ j : Fin 128, check ((j.val:Int)+640) := by decide
private theorem check_768 : ∀ j : Fin 128, check ((j.val:Int)+768) := by decide
private theorem check_896 : ∀ j : Fin 128, check ((j.val:Int)+896) := by decide
private theorem check_1024 : ∀ j : Fin 128, check ((j.val:Int)+1024) := by decide
private theorem check_1152 : ∀ j : Fin 128, check ((j.val:Int)+1152) := by decide
private theorem check_1280 : ∀ j : Fin 128, check ((j.val:Int)+1280) := by decide
private theorem check_1408 : ∀ j : Fin 128, check ((j.val:Int)+1408) := by decide
private theorem check_1536 : ∀ j : Fin 128, check ((j.val:Int)+1536) := by decide
private theorem check_1664 : ∀ j : Fin 128, check ((j.val:Int)+1664) := by decide
private theorem check_1792 : ∀ j : Fin 128, check ((j.val:Int)+1792) := by decide
private theorem check_1920 : ∀ j : Fin 128, check ((j.val:Int)+1920) := by decide
private theorem check_2048 : ∀ j : Fin 128, check ((j.val:Int)+2048) := by decide
private theorem check_2176 : ∀ j : Fin 128, check ((j.val:Int)+2176) := by decide
private theorem check_2304 : ∀ j : Fin 128, check ((j.val:Int)+2304) := by decide
private theorem check_2432 : ∀ j : Fin 128, check ((j.val:Int)+2432) := by decide
private theorem check_2560 : ∀ j : Fin 128, check ((j.val:Int)+2560) := by decide
private theorem check_2688 : ∀ j : Fin 128, check ((j.val:Int)+2688) := by decide
private theorem check_2816 : ∀ j : Fin 128, check ((j.val:Int)+2816) := by decide
private theorem check_2944 : ∀ j : Fin 128, check ((j.val:Int)+2944) := by decide
private theorem check_3072 : ∀ j : Fin 128, check ((j.val:Int)+3072) := by decide
private theorem check_3200 : ∀ j : Fin 128, check ((j.val:Int)+3200) := by decide
private theorem check_3328 : ∀ j : Fin 128, check ((j.val:Int)+3328) := by decide
private theorem check_3456 : ∀ j : Fin 128, check ((j.val:Int)+3456) := by decide
private theorem check_3584 : ∀ j : Fin 128, check ((j.val:Int)+3584) := by decide
private theorem check_3712 : ∀ j : Fin 128, check ((j.val:Int)+3712) := by decide
private theorem check_3840 : ∀ j : Fin 128, check ((j.val:Int)+3840) := by decide
private theorem check_3968 : ∀ j : Fin 128, check ((j.val:Int)+3968) := by decide
private theorem check_4096 : ∀ j : Fin 128, check ((j.val:Int)+4096) := by decide
private theorem check_4224 : ∀ j : Fin 128, check ((j.val:Int)+4224) := by decide
private theorem check_4352 : ∀ j : Fin 128, check ((j.val:Int)+4352) := by decide
private theorem check_4480 : ∀ j : Fin 128, check ((j.val:Int)+4480) := by decide
private theorem check_4608 : ∀ j : Fin 128, check ((j.val:Int)+4608) := by decide
private theorem check_4736 : ∀ j : Fin 128, check ((j.val:Int)+4736) := by decide
private theorem check_4864 : ∀ j : Fin 128, check ((j.val:Int)+4864) := by decide
private theorem check_4992 : ∀ j : Fin 128, check ((j.val:Int)+4992) := by decide
private theorem check_5120 : ∀ j : Fin 128, check ((j.val:Int)+5120) := by decide
private theorem check_5248 : ∀ j : Fin 128, check ((j.val:Int)+5248) := by decide
private theorem check_5376 : ∀ j : Fin 128, check ((j.val:Int)+5376) := by decide
private theorem check_5504 : ∀ j : Fin 16, check ((j.val:Int)+5504) := by decide
private theorem check_all (j : Fin 5520) : check j.val := by
    by_cases h0 : j.val<128
    · have hh := check_0 ⟨j.val-0, by omega⟩
      exact (show (↑(j.val-0):Int)+0=(j.val:Int) by omega) ▸ hh
    by_cases h128 : j.val<256
    · have hh := check_128 ⟨j.val-128, by omega⟩
      exact (show (↑(j.val-128):Int)+128=(j.val:Int) by omega) ▸ hh
    by_cases h256 : j.val<384
    · have hh := check_256 ⟨j.val-256, by omega⟩
      exact (show (↑(j.val-256):Int)+256=(j.val:Int) by omega) ▸ hh
    by_cases h384 : j.val<512
    · have hh := check_384 ⟨j.val-384, by omega⟩
      exact (show (↑(j.val-384):Int)+384=(j.val:Int) by omega) ▸ hh
    by_cases h512 : j.val<640
    · have hh := check_512 ⟨j.val-512, by omega⟩
      exact (show (↑(j.val-512):Int)+512=(j.val:Int) by omega) ▸ hh
    by_cases h640 : j.val<768
    · have hh := check_640 ⟨j.val-640, by omega⟩
      exact (show (↑(j.val-640):Int)+640=(j.val:Int) by omega) ▸ hh
    by_cases h768 : j.val<896
    · have hh := check_768 ⟨j.val-768, by omega⟩
      exact (show (↑(j.val-768):Int)+768=(j.val:Int) by omega) ▸ hh
    by_cases h896 : j.val<1024
    · have hh := check_896 ⟨j.val-896, by omega⟩
      exact (show (↑(j.val-896):Int)+896=(j.val:Int) by omega) ▸ hh
    by_cases h1024 : j.val<1152
    · have hh := check_1024 ⟨j.val-1024, by omega⟩
      exact (show (↑(j.val-1024):Int)+1024=(j.val:Int) by omega) ▸ hh
    by_cases h1152 : j.val<1280
    · have hh := check_1152 ⟨j.val-1152, by omega⟩
      exact (show (↑(j.val-1152):Int)+1152=(j.val:Int) by omega) ▸ hh
    by_cases h1280 : j.val<1408
    · have hh := check_1280 ⟨j.val-1280, by omega⟩
      exact (show (↑(j.val-1280):Int)+1280=(j.val:Int) by omega) ▸ hh
    by_cases h1408 : j.val<1536
    · have hh := check_1408 ⟨j.val-1408, by omega⟩
      exact (show (↑(j.val-1408):Int)+1408=(j.val:Int) by omega) ▸ hh
    by_cases h1536 : j.val<1664
    · have hh := check_1536 ⟨j.val-1536, by omega⟩
      exact (show (↑(j.val-1536):Int)+1536=(j.val:Int) by omega) ▸ hh
    by_cases h1664 : j.val<1792
    · have hh := check_1664 ⟨j.val-1664, by omega⟩
      exact (show (↑(j.val-1664):Int)+1664=(j.val:Int) by omega) ▸ hh
    by_cases h1792 : j.val<1920
    · have hh := check_1792 ⟨j.val-1792, by omega⟩
      exact (show (↑(j.val-1792):Int)+1792=(j.val:Int) by omega) ▸ hh
    by_cases h1920 : j.val<2048
    · have hh := check_1920 ⟨j.val-1920, by omega⟩
      exact (show (↑(j.val-1920):Int)+1920=(j.val:Int) by omega) ▸ hh
    by_cases h2048 : j.val<2176
    · have hh := check_2048 ⟨j.val-2048, by omega⟩
      exact (show (↑(j.val-2048):Int)+2048=(j.val:Int) by omega) ▸ hh
    by_cases h2176 : j.val<2304
    · have hh := check_2176 ⟨j.val-2176, by omega⟩
      exact (show (↑(j.val-2176):Int)+2176=(j.val:Int) by omega) ▸ hh
    by_cases h2304 : j.val<2432
    · have hh := check_2304 ⟨j.val-2304, by omega⟩
      exact (show (↑(j.val-2304):Int)+2304=(j.val:Int) by omega) ▸ hh
    by_cases h2432 : j.val<2560
    · have hh := check_2432 ⟨j.val-2432, by omega⟩
      exact (show (↑(j.val-2432):Int)+2432=(j.val:Int) by omega) ▸ hh
    by_cases h2560 : j.val<2688
    · have hh := check_2560 ⟨j.val-2560, by omega⟩
      exact (show (↑(j.val-2560):Int)+2560=(j.val:Int) by omega) ▸ hh
    by_cases h2688 : j.val<2816
    · have hh := check_2688 ⟨j.val-2688, by omega⟩
      exact (show (↑(j.val-2688):Int)+2688=(j.val:Int) by omega) ▸ hh
    by_cases h2816 : j.val<2944
    · have hh := check_2816 ⟨j.val-2816, by omega⟩
      exact (show (↑(j.val-2816):Int)+2816=(j.val:Int) by omega) ▸ hh
    by_cases h2944 : j.val<3072
    · have hh := check_2944 ⟨j.val-2944, by omega⟩
      exact (show (↑(j.val-2944):Int)+2944=(j.val:Int) by omega) ▸ hh
    by_cases h3072 : j.val<3200
    · have hh := check_3072 ⟨j.val-3072, by omega⟩
      exact (show (↑(j.val-3072):Int)+3072=(j.val:Int) by omega) ▸ hh
    by_cases h3200 : j.val<3328
    · have hh := check_3200 ⟨j.val-3200, by omega⟩
      exact (show (↑(j.val-3200):Int)+3200=(j.val:Int) by omega) ▸ hh
    by_cases h3328 : j.val<3456
    · have hh := check_3328 ⟨j.val-3328, by omega⟩
      exact (show (↑(j.val-3328):Int)+3328=(j.val:Int) by omega) ▸ hh
    by_cases h3456 : j.val<3584
    · have hh := check_3456 ⟨j.val-3456, by omega⟩
      exact (show (↑(j.val-3456):Int)+3456=(j.val:Int) by omega) ▸ hh
    by_cases h3584 : j.val<3712
    · have hh := check_3584 ⟨j.val-3584, by omega⟩
      exact (show (↑(j.val-3584):Int)+3584=(j.val:Int) by omega) ▸ hh
    by_cases h3712 : j.val<3840
    · have hh := check_3712 ⟨j.val-3712, by omega⟩
      exact (show (↑(j.val-3712):Int)+3712=(j.val:Int) by omega) ▸ hh
    by_cases h3840 : j.val<3968
    · have hh := check_3840 ⟨j.val-3840, by omega⟩
      exact (show (↑(j.val-3840):Int)+3840=(j.val:Int) by omega) ▸ hh
    by_cases h3968 : j.val<4096
    · have hh := check_3968 ⟨j.val-3968, by omega⟩
      exact (show (↑(j.val-3968):Int)+3968=(j.val:Int) by omega) ▸ hh
    by_cases h4096 : j.val<4224
    · have hh := check_4096 ⟨j.val-4096, by omega⟩
      exact (show (↑(j.val-4096):Int)+4096=(j.val:Int) by omega) ▸ hh
    by_cases h4224 : j.val<4352
    · have hh := check_4224 ⟨j.val-4224, by omega⟩
      exact (show (↑(j.val-4224):Int)+4224=(j.val:Int) by omega) ▸ hh
    by_cases h4352 : j.val<4480
    · have hh := check_4352 ⟨j.val-4352, by omega⟩
      exact (show (↑(j.val-4352):Int)+4352=(j.val:Int) by omega) ▸ hh
    by_cases h4480 : j.val<4608
    · have hh := check_4480 ⟨j.val-4480, by omega⟩
      exact (show (↑(j.val-4480):Int)+4480=(j.val:Int) by omega) ▸ hh
    by_cases h4608 : j.val<4736
    · have hh := check_4608 ⟨j.val-4608, by omega⟩
      exact (show (↑(j.val-4608):Int)+4608=(j.val:Int) by omega) ▸ hh
    by_cases h4736 : j.val<4864
    · have hh := check_4736 ⟨j.val-4736, by omega⟩
      exact (show (↑(j.val-4736):Int)+4736=(j.val:Int) by omega) ▸ hh
    by_cases h4864 : j.val<4992
    · have hh := check_4864 ⟨j.val-4864, by omega⟩
      exact (show (↑(j.val-4864):Int)+4864=(j.val:Int) by omega) ▸ hh
    by_cases h4992 : j.val<5120
    · have hh := check_4992 ⟨j.val-4992, by omega⟩
      exact (show (↑(j.val-4992):Int)+4992=(j.val:Int) by omega) ▸ hh
    by_cases h5120 : j.val<5248
    · have hh := check_5120 ⟨j.val-5120, by omega⟩
      exact (show (↑(j.val-5120):Int)+5120=(j.val:Int) by omega) ▸ hh
    by_cases h5248 : j.val<5376
    · have hh := check_5248 ⟨j.val-5248, by omega⟩
      exact (show (↑(j.val-5248):Int)+5248=(j.val:Int) by omega) ▸ hh
    by_cases h5376 : j.val<5504
    · have hh := check_5376 ⟨j.val-5376, by omega⟩
      exact (show (↑(j.val-5376):Int)+5376=(j.val:Int) by omega) ▸ hh
    have hh := check_5504 ⟨j.val-5504, by omega⟩
    exact (show (↑(j.val-5504):Int)+5504=(j.val:Int) by omega) ▸ hh
theorem Abgread (x : Int) : line Abg3240 x = Am0 0 x := by
  let i : Fin 5520 := ⟨(x%5520).toNat,by omega⟩
  have h : ∀ j : Fin 5520, (let x : Int := j.val; line Abg3240 x = Am0 0 x) := check_all
  have hh := h i
  dsimp only at hh
  simp only [line,pos,Am0] at hh ⊢
  dsimp only [i] at hh
  simpa only [show ((x%5520).toNat:Int)=x%5520 by omega, show (x%5520+2760)%5520=(x+2760)%5520 by omega, show (x%5520+2+2760)%5520=(x+2+2760)%5520 by omega, show x%5520%10=x%10 by omega] using hh

end Rails
