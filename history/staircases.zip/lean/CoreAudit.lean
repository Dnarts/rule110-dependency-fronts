import WedgeA
import WedgeB
namespace Rails
open Rule110Complete Rule110KernelCert Rule110Fin1320Bridge Rule110LocalWindow
def torHit (t x : Nat) : Bool :=
  (Am0 (760+t) x != Am2 (760+t) x) || (Bm0 (2234+t) x != Bm2 (2234+t) x)
def rowCount (t : Nat) := ((List.range 210).filter (torHit t)).length
set_option maxRecDepth 10000
set_option maxHeartbeats 0
theorem tor_count : ((List.range 315).map rowCount).sum = 45255 := by decide
theorem origin_essential (t : Nat) : EssentialAt t 0 := by
  have ho (k : Nat) (x : Int) (hx : 0<x) : evolve k (loneOneAt 0) x = false := by
    induction k generalizing x with
    | zero => simp [evolve,loneOneAt,show x ≠ 0 by omega]
    | succ k ih =>
      change f _ _ _ = false
      rw [ih x hx,ih (x+1) (by omega)]
      cases evolve k (loneOneAt 0) (x-1) <;> rfl
  have hv (k : Nat) : evolve k (loneOneAt 0) 0 = true := by
    induction k with
    | zero => decide
    | succ k ih =>
      change f _ _ _ = true
      rw [ih,ho k (0+1) (by decide)]
      cases evolve k (loneOneAt 0) (0-1) <;> rfl
  refine ⟨zeroCfg,loneOneAt 0,?_,?_⟩
  · intro i hi; simp [zeroCfg,loneOneAt,hi]
  · rw [evolve_zero,hv]; decide
#print axioms origin_essential
#print axioms tor_count
end Rails
