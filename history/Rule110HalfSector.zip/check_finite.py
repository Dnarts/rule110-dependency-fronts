from itertools import product
T=3999
# radius-one backward cone for physical |x|<=t fits strictly inside [-8100,8099].
N=16200;H=N//2;mask=(1<<N)-1
def step(s):
 l=s<<1&mask|s>>(N-1);r=s>>1|(s&1)<<(N-1)
 return (s|r)^(l&s&r)
holes=[(1<<(t+t-t//3+1))-1 for t in range(T+1)]
def add(w,p):
 tile=sum(int(w[(j-H+p)%len(w)])<<j for j in range(len(w)))
 b=(tile*((1<<(len(w)*((N+len(w)-1)//len(w))))-1)//((1<<len(w))-1))&mask
 y=b^(1<<H)
 for t in range(T+1):
  holes[t]&=~((b^y)>>(H-t))
  b,y=step(b),step(y)
spec=[('11111000100110',[1,4,6]),('0000001001',range(10)),('1',[0]),('00101111',range(8))]
for w,ps in spec:
 for p in ps:add(w,p)
print('initial',sum(z.bit_count() for z in holes), flush=True)
for length in range(1,13):
 for word in product('01',repeat=length):
  w=''.join(word)
  if w!=min(w[j:]+w[:j] for j in range(length)):continue
  if any(w==w[:j]*(length//j) for j in range(1,length)):continue
  for p in range(length):
   add(w,p)
   if not any(holes):
    print('verified cells',sum(2*t-t//3+1 for t in range(T+1)), 'remaining',sum(z.bit_count() for z in holes));quit()
 print(length,sum(z.bit_count() for z in holes),flush=True)
