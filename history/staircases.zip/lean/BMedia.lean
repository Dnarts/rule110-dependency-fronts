import Base
namespace Rails
open Rule110Complete Rule110Fin1320Bridge Rule110LocalWindow
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option exponentiation.threshold 16384
def Bm0tab : Array Nat := #[
0x7,
0x25,
0x37,
0x1c,
0x16,
0x1f,
0x31,
0x19,
0x3d]
def Bm0 (t : Nat) (x : Int) := cell (Bm0tab[t%9]!) (x%6)
theorem Bm0step (t : Nat) (x : Int) : step (Bm0 t) x = Bm0 (t+1) x := by
  have tab : ∀ i : Fin 9, ∀ j : Fin 6, (let t := i.val; let x : Int := j.val; step (Bm0 t) x = Bm0 (t+1) x) := by decide
  let i : Fin 9 := ⟨t%9,by omega⟩
  let j : Fin 6 := ⟨(x%6).toNat,by omega⟩
  have h := tab i j
  dsimp only at h
  simp only [Bm0, step] at h ⊢
  dsimp only [i,j] at h
  simpa only [show ((x%6).toNat:Int) = x%6 by omega, show (x%6)%6=(x)%6 by omega, show (x%6-1)%6=(x-1)%6 by omega, show (x%6+1)%6=(x+1)%6 by omega, show (x%6+(0))%6=(x+(0))%6 by omega, show (t%9)%9=(t)%9 by omega, show (t%9+1)%9=(t+1)%9 by omega] using h
theorem Bm0ret60 (t : Nat) (x : Int) : Bm0 (t+60) (x+(-14)) = Bm0 t x := by
  have tab : ∀ i : Fin 9, ∀ j : Fin 6, (let t := i.val; let x : Int := j.val; Bm0 (t+60) (x+(-14)) = Bm0 t x) := by decide
  let i : Fin 9 := ⟨t%9,by omega⟩
  let j : Fin 6 := ⟨(x%6).toNat,by omega⟩
  have h := tab i j
  dsimp only at h
  simp only [Bm0, step] at h ⊢
  dsimp only [i,j] at h
  simpa only [show ((x%6).toNat:Int) = x%6 by omega, show (x%6)%6=(x)%6 by omega, show (x%6-1)%6=(x-1)%6 by omega, show (x%6+1)%6=(x+1)%6 by omega, show (x%6+(-14))%6=(x+(-14))%6 by omega, show (t%9)%9=(t)%9 by omega, show (t%9+60)%9=(t+60)%9 by omega] using h
theorem Bm0ret3 (t : Nat) (x : Int) : Bm0 (t+3) (x+(2)) = Bm0 t x := by
  have tab : ∀ i : Fin 9, ∀ j : Fin 6, (let t := i.val; let x : Int := j.val; Bm0 (t+3) (x+(2)) = Bm0 t x) := by decide
  let i : Fin 9 := ⟨t%9,by omega⟩
  let j : Fin 6 := ⟨(x%6).toNat,by omega⟩
  have h := tab i j
  dsimp only at h
  simp only [Bm0, step] at h ⊢
  dsimp only [i,j] at h
  simpa only [show ((x%6).toNat:Int) = x%6 by omega, show (x%6)%6=(x)%6 by omega, show (x%6-1)%6=(x-1)%6 by omega, show (x%6+1)%6=(x+1)%6 by omega, show (x%6+(2))%6=(x+(2))%6 by omega, show (t%9)%9=(t)%9 by omega, show (t%9+3)%9=(t+3)%9 by omega] using h
theorem Bm0ret882 (t : Nat) (x : Int) : Bm0 (t+882) (x+(378)) = Bm0 t x := by
  have tab : ∀ i : Fin 9, ∀ j : Fin 6, (let t := i.val; let x : Int := j.val; Bm0 (t+882) (x+(378)) = Bm0 t x) := by decide
  let i : Fin 9 := ⟨t%9,by omega⟩
  let j : Fin 6 := ⟨(x%6).toNat,by omega⟩
  have h := tab i j
  dsimp only at h
  simp only [Bm0, step] at h ⊢
  dsimp only [i,j] at h
  simpa only [show ((x%6).toNat:Int) = x%6 by omega, show (x%6)%6=(x)%6 by omega, show (x%6-1)%6=(x-1)%6 by omega, show (x%6+1)%6=(x+1)%6 by omega, show (x%6+(378))%6=(x+(378))%6 by omega, show (t%9)%9=(t)%9 by omega, show (t%9+882)%9=(t+882)%9 by omega] using h
def Bm1tab : Array Nat := #[
0x3ec8fb23ec8fb8,
0x23ec8fb23ec8ec,
0x323ec8fb23ecbe,
0x3b23ec8fb23ee3,
0xfb23ec8fb23b2,
0x8fb23ec8fb2fb,
0x2c8fb23ec8fb8f,
0x3ec8fb23ec8ec8,
0x23ec8fb23ecbec,
0x323ec8fb23ee3e,
0x3b23ec8fb23b23,
0xfb23ec8fb2fb2,
0x8fb23ec8fb8fb,
0x2c8fb23ec8ec8f,
0x3ec8fb23ecbec8,
0x23ec8fb23ee3ec,
0x323ec8fb23b23e,
0x3b23ec8fb2fb23,
0xfb23ec8fb8fb2,
0x8fb23ec8ec8fb,
0x2c8fb23ecbec8f,
0x3ec8fb23ee3ec8,
0x23ec8fb23b23ec,
0x323ec8fb2fb23e,
0x3b23ec8fb8fb23,
0xfb23ec8ec8fb2,
0x8fb23ecbec8fb,
0x2c8fb23ee3ec8f,
0x3ec8fb23b23ec8,
0x23ec8fb2fb23ec,
0x323ec8fb8fb23e,
0x3b23ec8ec8fb23,
0xfb23ecbec8fb2,
0x8fb23ee3ec8fb,
0x2c8fb23b23ec8f,
0x3ec8fb2fb23ec8,
0x23ec8fb8fb23ec,
0x323ec8ec8fb23e,
0x3b23ecbec8fb23,
0xfb23ee3ec8fb2,
0x8fb23b23ec8fb,
0x2c8fb2fb23ec8f,
0x3ec8fb8fb23ec8,
0x23ec8ec8fb23ec,
0x323ecbec8fb23e,
0x3b23ee3ec8fb23,
0xfb23b23ec8fb2,
0x8fb2fb23ec8fb,
0x2c8fb8fb23ec8f,
0x3ec8ec8fb23ec8,
0x23ecbec8fb23ec,
0x323ee3ec8fb23e,
0x3b23b23ec8fb23,
0xfb2fb23ec8fb2,
0x8fb8fb23ec8fb,
0x2c8ec8fb23ec8f,
0x3ecbec8fb23ec8,
0x23ee3ec8fb23ec,
0x323b23ec8fb23e,
0x3b2fb23ec8fb23,
0xfb8fb23ec8fb2,
0x8ec8fb23ec8fb,
0x2cbec8fb23ec8f,
0x3ee3ec8fb23ec8,
0x23b23ec8fb23ec,
0x32fb23ec8fb23e,
0x3b8fb23ec8fb23,
0xec8fb23ec8fb2,
0xbec8fb23ec8fb,
0x2e3ec8fb23ec8f,
0x3b23ec8fb23ec8,
0x2fb23ec8fb23ec,
0x38fb23ec8fb23e,
0x2c8fb23ec8fb23,
0x3ec8fb23ec8fb2,
0x23ec8fb23ec8fb,
0x323ec8fb23ec8e,
0x3b23ec8fb23ecb,
0xfb23ec8fb23ee,
0x8fb23ec8fb23b,
0x2c8fb23ec8fb2f]
def Bm1 (t : Nat) (x : Int) := cell (Bm1tab[t%81]!) (x%54)
theorem Bm1step (t : Nat) (x : Int) : step (Bm1 t) x = Bm1 (t+1) x := by
  have tab : ∀ i : Fin 81, ∀ j : Fin 54, (let t := i.val; let x : Int := j.val; step (Bm1 t) x = Bm1 (t+1) x) := by decide
  let i : Fin 81 := ⟨t%81,by omega⟩
  let j : Fin 54 := ⟨(x%54).toNat,by omega⟩
  have h := tab i j
  dsimp only at h
  simp only [Bm1, step] at h ⊢
  dsimp only [i,j] at h
  simpa only [show ((x%54).toNat:Int) = x%54 by omega, show (x%54)%54=(x)%54 by omega, show (x%54-1)%54=(x-1)%54 by omega, show (x%54+1)%54=(x+1)%54 by omega, show (x%54+(0))%54=(x+(0))%54 by omega, show (t%81)%81=(t)%81 by omega, show (t%81+1)%81=(t+1)%81 by omega] using h
theorem Bm1ret60 (t : Nat) (x : Int) : Bm1 (t+60) (x+(-14)) = Bm1 t x := by
  have tab : ∀ i : Fin 81, ∀ j : Fin 54, (let t := i.val; let x : Int := j.val; Bm1 (t+60) (x+(-14)) = Bm1 t x) := by decide
  let i : Fin 81 := ⟨t%81,by omega⟩
  let j : Fin 54 := ⟨(x%54).toNat,by omega⟩
  have h := tab i j
  dsimp only at h
  simp only [Bm1, step] at h ⊢
  dsimp only [i,j] at h
  simpa only [show ((x%54).toNat:Int) = x%54 by omega, show (x%54)%54=(x)%54 by omega, show (x%54-1)%54=(x-1)%54 by omega, show (x%54+1)%54=(x+1)%54 by omega, show (x%54+(-14))%54=(x+(-14))%54 by omega, show (t%81)%81=(t)%81 by omega, show (t%81+60)%81=(t+60)%81 by omega] using h
theorem Bm1ret513 (t : Nat) (x : Int) : Bm1 (t+513) (x+(-36)) = Bm1 t x := by
  have tab : ∀ i : Fin 81, ∀ j : Fin 54, (let t := i.val; let x : Int := j.val; Bm1 (t+513) (x+(-36)) = Bm1 t x) := by decide
  let i : Fin 81 := ⟨t%81,by omega⟩
  let j : Fin 54 := ⟨(x%54).toNat,by omega⟩
  have h := tab i j
  dsimp only at h
  simp only [Bm1, step] at h ⊢
  dsimp only [i,j] at h
  simpa only [show ((x%54).toNat:Int) = x%54 by omega, show (x%54)%54=(x)%54 by omega, show (x%54-1)%54=(x-1)%54 by omega, show (x%54+1)%54=(x+1)%54 by omega, show (x%54+(-36))%54=(x+(-36))%54 by omega, show (t%81)%81=(t)%81 by omega, show (t%81+513)%81=(t+513)%81 by omega] using h
def Bm2tab : Array Nat := #[
0x7d9,
0x247d,
0x3647,
0x1f64,
0x11f6,
0x191f,
0x3d91]
def Bm2 (t : Nat) (x : Int) := cell (Bm2tab[t%7]!) (x%14)
theorem Bm2step (t : Nat) (x : Int) : step (Bm2 t) x = Bm2 (t+1) x := by
  have tab : ∀ i : Fin 7, ∀ j : Fin 14, (let t := i.val; let x : Int := j.val; step (Bm2 t) x = Bm2 (t+1) x) := by decide
  let i : Fin 7 := ⟨t%7,by omega⟩
  let j : Fin 14 := ⟨(x%14).toNat,by omega⟩
  have h := tab i j
  dsimp only at h
  simp only [Bm2, step] at h ⊢
  dsimp only [i,j] at h
  simpa only [show ((x%14).toNat:Int) = x%14 by omega, show (x%14)%14=(x)%14 by omega, show (x%14-1)%14=(x-1)%14 by omega, show (x%14+1)%14=(x+1)%14 by omega, show (x%14+(0))%14=(x+(0))%14 by omega, show (t%7)%7=(t)%7 by omega, show (t%7+1)%7=(t+1)%7 by omega] using h
theorem Bm2ret3 (t : Nat) (x : Int) : Bm2 (t+3) (x+(2)) = Bm2 t x := by
  have tab : ∀ i : Fin 7, ∀ j : Fin 14, (let t := i.val; let x : Int := j.val; Bm2 (t+3) (x+(2)) = Bm2 t x) := by decide
  let i : Fin 7 := ⟨t%7,by omega⟩
  let j : Fin 14 := ⟨(x%14).toNat,by omega⟩
  have h := tab i j
  dsimp only at h
  simp only [Bm2, step] at h ⊢
  dsimp only [i,j] at h
  simpa only [show ((x%14).toNat:Int) = x%14 by omega, show (x%14)%14=(x)%14 by omega, show (x%14-1)%14=(x-1)%14 by omega, show (x%14+1)%14=(x+1)%14 by omega, show (x%14+(2))%14=(x+(2))%14 by omega, show (t%7)%7=(t)%7 by omega, show (t%7+3)%7=(t+3)%7 by omega] using h
theorem Bm2ret513 (t : Nat) (x : Int) : Bm2 (t+513) (x+(-36)) = Bm2 t x := by
  have tab : ∀ i : Fin 7, ∀ j : Fin 14, (let t := i.val; let x : Int := j.val; Bm2 (t+513) (x+(-36)) = Bm2 t x) := by decide
  let i : Fin 7 := ⟨t%7,by omega⟩
  let j : Fin 14 := ⟨(x%14).toNat,by omega⟩
  have h := tab i j
  dsimp only at h
  simp only [Bm2, step] at h ⊢
  dsimp only [i,j] at h
  simpa only [show ((x%14).toNat:Int) = x%14 by omega, show (x%14)%14=(x)%14 by omega, show (x%14-1)%14=(x-1)%14 by omega, show (x%14+1)%14=(x+1)%14 by omega, show (x%14+(-36))%14=(x+(-36))%14 by omega, show (t%7)%7=(t)%7 by omega, show (t%7+513)%7=(t+513)%7 by omega] using h
theorem Bm2ret882 (t : Nat) (x : Int) : Bm2 (t+882) (x+(378)) = Bm2 t x := by
  have tab : ∀ i : Fin 7, ∀ j : Fin 14, (let t := i.val; let x : Int := j.val; Bm2 (t+882) (x+(378)) = Bm2 t x) := by decide
  let i : Fin 7 := ⟨t%7,by omega⟩
  let j : Fin 14 := ⟨(x%14).toNat,by omega⟩
  have h := tab i j
  dsimp only at h
  simp only [Bm2, step] at h ⊢
  dsimp only [i,j] at h
  simpa only [show ((x%14).toNat:Int) = x%14 by omega, show (x%14)%14=(x)%14 by omega, show (x%14-1)%14=(x-1)%14 by omega, show (x%14+1)%14=(x+1)%14 by omega, show (x%14+(378))%14=(x+(378))%14 by omega, show (t%7)%7=(t)%7 by omega, show (t%7+882)%7=(t+882)%7 by omega] using h

end Rails
