# Rule 110 preprint, reproducible draft (2026-11-18)

This folder is a **pre-submission research draft**, not a public publication and not a peer-reviewed article.

## Included deliverables

- `rule110_preprint.tex` — LaTeX source of the mathematical draft (adapted from the supplied user text; includes the corrected arithmetic identity `5040 = 2*lcm(1,...,10)`).
- `rule110_preprint.pdf` — PDF rebuilt from the updated LaTeX source with Tectonic 0.17.0.
- `rule110_complete.lean` — Lean source checked with Lean 4.35.0. The four theorems establishing the dependency bounds and endpoint sharpness have no dependency on `sorryAx`.
- `rule110_certificate.py`, `rule110_crosscheck.ts`, `rule110_crosscheck.js` — computational audit of the local ANF, directional derivative, 128 seven-bit neighborhoods, periodic defect recurrence and finite-ring collapse examples.
- `rule110_large_coverage.py` — exact finite-time coverage algorithm for periodic input backgrounds and isolated perturbations.
- `certificate_100_rechecked.json` — current-run finite certificate through time 100.
- `large_coverage_2000_rechecked.json` — current-run finite witness coverage through time 2000.
- `typescript_crosscheck_stdout.log`, `certificate_100_stdout.log`, `large_coverage_stdout.log` and `large_coverage_timing.txt` — executed run logs.
- `rule110_certificate_proof_ru.md` — independent human-readable proof in Russian.
- `SHA256SUMS` — artifact file hashes (excluding itself).

## Verification results

| Check | Scope | Status |
|---|---|---|
| Rule 110 ANF identity | 8 Boolean inputs | PASS, Python and TS |
| Left-neighbor Boolean derivative | 4 Boolean inputs | PASS, Python and TS |
| Three-step 7-bit identity | 128 local neighborhoods | PASS, Python and TS |
| Period-4 background and traveling defect | finite base cycles and independent ring simulation | PASS |
| Rule 110 N=5 and Rule 90 N=4 collapse | exhaustive small rings | PASS |
| Finite essential-support coverage | all 3,337,668 (t,j) pairs, 0 <= t <= 2000, period p <= 10 | PASS, Python |
| Dependency bounds and endpoint sharpness | all t >= 0 on the bi-infinite lattice | PASS, Lean 4.35.0 |
| Lean compilation and axiom audit | module compilation and four theorem dependency reports | PASS, no `sorryAx` |
| New general all-time full-support conjecture | all t >= 0 | OPEN |

The finite-coverage algorithm chose ring length **5040** to keep periodic backgrounds of all periods 1..10 consistent and eliminate defect wraparound through t=2000. Note that `lcm(1,...,10) = 2520`, not 5040; the ring length is twice that least common multiple.

## Reproduction

Python 3 without third-party libraries:

```
python3 rule110_certificate.py --coverage-time 100 --coverage-period 6 --output certificate_100_rechecked.json
python3 rule110_large_coverage.py --max-time 2000 --max-period 10 --output large_coverage_2000_rechecked.json
```

TypeScript with `tsc` and Node.js:

```
tsc --strict --target ES2022 --module commonjs --skipLibCheck rule110_crosscheck.ts
node rule110_crosscheck.js
```

LaTeX:

```
tectonic rule110_preprint.tex
```

Reproduce the axiom audit with Lean 4.35.0:

```
lean rule110_complete.lean > lean_build.log 2>&1
```

The recorded run exited with code 0 and produced no errors or warnings. The bounds (`left_dependency_bound`, `right_dependency_bound`) depend on `propext` and `Quot.sound`. The endpoint theorems (`left_endpoint_essential`, `right_endpoint_essential`) also depend on `Classical.choice`. The full reports and source hash are recorded in `lean_check_status.txt`. The finite-ring results and the open gap-free support conjecture are outside the scope of this Lean audit.

References and publication priority require independent checking prior to distribution as a final preprint.
