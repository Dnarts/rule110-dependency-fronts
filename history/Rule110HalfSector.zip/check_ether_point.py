N=16200;H=N//2;mask=(1<<N)-1
def step(s):
 l=s<<1&mask|s>>(N-1);r=s>>1|(s&1)<<(N-1)
 return (s|r)^(l&s&r)

t, x = 4000, -2400
for word in ("11111000100110", "0000001001"):
    hits = []
    for phase in range(len(word)):
        bg = sum(int(word[(j-H+phase) % len(word)]) << j for j in range(N))
        defect = bg ^ (1 << H)
        for _ in range(t):
            bg, defect = step(bg), step(defect)
        if (bg ^ defect) >> (H+x) & 1:
            hits.append(phase)
    print(word, "time", t, "physical x", x, "witnesses", hits)
