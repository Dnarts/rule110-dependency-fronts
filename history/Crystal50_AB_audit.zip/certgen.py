from pathlib import Path
from collections import deque
f=Path('Crystal50Graph.lean').open('w')
def emit(s):print(s,file=f)
emit('''import Crystal50Wedge
namespace Rails.Crystal50Graph
open Rails.Crystal50Wedge
set_option maxRecDepth 200000
set_option maxHeartbeats 0
def shrink (s : Nat) := ((s >>> 1) ||| (s >>> 2)) ^^^ (s &&& (s >>> 1) &&& (s >>> 2))
def ctx (p : Phase) (j : Nat) := (List.range 4).foldl (fun a (k : Nat) =>
  a + (Cm p (2450+2*j) (-350-(j:Int)-4+(k:Nat))).toNat * 2^k) 0
def valid (p : Phase) (j : Nat) (src dst : Array Nat) :=
  let prefixBits := ctx p j
  let want := Cm p (2452+2*j) (-352-(j:Int))
  src.all fun entry => [0,1].all fun r =>
    let s := entry % 65536
    let v := shrink (shrink (prefixBits + s*16 + r*1048576))
    let i := (entry >>> (16+10*r)) % 1024
    i < dst.size && v.testBit 0 == want && (v >>> 1) % 65536 == dst[i]!.mod 65536
''')
for line in Path('cases.txt').read_text().splitlines():
    p,x,w,s,*c=map(int,line.split())
    if (x,w)!=(-350,16):continue
    start=s
    def update(v):
        return ((v>>1)|(v>>2))^(v&(v>>1)&(v>>2))
    def dest(j,s,r):
        v=update(update((c[j]&15)+(s<<4)+(r<<20)))
        assert v%2==c[j]>>4
        return v>>1&65535
    sets=[set() for _ in range(50)];sets[0].add(s);todo=[(0,s)]
    while todo:
        j,s=todo.pop();k=(j+1)%50
        for r in (0,1):
            v=dest(j,s,r)
            if v not in sets[k]:sets[k].add(v);todo.append((k,v))
    rows=[sorted(a) for a in sets]
    for j,states in enumerate(rows):
        dst=rows[(j+1)%50];assert len(dst)<1024
        entries=[s+(dst.index(dest(j,s,0))<<16)+(dst.index(dest(j,s,1))<<26) for s in states]
        emit(f'def row{p}_{j} : Array Nat := #['+', '.join(map(str,entries))+']')
    emit(f'def graph{p} := #['+', '.join(f'row{p}_{j}' for j in range(50))+']')
    emit(f'theorem base{p} : (List.range 16).foldl (fun a (k : Nat) => a + (Rule110LocalWindow.line (snap .p{p}) (-350+(k:Int))).toNat * 2^k) 0 = (row{p}_0[{rows[0].index(start)}]!).mod 65536 := by decide +kernel')
    for j in range(50):
        emit(f'theorem check{p}_{j} : valid .p{p} {j} row{p}_{j} row{p}_{(j+1)%50} = true := by decide +kernel')
    emit(f'theorem closed{p} (j : Fin 50) : valid .p{p} j (graph{p}[j.val]!) (graph{p}[(j.val+1)%50]!) = true := by')
    emit('  match j with')
    for j in range(50):
        emit(f'  | ⟨{j},_⟩ => exact check{p}_{j}' if j<49 else f'  | ⟨49,_⟩ =>\n    change valid .p{p} 49 (graph{p}[49]!) (graph{p}[(49+1)%50]!) = true\n    decide +kernel' )
    emit('  | ⟨n+50,h⟩ => omega')
    emit(f'#print axioms closed{p}')
emit('end Rails.Crystal50Graph')
