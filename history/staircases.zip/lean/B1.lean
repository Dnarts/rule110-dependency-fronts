import BMedia
namespace Rails
open Rule110Complete Rule110Fin1320Bridge Rule110LocalWindow
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option exponentiation.threshold 16384
def B1tab : Array Nat := #[
0x5e08fb23ec8fb8fb2,
0x66191f647d91d91f6,
0x371d91f647d97d91f,
0x3d97d91f647dc7d91,
0x27dc7d91f647647d9,
0x747647d91f65f647d,
0x1e5f647d91f71f647,
0x5371f647d91d91f64,
0x7bd91f647d97d91f6,
0xe7d91f647dc7d91f,
0xb47d91f647647d91,
0xfe47d91f65f647d9,
0x483647d91f71f647d,
0x6c3f647d91d91f647,
0x3e21f647d97d91f64,
0x46623ec8fb8fb23ec,
0x677323ec8ec8fb23e,
0x75dbb23ecbec8fb23,
0x5f7efb23ee3ec8fb2,
0x71c38fb23b23ec8fb,
0x1962c8fb2fb23ec8f,
0x1df3ec8fb8fb23ec8,
0x571a3ec8ec8fb23ec,
0x7d9f23ecbec8fb23e,
0x47d1b23ee3ec8fb23,
0x6479fb23b23ec8fb2,
0x764d0fb2fb23ec8fb,
0x1f6f88fb8fb23ec8f,
0x11f8cc8ec8fb23ec8,
0x3219dd97d91f647d9,
0x7b1d77dc7d91f647d,
0xf97dc7647d91f647,
0x48dc765f647d91f64,
0x6cf65f71f647d91f6,
0x3e9f71d91f647d91f,
0x23d1d97d91f647d91,
0x32797dc7d91f647d9,
0x7b4dc7647d91f647d,
0xfef65f647d91f647,
0x4839f71f647d91f64,
0x6c2d1d91f647d91f6,
0x3e3f97d91f647d91f,
0x2320dc7d91f647d91,
0x6761ec8fb23ec8fb2,
0x75f13ec8fb23ec8fb,
0x1f19a3ec8fb23ec8f,
0x119df23ec8fb23ec8,
0x59d71b23ec8fb23ec,
0x7d7d9fb23ec8fb23e,
0x47c7d0fb23ec8fb23,
0x6464788fb23ec8fb2,
0x76764cc8fb23ec8fb,
0x1f5f6eec8fb23ec8e,
0x11f1fbbec8fb23ecb,
0x59190ee3ec8fb23ee,
0x7d9d8bb23ec8fb23b,
0x47d7cefb23ec8fb2f,
0x647c6b8fb23ec8fb8,
0x6c8cfd91f647d91d9,
0x3ece87d91f647d97d,
0x23ebc47d91f647dc7,
0x323e6647d91f64764,
0x7b2377647d91f65f6,
0xfb3ddf647d91f71f,
0x48fa771f647d91d91,
0x6c8f5d91f647d97d9,
0x3ec9f7d91f647dc7d,
0x23ed1c7d91f647647,
0x323f9647d91f65f64,
0x7b20df647d91f71f6,
0xfb0f1f647d91d91f,
0x48f8991f647d97d91,
0x5919bb23ec8fb8fb2,
0x7d9defb23ec8ec8fb,
0x47d738fb23ecbec8f,
0x647dac8fb23ee3ec8,
0x7647fec8fb23b23ec,
0x1f6403ec8fb2fb23e,
0x11f6023ec8fb8fb23,
0x591f0323ec8ec8fb2,
0x7d9183b23ecbec8fb,
0x47d9c2fb23ee3ec8f,
0x647d638fb23b23ec8,
0x7647f2c8fb2fb23ec,
0x1f641bec8fb8fb23e,
0x11f61e3ec8ec8fb23,
0x323e2647d97d91f64,
0x7b2337647dc7d91f6,
0xfb3bdf647647d91f,
0x48fae71f65f647d91,
0x6c8fb591f71f647d9,
0x3ec8ffd91d91f647d,
0x23ec807d97d91f647,
0x323ec047dc7d91f64,
0x7b23e0647647d91f6,
0xfb230765f647d91f,
0x48fb385f71f647d91,
0x6c8fac71d91f647d9,
0x3ec8fe597d91f647d,
0x23ec837dc7d91f647,
0x647d878ec8fb23ec8,
0x7647c4cbec8fb23ec,
0x1f6466ee3ec8fb23e,
0x11f677bb23ec8fb23,
0x591f5cefb23ec8fb2,
0x7d91f6b8fb23ec8fb,
0x47d91fec8fb23ec8f,
0x647d903ec8fb23ec8,
0x7647d823ec8fb23ec,
0x1f647c323ec8fb23e,
0x11f6463b23ec8fb23,
0x591f672fb23ec8fb2,
0x7d91f5b8fb23ec8fb,
0x47d91fec8fb23ec8f,
0x647d903ec8fb23ec8,
0x6c8fb047d91f647d9,
0x3ec8f8647d91f647d,
0x23ec8c7647d91f647,
0x323ece5f647d91f64,
0x7b23eb71f647d91f6,
0xfb23fd91f647d91f,
0x48fb207d91f647d91,
0x6c8fb047d91f647d9,
0x3ec8f8647d91f647d,
0x23ec8c7647d91f647,
0x323ece5f647d91f65,
0x7b23eb71f647d91f7,
0xfb23fd91f647d91d,
0x48fb207d91f647d97,
0x591f608fb23ec8fb8,
0x7d91f0c8fb23ec8ec,
0x47d918ec8fb23ecbe,
0x647d9cbec8fb23ee3,
0x7647d6e3ec8fb23b2,
0x1f647fb23ec8fb2fb,
0x11f640fb23ec8fb8f,
0x591f608fb23ec8ec8,
0x7d91f0c8fb23ecbec,
0x47d918ec8fb23ee3e,
0x647d9cbec8fb23b23,
0x7647d6e3ec8fb2fb2,
0x1f647fb23ec8fb8fb,
0x11f640fb23ec8ec8f,
0x323ec11f647d97d91,
0x7b23e191f647dc7d9,
0xfb231d91f647647d,
0x48fb397d91f65f647,
0x6c8fadc7d91f71f64,
0x3ec8ff647d91d91f6,
0x23ec81f647d97d91f,
0x323ec11f647dc7d91,
0x7b23e191f647647d9,
0xfb231d91f65f647d,
0x48fb397d91f71f647,
0x6c8fadc7d91d91f64,
0x3ec8ff647d97d91f6,
0x23ec81f647dc7d91f,
0x647d823ec8ec8fb23,
0x7647c323ecbec8fb2,
0x1f6463b23ee3ec8fb,
0x11f672fb23b23ec8f,
0x591f5b8fb2fb23ec8,
0x7d91fec8fb8fb23ec,
0x47d903ec8ec8fb23e,
0x647d823ecbec8fb23,
0x7647c323ee3ec8fb2,
0x1f6463b23b23ec8fb,
0x11f672fb2fb23ec8f,
0x591f5b8fb8fb23ec8,
0x7d91fec8ec8fb23ec,
0x47d903ecbec8fb23e,
0x647d823ee3ec8fb23,
0x6c8f8647647d91f64,
0x3ec8c765f647d91f6,
0x23ece5f71f647d91f,
0x323eb71d91f647d91,
0x7b23fd97d91f647d9,
0xfb207dc7d91f647d,
0x48fb047647d91f647,
0x6c8f865f647d91f64,
0x3ec8c771f647d91f6,
0x23ece5d91f647d91f,
0x323eb77d91f647d91,
0x7b23fdc7d91f647d9,
0xfb207647d91f647d,
0x48fb05f647d91f647,
0x591f0e3ec8fb23ec8,
0x7d918b23ec8fb23ec,
0x47d9cfb23ec8fb23e,
0x647d68fb23ec8fb23,
0x7647fc8fb23ec8fb2,
0x1f6406c8fb23ec8fb,
0x11f607ec8fb23ec8f,
0x591f043ec8fb23ec8,
0x7d918623ec8fb23ec,
0x47d9c7323ec8fb23e,
0x647d65bb23ec8fb23,
0x7647f7efb23ec8fb2,
0x1f641c38fb23ec8fb,
0x11f6162c8fb23ec8e,
0x323e3e7d91f647d97,
0x7b232347d91f647dc,
0xfb3b3e47d91f6476,
0x48fafa3647d91f65f,
0x6c8f8f3f647d91f71,
0x3ec8c9a1f647d91d9,
0x23ecedf11f647d97d,
0x323ebf1991f647dc7,
0x7b23e19dd91f64764,
0xfb231d77d91f65f6,
0x48fb397dc7d91f71f,
0x6c8fadc7647d91d91,
0x3ec8ff65f647d97d9,
0x23ec81f71f647dc7d,
0x647d823b23ec8ec8f,
0x7647c32fb23ecbec8,
0x1f6463b8fb23ee3ec,
0x11f672ec8fb23b23e,
0x591f5bbec8fb2fb23,
0x7d91fee3ec8fb8fb2,
0x47d903b23ec8ec8fb,
0x647d82fb23ecbec8f,
0x7647c38fb23ee3ec8,
0x1f6462c8fb23b23ec,
0x11f673ec8fb2fb23e,
0x591f5a3ec8fb8fb23,
0x7d91ff23ec8ec8fb2,
0x47d901b23ecbec8fb,
0x647d81fb23ee3ec8f,
0x6c8f821f647647d91,
0x3ec8c311f65f647d9,
0x23ece3991f71f647d,
0x323eb2dd91d91f647,
0x7b23fbf7d97d91f64,
0xfb20e1c7dc7d91f6,
0x48fb0b1647647d91f,
0x6c8f8f9f65f647d91,
0x3ec8c8d1f71f647d9,
0x23ececf91d91f647d,
0x323ebe8d97d91f647,
0x7b23e3cfdc7d91f64,
0xfb232687647d91f6,
0x48fb3b7c5f647d91f,
0x591f5f8ce3ec8fb23,
0x7d91f0ceb23ec8fb2,
0x47d918ebfb23ec8fb,
0x647d9cbe0fb23ec8f,
0x7647d6e308fb23ec8,
0x1f647fb38c8fb23ec,
0x11f640facec8fb23e,
0x591f608febec8fb23,
0x7d91f0c83e3ec8fb2,
0x47d918ec2323ec8fb,
0x647d9cbe33b23ec8f,
0x7647d6e33afb23ec8,
0x1f647fb3af8fb23ec,
0x11f640faf8c8fb23e,
0x323ec11f19d91f647,
0x7b23e1919d7d91f64,
0xfb231d9d7c7d91f6,
0x48fb397d7c647d91f,
0x6c8fadc7c67647d91,
0x3ec8ff64675f647d9,
0x23ec81f675f1f647d,
0x323ec11f5f191f647,
0x7b23e191f19d91f64,
0xfb231d919d7d91f6,
0x48fb397d9d7c7d91f,
0x6c8fadc7d7c647d91,
0x3ec8ff647c67647d9,
0x23ec81f64675f647d,
0x647d823ecebe3ec8e,
0x7647c323ebe323ecb,
0x1f6463b23e33b23ee,
0x11f672fb233afb23b,
0x591f5b8fb3af8fb2f,
0x7d91fec8faf8c8fb8,
0x47d903ec8f8cec8ec,
0x647d823ec8cebecbe,
0x7647c323ecebe3ee3,
0x1f6463b23ebe323b2,
0x11f672fb23e33b2fb,
0x591f5b8fb233afb8f,
0x7d91fec8fb3af8ec8,
0x47d903ec8faf8cbec,
0x647d823ec8f8cee3e,
0x6c8f8647d919d7647,
0x3ec8c7647d9d7df64,
0x23ece5f647d7c71f6,
0x323eb71f647c6591f,
0x7b23fd91f64677d91,
0xfb207d91f675c7d9,
0x48fb047d91f5f647d,
0x6c8f8647d91f1f647,
0x3ec8c7647d9191f64,
0x23ece5f647d9d91f6,
0x323eb71f647d7d91f,
0x7b23fd91f647c7d91,
0xfb207d91f64647d9,
0x48fb047d91f67647d,
0x591f0c8fb23ebec8f,
0x7d918ec8fb23e3ec8,
0x47d9cbec8fb2323ec,
0x647d6e3ec8fb3b23e,
0x7647fb23ec8fafb23,
0x1f640fb23ec8f8fb2,
0x11f608fb23ec8c8fb,
0x591f0c8fb23ecec8f,
0x7d918ec8fb23ebec8,
0x47d9cbec8fb23e3ec,
0x647d6e3ec8fb2323e,
0x7647fb23ec8fb3b23,
0x1f640fb23ec8fafb2,
0x11f608fb23ec8f8fb,
0x323e191f647d9191f,
0x7b231d91f647d9d91,
0xfb397d91f647d7d9,
0x48fadc7d91f647c7d,
0x6c8ff647d91f64647,
0x3ec81f647d91f6764,
0x23ec11f647d91f5f6,
0x323e191f647d91f1f,
0x7b231d91f647d9191,
0xfb397d91f647d9d9,
0x48fadc7d91f647d7d,
0x6c8ff647d91f647c7,
0x3ec81f647d91f6464,
0x23ec11f647d91f676,
0x647c323ec8fb23ebe,
0x76463b23ec8fb23e3,
0x1f672fb23ec8fb232,
0x11f5b8fb23ec8fb3b,
0x591fec8fb23ec8faf,
0x7d903ec8fb23ec8f8,
0x47d823ec8fb23ec8c,
0x647c323ec8fb23ece,
0x76463b23ec8fb23eb,
0x1f672fb23ec8fb23e,
0x11f5b8fb23ec8fb23,
0x591fec8fb23ec8fb3,
0x7d903ec8fb23ec8fa,
0x47d823ec8fb23ec8f,
0x647c323ec8fb23ec8,
0x6c8c7647d91f647d9,
0x3ece5f647d91f647d,
0x23eb71f647d91f647,
0x323fd91f647d91f65,
0x7b207d91f647d91f7,
0xfb047d91f647d91c,
0x48f8647d91f647d96,
0x6c8c7647d91f647df,
0x3ece5f647d91f6471,
0x23eb71f647d91f659,
0x323fd91f647d91f7d,
0x7b207d91f647d91c7,
0xfb047d91f647d964,
0x48f8647d91f647df6,
0x5918ec8fb23ec8e3e,
0x7d9cbec8fb23ecb23,
0x47d6e3ec8fb23efb2,
0x647fb23ec8fb238fb,
0x7640fb23ec8fb2c8f,
0x1f608fb23ec8fbec8,
0x11f0c8fb23ec8e3ec,
0x5918ec8fb23ecb23e,
0x7d9cbec8fb23efb23,
0x47d6e3ec8fb238fb2,
0x647fb23ec8fb2c8fb,
0x7640fb23ec8fbec8f,
0x1f608fb23ec8e3ec8,
0x11f0c8fb23ecb23ec,
0x3231d91f647df647d,
0x7b397d91f6471f647,
0xfadc7d91f6591f64,
0x48ff647d91f7d91f6,
0x6c81f647d91c7d91f,
0x3ec11f647d9647d91,
0x23e191f647df647d9,
0x3231d91f6471f647d,
0x7b397d91f6591f647,
0xfadc7d91f7d91f64,
0x48ff647d91c7d91f6,
0x6c81f647d9647d91f,
0x3ec11f647df647d91,
0x23e191f6471f647d9,
0x6463b23ecb23ec8fb,
0x7672fb23efb23ec8f,
0x1f5b8fb238fb23ec8,
0x11fec8fb2c8fb23ec,
0x5903ec8fbec8fb23e,
0x7d823ec8e3ec8fb23,
0x47c323ecb23ec8fb2,
0x6463b23efb23ec8fb,
0x7672fb238fb23ec8f,
0x1f5b8fb2c8fb23ec8,
0x11fec8fbec8fb23ec,
0x5903ec8e3ec8fb23e,
0x7d823ecb23ec8fb23,
0x47c323efb23ec8fb2,
0x6463b238fb23ec8fb,
0x6ce5f6591f647d91f,
0x3eb71f7d91f647d91,
0x23fd91c7d91f647d9,
0x3207d9647d91f647d,
0x7b047df647d91f647,
0xf86471f647d91f64,
0x48c76591f647d91f6,
0x6ce5f7d91f647d91f,
0x3eb71c7d91f647d91,
0x23fd9647d91f647d9,
0x3207df647d91f647d,
0x7b0471f647d91f647,
0xf86591f647d91f64,
0x48c77d91f647d91f6,
0x59cb8fb23ec8fb23e,
0x7d6ec8fb23ec8fb23,
0x47fbec8fb23ec8fb2,
0x640e3ec8fb23ec8fb,
0x760b23ec8fb23ec8e,
0x1f0fb23ec8fb23ecb,
0x1188fb23ec8fb23ee,
0x59cc8fb23ec8fb23b,
0x7d6ec8fb23ec8fb2f,
0x47fbec8fb23ec8fb8,
0x640e3ec8fb23ec8ec,
0x760b23ec8fb23ecbe,
0x1f0fb23ec8fb23ee3,
0x1188fb23ec8fb23b2,
0x33991f647d91f65f6,
0x7add91f647d91f71f,
0xff7d91f647d91d91,
0x481c7d91f647d97d9,
0x6c1647d91f647dc7d,
0x3e1f647d91f647647,
0x2311f647d91f65f64,
0x33991f647d91f71f6,
0x7add91f647d91d91f,
0xff7d91f647d97d91,
0x481c7d91f647dc7d9,
0x6c1647d91f647647d,
0x3e1f647d91f65f647,
0x2311f647d91f71f64,
0x67323ec8fb23b23ec,
0x75bb23ec8fb2fb23e,
0x1fefb23ec8fb8fb23,
0x1038fb23ec8ec8fb2,
0x582c8fb23ecbec8fb,
0x7c3ec8fb23ee3ec8f,
0x4623ec8fb23b23ec8,
0x67323ec8fb2fb23ec,
0x75bb23ec8fb8fb23e,
0x1fefb23ec8ec8fb23,
0x1038fb23ecbec8fb2,
0x582c8fb23ee3ec8fb,
0x7c3ec8fb23b23ec8f,
0x4623ec8fb2fb23ec8,
0x67323ec8fb8fb23ec,
0x6b7647d91d91f647d,
0x3fdf647d97d91f647,
0x2071f647dc7d91f64,
0x30591f647647d91f6,
0x787d91f65f647d91f,
0xc47d91f71f647d91,
0x4e647d91d91f647d9,
0x6b7647d97d91f647d,
0x3fdf647dc7d91f647,
0x2071f647647d91f64,
0x30591f65f647d91f6,
0x787d91f71f647d91f,
0xc47d91d91f647d91,
0x4e647d97d91f647d9,
0x56ec8fb8fb23ec8fb,
0x7fbec8ec8fb23ec8f,
0x40e3ecbec8fb23ec8,
0x60b23ee3ec8fb23ec,
0x70fb23b23ec8fb23e,
0x188fb2fb23ec8fb23,
0x1cc8fb8fb23ec8fb2,
0x56ec8ec8fb23ec8fb,
0x7fbecbec8fb23ec8f,
0x40e3ee3ec8fb23ec8,
0x60b23b23ec8fb23ec,
0x70fb2fb23ec8fb23e,
0x188fb8fb23ec8fb23,
0x1cc8ec8fb23ec8fb2,
0x2dd97d91f647d91f6,
0x7f7dc7d91f647d91f,
0x1c7647d91f647d91,
0x4165f647d91f647d9,
0x61f71f647d91f647d,
0x311d91f647d91f647,
0x3997d91f647d91f65,
0x2ddc7d91f647d91f7,
0x7f7647d91f647d91d,
0x1df647d91f647d97,
0x4171f647d91f647dc,
0x61d91f647d91f6476,
0x317d91f647d91f65f,
0x39c7d91f647d91f71,
0x5ac8fb23ec8fb23b2,
0x7fec8fb23ec8fb2fb,
0x3ec8fb23ec8fb8f,
0x23ec8fb23ec8ec8,
0x40323ec8fb23ecbec,
0x603b23ec8fb23ee3e,
0x702fb23ec8fb23b23,
0x5838fb23ec8fb2fb2,
0x7c2c8fb23ec8fb8fb,
0x63ec8fb23ec8ec8f,
0x723ec8fb23ecbec8,
0x45b23ec8fb23ee3ec,
0x67fb23ec8fb23b23e,
0x740fb23ec8fb2fb23]
def B1 (t : Nat) (x : Int) := if x-(t:Int)*(-36)/513<(-174) then Bm1 t x else if (-108)<x-(t:Int)*(-36)/513 then Bm2 t x else cell B1tab[t%513]! (x-(t:Int)*(-36)/513-(-174))
theorem B1ret (t : Nat) (x : Int) : B1 (t+513) (x+(-36)) = B1 t x := by
  unfold B1
  simp only [show x+(-36)-((↑(t+513):Int)*(-36)/513) = x-((t:Int)*(-36)/513) by omega, show (t+513)%513=t%513 by omega, Bm1ret513, Bm2ret513]
private theorem B1check0 : ∀ r : Fin 8, ∀ j : Fin 71, let y := (-176:Int)+j.val+((r.val+0):Int)*(-36)/513; step (B1 (r.val+0)) y = B1 ((r.val+0)+1) y := by decide
private theorem B1check8 : ∀ r : Fin 8, ∀ j : Fin 71, let y := (-176:Int)+j.val+((r.val+8):Int)*(-36)/513; step (B1 (r.val+8)) y = B1 ((r.val+8)+1) y := by decide
private theorem B1check16 : ∀ r : Fin 8, ∀ j : Fin 71, let y := (-176:Int)+j.val+((r.val+16):Int)*(-36)/513; step (B1 (r.val+16)) y = B1 ((r.val+16)+1) y := by decide
private theorem B1check24 : ∀ r : Fin 8, ∀ j : Fin 71, let y := (-176:Int)+j.val+((r.val+24):Int)*(-36)/513; step (B1 (r.val+24)) y = B1 ((r.val+24)+1) y := by decide
private theorem B1check32 : ∀ r : Fin 8, ∀ j : Fin 71, let y := (-176:Int)+j.val+((r.val+32):Int)*(-36)/513; step (B1 (r.val+32)) y = B1 ((r.val+32)+1) y := by decide
private theorem B1check40 : ∀ r : Fin 8, ∀ j : Fin 71, let y := (-176:Int)+j.val+((r.val+40):Int)*(-36)/513; step (B1 (r.val+40)) y = B1 ((r.val+40)+1) y := by decide
private theorem B1check48 : ∀ r : Fin 8, ∀ j : Fin 71, let y := (-176:Int)+j.val+((r.val+48):Int)*(-36)/513; step (B1 (r.val+48)) y = B1 ((r.val+48)+1) y := by decide
private theorem B1check56 : ∀ r : Fin 8, ∀ j : Fin 71, let y := (-176:Int)+j.val+((r.val+56):Int)*(-36)/513; step (B1 (r.val+56)) y = B1 ((r.val+56)+1) y := by decide
private theorem B1check64 : ∀ r : Fin 8, ∀ j : Fin 71, let y := (-176:Int)+j.val+((r.val+64):Int)*(-36)/513; step (B1 (r.val+64)) y = B1 ((r.val+64)+1) y := by decide
private theorem B1check72 : ∀ r : Fin 8, ∀ j : Fin 71, let y := (-176:Int)+j.val+((r.val+72):Int)*(-36)/513; step (B1 (r.val+72)) y = B1 ((r.val+72)+1) y := by decide
private theorem B1check80 : ∀ r : Fin 8, ∀ j : Fin 71, let y := (-176:Int)+j.val+((r.val+80):Int)*(-36)/513; step (B1 (r.val+80)) y = B1 ((r.val+80)+1) y := by decide
private theorem B1check88 : ∀ r : Fin 8, ∀ j : Fin 71, let y := (-176:Int)+j.val+((r.val+88):Int)*(-36)/513; step (B1 (r.val+88)) y = B1 ((r.val+88)+1) y := by decide
private theorem B1check96 : ∀ r : Fin 8, ∀ j : Fin 71, let y := (-176:Int)+j.val+((r.val+96):Int)*(-36)/513; step (B1 (r.val+96)) y = B1 ((r.val+96)+1) y := by decide
private theorem B1check104 : ∀ r : Fin 8, ∀ j : Fin 71, let y := (-176:Int)+j.val+((r.val+104):Int)*(-36)/513; step (B1 (r.val+104)) y = B1 ((r.val+104)+1) y := by decide
private theorem B1check112 : ∀ r : Fin 8, ∀ j : Fin 71, let y := (-176:Int)+j.val+((r.val+112):Int)*(-36)/513; step (B1 (r.val+112)) y = B1 ((r.val+112)+1) y := by decide
private theorem B1check120 : ∀ r : Fin 8, ∀ j : Fin 71, let y := (-176:Int)+j.val+((r.val+120):Int)*(-36)/513; step (B1 (r.val+120)) y = B1 ((r.val+120)+1) y := by decide
private theorem B1check128 : ∀ r : Fin 8, ∀ j : Fin 71, let y := (-176:Int)+j.val+((r.val+128):Int)*(-36)/513; step (B1 (r.val+128)) y = B1 ((r.val+128)+1) y := by decide
private theorem B1check136 : ∀ r : Fin 8, ∀ j : Fin 71, let y := (-176:Int)+j.val+((r.val+136):Int)*(-36)/513; step (B1 (r.val+136)) y = B1 ((r.val+136)+1) y := by decide
private theorem B1check144 : ∀ r : Fin 8, ∀ j : Fin 71, let y := (-176:Int)+j.val+((r.val+144):Int)*(-36)/513; step (B1 (r.val+144)) y = B1 ((r.val+144)+1) y := by decide
private theorem B1check152 : ∀ r : Fin 8, ∀ j : Fin 71, let y := (-176:Int)+j.val+((r.val+152):Int)*(-36)/513; step (B1 (r.val+152)) y = B1 ((r.val+152)+1) y := by decide
private theorem B1check160 : ∀ r : Fin 8, ∀ j : Fin 71, let y := (-176:Int)+j.val+((r.val+160):Int)*(-36)/513; step (B1 (r.val+160)) y = B1 ((r.val+160)+1) y := by decide
private theorem B1check168 : ∀ r : Fin 8, ∀ j : Fin 71, let y := (-176:Int)+j.val+((r.val+168):Int)*(-36)/513; step (B1 (r.val+168)) y = B1 ((r.val+168)+1) y := by decide
private theorem B1check176 : ∀ r : Fin 8, ∀ j : Fin 71, let y := (-176:Int)+j.val+((r.val+176):Int)*(-36)/513; step (B1 (r.val+176)) y = B1 ((r.val+176)+1) y := by decide
private theorem B1check184 : ∀ r : Fin 8, ∀ j : Fin 71, let y := (-176:Int)+j.val+((r.val+184):Int)*(-36)/513; step (B1 (r.val+184)) y = B1 ((r.val+184)+1) y := by decide
private theorem B1check192 : ∀ r : Fin 8, ∀ j : Fin 71, let y := (-176:Int)+j.val+((r.val+192):Int)*(-36)/513; step (B1 (r.val+192)) y = B1 ((r.val+192)+1) y := by decide
private theorem B1check200 : ∀ r : Fin 8, ∀ j : Fin 71, let y := (-176:Int)+j.val+((r.val+200):Int)*(-36)/513; step (B1 (r.val+200)) y = B1 ((r.val+200)+1) y := by decide
private theorem B1check208 : ∀ r : Fin 8, ∀ j : Fin 71, let y := (-176:Int)+j.val+((r.val+208):Int)*(-36)/513; step (B1 (r.val+208)) y = B1 ((r.val+208)+1) y := by decide
private theorem B1check216 : ∀ r : Fin 8, ∀ j : Fin 71, let y := (-176:Int)+j.val+((r.val+216):Int)*(-36)/513; step (B1 (r.val+216)) y = B1 ((r.val+216)+1) y := by decide
private theorem B1check224 : ∀ r : Fin 8, ∀ j : Fin 71, let y := (-176:Int)+j.val+((r.val+224):Int)*(-36)/513; step (B1 (r.val+224)) y = B1 ((r.val+224)+1) y := by decide
private theorem B1check232 : ∀ r : Fin 8, ∀ j : Fin 71, let y := (-176:Int)+j.val+((r.val+232):Int)*(-36)/513; step (B1 (r.val+232)) y = B1 ((r.val+232)+1) y := by decide
private theorem B1check240 : ∀ r : Fin 8, ∀ j : Fin 71, let y := (-176:Int)+j.val+((r.val+240):Int)*(-36)/513; step (B1 (r.val+240)) y = B1 ((r.val+240)+1) y := by decide
private theorem B1check248 : ∀ r : Fin 8, ∀ j : Fin 71, let y := (-176:Int)+j.val+((r.val+248):Int)*(-36)/513; step (B1 (r.val+248)) y = B1 ((r.val+248)+1) y := by decide
private theorem B1check256 : ∀ r : Fin 8, ∀ j : Fin 71, let y := (-176:Int)+j.val+((r.val+256):Int)*(-36)/513; step (B1 (r.val+256)) y = B1 ((r.val+256)+1) y := by decide
private theorem B1check264 : ∀ r : Fin 8, ∀ j : Fin 71, let y := (-176:Int)+j.val+((r.val+264):Int)*(-36)/513; step (B1 (r.val+264)) y = B1 ((r.val+264)+1) y := by decide
private theorem B1check272 : ∀ r : Fin 8, ∀ j : Fin 71, let y := (-176:Int)+j.val+((r.val+272):Int)*(-36)/513; step (B1 (r.val+272)) y = B1 ((r.val+272)+1) y := by decide
private theorem B1check280 : ∀ r : Fin 8, ∀ j : Fin 71, let y := (-176:Int)+j.val+((r.val+280):Int)*(-36)/513; step (B1 (r.val+280)) y = B1 ((r.val+280)+1) y := by decide
private theorem B1check288 : ∀ r : Fin 8, ∀ j : Fin 71, let y := (-176:Int)+j.val+((r.val+288):Int)*(-36)/513; step (B1 (r.val+288)) y = B1 ((r.val+288)+1) y := by decide
private theorem B1check296 : ∀ r : Fin 8, ∀ j : Fin 71, let y := (-176:Int)+j.val+((r.val+296):Int)*(-36)/513; step (B1 (r.val+296)) y = B1 ((r.val+296)+1) y := by decide
private theorem B1check304 : ∀ r : Fin 8, ∀ j : Fin 71, let y := (-176:Int)+j.val+((r.val+304):Int)*(-36)/513; step (B1 (r.val+304)) y = B1 ((r.val+304)+1) y := by decide
private theorem B1check312 : ∀ r : Fin 8, ∀ j : Fin 71, let y := (-176:Int)+j.val+((r.val+312):Int)*(-36)/513; step (B1 (r.val+312)) y = B1 ((r.val+312)+1) y := by decide
private theorem B1check320 : ∀ r : Fin 8, ∀ j : Fin 71, let y := (-176:Int)+j.val+((r.val+320):Int)*(-36)/513; step (B1 (r.val+320)) y = B1 ((r.val+320)+1) y := by decide
private theorem B1check328 : ∀ r : Fin 8, ∀ j : Fin 71, let y := (-176:Int)+j.val+((r.val+328):Int)*(-36)/513; step (B1 (r.val+328)) y = B1 ((r.val+328)+1) y := by decide
private theorem B1check336 : ∀ r : Fin 8, ∀ j : Fin 71, let y := (-176:Int)+j.val+((r.val+336):Int)*(-36)/513; step (B1 (r.val+336)) y = B1 ((r.val+336)+1) y := by decide
private theorem B1check344 : ∀ r : Fin 8, ∀ j : Fin 71, let y := (-176:Int)+j.val+((r.val+344):Int)*(-36)/513; step (B1 (r.val+344)) y = B1 ((r.val+344)+1) y := by decide
private theorem B1check352 : ∀ r : Fin 8, ∀ j : Fin 71, let y := (-176:Int)+j.val+((r.val+352):Int)*(-36)/513; step (B1 (r.val+352)) y = B1 ((r.val+352)+1) y := by decide
private theorem B1check360 : ∀ r : Fin 8, ∀ j : Fin 71, let y := (-176:Int)+j.val+((r.val+360):Int)*(-36)/513; step (B1 (r.val+360)) y = B1 ((r.val+360)+1) y := by decide
private theorem B1check368 : ∀ r : Fin 8, ∀ j : Fin 71, let y := (-176:Int)+j.val+((r.val+368):Int)*(-36)/513; step (B1 (r.val+368)) y = B1 ((r.val+368)+1) y := by decide
private theorem B1check376 : ∀ r : Fin 8, ∀ j : Fin 71, let y := (-176:Int)+j.val+((r.val+376):Int)*(-36)/513; step (B1 (r.val+376)) y = B1 ((r.val+376)+1) y := by decide
private theorem B1check384 : ∀ r : Fin 8, ∀ j : Fin 71, let y := (-176:Int)+j.val+((r.val+384):Int)*(-36)/513; step (B1 (r.val+384)) y = B1 ((r.val+384)+1) y := by decide
private theorem B1check392 : ∀ r : Fin 8, ∀ j : Fin 71, let y := (-176:Int)+j.val+((r.val+392):Int)*(-36)/513; step (B1 (r.val+392)) y = B1 ((r.val+392)+1) y := by decide
private theorem B1check400 : ∀ r : Fin 8, ∀ j : Fin 71, let y := (-176:Int)+j.val+((r.val+400):Int)*(-36)/513; step (B1 (r.val+400)) y = B1 ((r.val+400)+1) y := by decide
private theorem B1check408 : ∀ r : Fin 8, ∀ j : Fin 71, let y := (-176:Int)+j.val+((r.val+408):Int)*(-36)/513; step (B1 (r.val+408)) y = B1 ((r.val+408)+1) y := by decide
private theorem B1check416 : ∀ r : Fin 8, ∀ j : Fin 71, let y := (-176:Int)+j.val+((r.val+416):Int)*(-36)/513; step (B1 (r.val+416)) y = B1 ((r.val+416)+1) y := by decide
private theorem B1check424 : ∀ r : Fin 8, ∀ j : Fin 71, let y := (-176:Int)+j.val+((r.val+424):Int)*(-36)/513; step (B1 (r.val+424)) y = B1 ((r.val+424)+1) y := by decide
private theorem B1check432 : ∀ r : Fin 8, ∀ j : Fin 71, let y := (-176:Int)+j.val+((r.val+432):Int)*(-36)/513; step (B1 (r.val+432)) y = B1 ((r.val+432)+1) y := by decide
private theorem B1check440 : ∀ r : Fin 8, ∀ j : Fin 71, let y := (-176:Int)+j.val+((r.val+440):Int)*(-36)/513; step (B1 (r.val+440)) y = B1 ((r.val+440)+1) y := by decide
private theorem B1check448 : ∀ r : Fin 8, ∀ j : Fin 71, let y := (-176:Int)+j.val+((r.val+448):Int)*(-36)/513; step (B1 (r.val+448)) y = B1 ((r.val+448)+1) y := by decide
private theorem B1check456 : ∀ r : Fin 8, ∀ j : Fin 71, let y := (-176:Int)+j.val+((r.val+456):Int)*(-36)/513; step (B1 (r.val+456)) y = B1 ((r.val+456)+1) y := by decide
private theorem B1check464 : ∀ r : Fin 8, ∀ j : Fin 71, let y := (-176:Int)+j.val+((r.val+464):Int)*(-36)/513; step (B1 (r.val+464)) y = B1 ((r.val+464)+1) y := by decide
private theorem B1check472 : ∀ r : Fin 8, ∀ j : Fin 71, let y := (-176:Int)+j.val+((r.val+472):Int)*(-36)/513; step (B1 (r.val+472)) y = B1 ((r.val+472)+1) y := by decide
private theorem B1check480 : ∀ r : Fin 8, ∀ j : Fin 71, let y := (-176:Int)+j.val+((r.val+480):Int)*(-36)/513; step (B1 (r.val+480)) y = B1 ((r.val+480)+1) y := by decide
private theorem B1check488 : ∀ r : Fin 8, ∀ j : Fin 71, let y := (-176:Int)+j.val+((r.val+488):Int)*(-36)/513; step (B1 (r.val+488)) y = B1 ((r.val+488)+1) y := by decide
private theorem B1check496 : ∀ r : Fin 8, ∀ j : Fin 71, let y := (-176:Int)+j.val+((r.val+496):Int)*(-36)/513; step (B1 (r.val+496)) y = B1 ((r.val+496)+1) y := by decide
private theorem B1check504 : ∀ r : Fin 8, ∀ j : Fin 71, let y := (-176:Int)+j.val+((r.val+504):Int)*(-36)/513; step (B1 (r.val+504)) y = B1 ((r.val+504)+1) y := by decide
private theorem B1check512 : ∀ r : Fin 1, ∀ j : Fin 71, let y := (-176:Int)+j.val+((r.val+512):Int)*(-36)/513; step (B1 (r.val+512)) y = B1 ((r.val+512)+1) y := by decide
theorem B1step : ∀ t x, step (B1 t) x = B1 (t+1) x := by
  apply propagate _ 513 (-36) (by decide) B1ret
  intro t ht x
  let z := x - (t:Int)*(-36)/513
  by_cases hl : z < (-174)-2
  · have h (j : Int) (hj : x-1≤j ∧ j≤x+1) : B1 t j = Bm1 t j := by
      simp only [B1,ite_true,ite_false,show j-(t:Int)*(-36)/513<(-174) by dsimp [z] at hl; omega]
    rw [show step (B1 t) x = step (Bm1 t) x by unfold step; rw [h _ (by omega),h _ (by omega),h _ (by omega)], Bm1step]
    simp only [B1,ite_true,ite_false,show x-(↑(t+1):Int)*(-36)/513<(-174) by dsimp [z] at hl; omega]
  by_cases hr : (-108)+2 < z
  · have h (j : Int) (hj : x-1≤j ∧ j≤x+1) : B1 t j = Bm2 t j := by
      have hh : (-108)<j-(t:Int)*(-36)/513 := by dsimp [z] at hr; omega
      simp only [B1,ite_true,ite_false,hh,show ¬ j-(t:Int)*(-36)/513<(-174) by omega]
    rw [show step (B1 t) x = step (Bm2 t) x by unfold step; rw [h _ (by omega),h _ (by omega),h _ (by omega)], Bm2step]
    have hh : (-108)<x-(↑(t+1):Int)*(-36)/513 := by dsimp [z] at hr; omega
    simp only [B1,ite_true,ite_false,hh,show ¬ x-(↑(t+1):Int)*(-36)/513<(-174) by omega]
  let k : Fin 71 := ⟨(z-(-176)).toNat, by omega⟩
  have tab : ∀ r : Fin 513, ∀ j : Fin 71, let y := (-176:Int)+j.val+(r.val:Int)*(-36)/513; step (B1 r.val) y = B1 (r.val+1) y := by
    intro r j
    by_cases h : r.val < 8
    ·   have h0 := B1check0 ⟨r.val-0, by omega⟩ j
        simpa only [show r.val-0+0=r.val by omega, show ((r.val-0:Nat):Int)+0=(r.val:Int) by omega] using h0
    by_cases h : r.val < 16
    ·   have h0 := B1check8 ⟨r.val-8, by omega⟩ j
        simpa only [show r.val-8+8=r.val by omega, show ((r.val-8:Nat):Int)+8=(r.val:Int) by omega] using h0
    by_cases h : r.val < 24
    ·   have h0 := B1check16 ⟨r.val-16, by omega⟩ j
        simpa only [show r.val-16+16=r.val by omega, show ((r.val-16:Nat):Int)+16=(r.val:Int) by omega] using h0
    by_cases h : r.val < 32
    ·   have h0 := B1check24 ⟨r.val-24, by omega⟩ j
        simpa only [show r.val-24+24=r.val by omega, show ((r.val-24:Nat):Int)+24=(r.val:Int) by omega] using h0
    by_cases h : r.val < 40
    ·   have h0 := B1check32 ⟨r.val-32, by omega⟩ j
        simpa only [show r.val-32+32=r.val by omega, show ((r.val-32:Nat):Int)+32=(r.val:Int) by omega] using h0
    by_cases h : r.val < 48
    ·   have h0 := B1check40 ⟨r.val-40, by omega⟩ j
        simpa only [show r.val-40+40=r.val by omega, show ((r.val-40:Nat):Int)+40=(r.val:Int) by omega] using h0
    by_cases h : r.val < 56
    ·   have h0 := B1check48 ⟨r.val-48, by omega⟩ j
        simpa only [show r.val-48+48=r.val by omega, show ((r.val-48:Nat):Int)+48=(r.val:Int) by omega] using h0
    by_cases h : r.val < 64
    ·   have h0 := B1check56 ⟨r.val-56, by omega⟩ j
        simpa only [show r.val-56+56=r.val by omega, show ((r.val-56:Nat):Int)+56=(r.val:Int) by omega] using h0
    by_cases h : r.val < 72
    ·   have h0 := B1check64 ⟨r.val-64, by omega⟩ j
        simpa only [show r.val-64+64=r.val by omega, show ((r.val-64:Nat):Int)+64=(r.val:Int) by omega] using h0
    by_cases h : r.val < 80
    ·   have h0 := B1check72 ⟨r.val-72, by omega⟩ j
        simpa only [show r.val-72+72=r.val by omega, show ((r.val-72:Nat):Int)+72=(r.val:Int) by omega] using h0
    by_cases h : r.val < 88
    ·   have h0 := B1check80 ⟨r.val-80, by omega⟩ j
        simpa only [show r.val-80+80=r.val by omega, show ((r.val-80:Nat):Int)+80=(r.val:Int) by omega] using h0
    by_cases h : r.val < 96
    ·   have h0 := B1check88 ⟨r.val-88, by omega⟩ j
        simpa only [show r.val-88+88=r.val by omega, show ((r.val-88:Nat):Int)+88=(r.val:Int) by omega] using h0
    by_cases h : r.val < 104
    ·   have h0 := B1check96 ⟨r.val-96, by omega⟩ j
        simpa only [show r.val-96+96=r.val by omega, show ((r.val-96:Nat):Int)+96=(r.val:Int) by omega] using h0
    by_cases h : r.val < 112
    ·   have h0 := B1check104 ⟨r.val-104, by omega⟩ j
        simpa only [show r.val-104+104=r.val by omega, show ((r.val-104:Nat):Int)+104=(r.val:Int) by omega] using h0
    by_cases h : r.val < 120
    ·   have h0 := B1check112 ⟨r.val-112, by omega⟩ j
        simpa only [show r.val-112+112=r.val by omega, show ((r.val-112:Nat):Int)+112=(r.val:Int) by omega] using h0
    by_cases h : r.val < 128
    ·   have h0 := B1check120 ⟨r.val-120, by omega⟩ j
        simpa only [show r.val-120+120=r.val by omega, show ((r.val-120:Nat):Int)+120=(r.val:Int) by omega] using h0
    by_cases h : r.val < 136
    ·   have h0 := B1check128 ⟨r.val-128, by omega⟩ j
        simpa only [show r.val-128+128=r.val by omega, show ((r.val-128:Nat):Int)+128=(r.val:Int) by omega] using h0
    by_cases h : r.val < 144
    ·   have h0 := B1check136 ⟨r.val-136, by omega⟩ j
        simpa only [show r.val-136+136=r.val by omega, show ((r.val-136:Nat):Int)+136=(r.val:Int) by omega] using h0
    by_cases h : r.val < 152
    ·   have h0 := B1check144 ⟨r.val-144, by omega⟩ j
        simpa only [show r.val-144+144=r.val by omega, show ((r.val-144:Nat):Int)+144=(r.val:Int) by omega] using h0
    by_cases h : r.val < 160
    ·   have h0 := B1check152 ⟨r.val-152, by omega⟩ j
        simpa only [show r.val-152+152=r.val by omega, show ((r.val-152:Nat):Int)+152=(r.val:Int) by omega] using h0
    by_cases h : r.val < 168
    ·   have h0 := B1check160 ⟨r.val-160, by omega⟩ j
        simpa only [show r.val-160+160=r.val by omega, show ((r.val-160:Nat):Int)+160=(r.val:Int) by omega] using h0
    by_cases h : r.val < 176
    ·   have h0 := B1check168 ⟨r.val-168, by omega⟩ j
        simpa only [show r.val-168+168=r.val by omega, show ((r.val-168:Nat):Int)+168=(r.val:Int) by omega] using h0
    by_cases h : r.val < 184
    ·   have h0 := B1check176 ⟨r.val-176, by omega⟩ j
        simpa only [show r.val-176+176=r.val by omega, show ((r.val-176:Nat):Int)+176=(r.val:Int) by omega] using h0
    by_cases h : r.val < 192
    ·   have h0 := B1check184 ⟨r.val-184, by omega⟩ j
        simpa only [show r.val-184+184=r.val by omega, show ((r.val-184:Nat):Int)+184=(r.val:Int) by omega] using h0
    by_cases h : r.val < 200
    ·   have h0 := B1check192 ⟨r.val-192, by omega⟩ j
        simpa only [show r.val-192+192=r.val by omega, show ((r.val-192:Nat):Int)+192=(r.val:Int) by omega] using h0
    by_cases h : r.val < 208
    ·   have h0 := B1check200 ⟨r.val-200, by omega⟩ j
        simpa only [show r.val-200+200=r.val by omega, show ((r.val-200:Nat):Int)+200=(r.val:Int) by omega] using h0
    by_cases h : r.val < 216
    ·   have h0 := B1check208 ⟨r.val-208, by omega⟩ j
        simpa only [show r.val-208+208=r.val by omega, show ((r.val-208:Nat):Int)+208=(r.val:Int) by omega] using h0
    by_cases h : r.val < 224
    ·   have h0 := B1check216 ⟨r.val-216, by omega⟩ j
        simpa only [show r.val-216+216=r.val by omega, show ((r.val-216:Nat):Int)+216=(r.val:Int) by omega] using h0
    by_cases h : r.val < 232
    ·   have h0 := B1check224 ⟨r.val-224, by omega⟩ j
        simpa only [show r.val-224+224=r.val by omega, show ((r.val-224:Nat):Int)+224=(r.val:Int) by omega] using h0
    by_cases h : r.val < 240
    ·   have h0 := B1check232 ⟨r.val-232, by omega⟩ j
        simpa only [show r.val-232+232=r.val by omega, show ((r.val-232:Nat):Int)+232=(r.val:Int) by omega] using h0
    by_cases h : r.val < 248
    ·   have h0 := B1check240 ⟨r.val-240, by omega⟩ j
        simpa only [show r.val-240+240=r.val by omega, show ((r.val-240:Nat):Int)+240=(r.val:Int) by omega] using h0
    by_cases h : r.val < 256
    ·   have h0 := B1check248 ⟨r.val-248, by omega⟩ j
        simpa only [show r.val-248+248=r.val by omega, show ((r.val-248:Nat):Int)+248=(r.val:Int) by omega] using h0
    by_cases h : r.val < 264
    ·   have h0 := B1check256 ⟨r.val-256, by omega⟩ j
        simpa only [show r.val-256+256=r.val by omega, show ((r.val-256:Nat):Int)+256=(r.val:Int) by omega] using h0
    by_cases h : r.val < 272
    ·   have h0 := B1check264 ⟨r.val-264, by omega⟩ j
        simpa only [show r.val-264+264=r.val by omega, show ((r.val-264:Nat):Int)+264=(r.val:Int) by omega] using h0
    by_cases h : r.val < 280
    ·   have h0 := B1check272 ⟨r.val-272, by omega⟩ j
        simpa only [show r.val-272+272=r.val by omega, show ((r.val-272:Nat):Int)+272=(r.val:Int) by omega] using h0
    by_cases h : r.val < 288
    ·   have h0 := B1check280 ⟨r.val-280, by omega⟩ j
        simpa only [show r.val-280+280=r.val by omega, show ((r.val-280:Nat):Int)+280=(r.val:Int) by omega] using h0
    by_cases h : r.val < 296
    ·   have h0 := B1check288 ⟨r.val-288, by omega⟩ j
        simpa only [show r.val-288+288=r.val by omega, show ((r.val-288:Nat):Int)+288=(r.val:Int) by omega] using h0
    by_cases h : r.val < 304
    ·   have h0 := B1check296 ⟨r.val-296, by omega⟩ j
        simpa only [show r.val-296+296=r.val by omega, show ((r.val-296:Nat):Int)+296=(r.val:Int) by omega] using h0
    by_cases h : r.val < 312
    ·   have h0 := B1check304 ⟨r.val-304, by omega⟩ j
        simpa only [show r.val-304+304=r.val by omega, show ((r.val-304:Nat):Int)+304=(r.val:Int) by omega] using h0
    by_cases h : r.val < 320
    ·   have h0 := B1check312 ⟨r.val-312, by omega⟩ j
        simpa only [show r.val-312+312=r.val by omega, show ((r.val-312:Nat):Int)+312=(r.val:Int) by omega] using h0
    by_cases h : r.val < 328
    ·   have h0 := B1check320 ⟨r.val-320, by omega⟩ j
        simpa only [show r.val-320+320=r.val by omega, show ((r.val-320:Nat):Int)+320=(r.val:Int) by omega] using h0
    by_cases h : r.val < 336
    ·   have h0 := B1check328 ⟨r.val-328, by omega⟩ j
        simpa only [show r.val-328+328=r.val by omega, show ((r.val-328:Nat):Int)+328=(r.val:Int) by omega] using h0
    by_cases h : r.val < 344
    ·   have h0 := B1check336 ⟨r.val-336, by omega⟩ j
        simpa only [show r.val-336+336=r.val by omega, show ((r.val-336:Nat):Int)+336=(r.val:Int) by omega] using h0
    by_cases h : r.val < 352
    ·   have h0 := B1check344 ⟨r.val-344, by omega⟩ j
        simpa only [show r.val-344+344=r.val by omega, show ((r.val-344:Nat):Int)+344=(r.val:Int) by omega] using h0
    by_cases h : r.val < 360
    ·   have h0 := B1check352 ⟨r.val-352, by omega⟩ j
        simpa only [show r.val-352+352=r.val by omega, show ((r.val-352:Nat):Int)+352=(r.val:Int) by omega] using h0
    by_cases h : r.val < 368
    ·   have h0 := B1check360 ⟨r.val-360, by omega⟩ j
        simpa only [show r.val-360+360=r.val by omega, show ((r.val-360:Nat):Int)+360=(r.val:Int) by omega] using h0
    by_cases h : r.val < 376
    ·   have h0 := B1check368 ⟨r.val-368, by omega⟩ j
        simpa only [show r.val-368+368=r.val by omega, show ((r.val-368:Nat):Int)+368=(r.val:Int) by omega] using h0
    by_cases h : r.val < 384
    ·   have h0 := B1check376 ⟨r.val-376, by omega⟩ j
        simpa only [show r.val-376+376=r.val by omega, show ((r.val-376:Nat):Int)+376=(r.val:Int) by omega] using h0
    by_cases h : r.val < 392
    ·   have h0 := B1check384 ⟨r.val-384, by omega⟩ j
        simpa only [show r.val-384+384=r.val by omega, show ((r.val-384:Nat):Int)+384=(r.val:Int) by omega] using h0
    by_cases h : r.val < 400
    ·   have h0 := B1check392 ⟨r.val-392, by omega⟩ j
        simpa only [show r.val-392+392=r.val by omega, show ((r.val-392:Nat):Int)+392=(r.val:Int) by omega] using h0
    by_cases h : r.val < 408
    ·   have h0 := B1check400 ⟨r.val-400, by omega⟩ j
        simpa only [show r.val-400+400=r.val by omega, show ((r.val-400:Nat):Int)+400=(r.val:Int) by omega] using h0
    by_cases h : r.val < 416
    ·   have h0 := B1check408 ⟨r.val-408, by omega⟩ j
        simpa only [show r.val-408+408=r.val by omega, show ((r.val-408:Nat):Int)+408=(r.val:Int) by omega] using h0
    by_cases h : r.val < 424
    ·   have h0 := B1check416 ⟨r.val-416, by omega⟩ j
        simpa only [show r.val-416+416=r.val by omega, show ((r.val-416:Nat):Int)+416=(r.val:Int) by omega] using h0
    by_cases h : r.val < 432
    ·   have h0 := B1check424 ⟨r.val-424, by omega⟩ j
        simpa only [show r.val-424+424=r.val by omega, show ((r.val-424:Nat):Int)+424=(r.val:Int) by omega] using h0
    by_cases h : r.val < 440
    ·   have h0 := B1check432 ⟨r.val-432, by omega⟩ j
        simpa only [show r.val-432+432=r.val by omega, show ((r.val-432:Nat):Int)+432=(r.val:Int) by omega] using h0
    by_cases h : r.val < 448
    ·   have h0 := B1check440 ⟨r.val-440, by omega⟩ j
        simpa only [show r.val-440+440=r.val by omega, show ((r.val-440:Nat):Int)+440=(r.val:Int) by omega] using h0
    by_cases h : r.val < 456
    ·   have h0 := B1check448 ⟨r.val-448, by omega⟩ j
        simpa only [show r.val-448+448=r.val by omega, show ((r.val-448:Nat):Int)+448=(r.val:Int) by omega] using h0
    by_cases h : r.val < 464
    ·   have h0 := B1check456 ⟨r.val-456, by omega⟩ j
        simpa only [show r.val-456+456=r.val by omega, show ((r.val-456:Nat):Int)+456=(r.val:Int) by omega] using h0
    by_cases h : r.val < 472
    ·   have h0 := B1check464 ⟨r.val-464, by omega⟩ j
        simpa only [show r.val-464+464=r.val by omega, show ((r.val-464:Nat):Int)+464=(r.val:Int) by omega] using h0
    by_cases h : r.val < 480
    ·   have h0 := B1check472 ⟨r.val-472, by omega⟩ j
        simpa only [show r.val-472+472=r.val by omega, show ((r.val-472:Nat):Int)+472=(r.val:Int) by omega] using h0
    by_cases h : r.val < 488
    ·   have h0 := B1check480 ⟨r.val-480, by omega⟩ j
        simpa only [show r.val-480+480=r.val by omega, show ((r.val-480:Nat):Int)+480=(r.val:Int) by omega] using h0
    by_cases h : r.val < 496
    ·   have h0 := B1check488 ⟨r.val-488, by omega⟩ j
        simpa only [show r.val-488+488=r.val by omega, show ((r.val-488:Nat):Int)+488=(r.val:Int) by omega] using h0
    by_cases h : r.val < 504
    ·   have h0 := B1check496 ⟨r.val-496, by omega⟩ j
        simpa only [show r.val-496+496=r.val by omega, show ((r.val-496:Nat):Int)+496=(r.val:Int) by omega] using h0
    by_cases h : r.val < 512
    ·   have h0 := B1check504 ⟨r.val-504, by omega⟩ j
        simpa only [show r.val-504+504=r.val by omega, show ((r.val-504:Nat):Int)+504=(r.val:Int) by omega] using h0
    have h0 := B1check512 ⟨r.val-512, by omega⟩ j
    simpa only [show r.val-512+512=r.val by omega, show ((r.val-512:Nat):Int)+512=(r.val:Int) by omega] using h0
  have h := tab ⟨t,ht⟩ k
  dsimp only at h
  rwa [show (-176:Int)+(k.val:Int)+(t:Int)*(-36)/513=x by dsimp [k,z]; omega] at h

end Rails
