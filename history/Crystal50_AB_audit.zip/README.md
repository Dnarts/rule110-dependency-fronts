# Crystal50 boundary audit

Run in the extracted directory with Python 3 and a C++ compiler.

    python generate.py Crystal50Tables.zip
    c++ -O3 search.cpp -o search
    ./search < cases.txt > exact.txt
    python verify.py
    python left.py Crystal50Tables.zip
    python certgen.py
    python compact.py

Each exact.txt line contains phase, initial x, width, status, number of discovered nodes and (on failure) the input bits along one failing path. maps.tsv preserves the nine sampled rows per phase. The left check uses the frame x=-t+h: h at the next time depends on h-2,h-1,h at the preceding time. For h<0 the two evolutions (flipped and background) agree by radius one. The background repeats after 50 steps and translation by -50. Thus the 50-step return of depths 0..1311 is sufficient to perpetuate the measured seam at depths 1280..1311.

The graph starts at t=2450, a=-350. At macrostep j use a=-350-j and time 2450+2j. In each transition an arbitrary bit enters from the right. Array entries contain a 16-bit window, then two 10-bit indices into the next residue's array. The four bits left of the window come from Cm. Two local steps must reproduce the Cm bit at a-2. The next buffer begins at a-1. All positions strictly left of a-2 depend only on the old medium provided their light cone stays above the left seam. The seam covers the four newly exposed cells at the left of a two-step induction with lower endpoint -t+1302. At odd times use one local step plus the seam; the target right boundary remains at least 815 cells left of the certified buffer. The finite closure check and the global induction are distinct proof obligations.

To rebuild the Lean certificate with Lean 4.35.0, unpack Crystal50Tables.zip into an empty directory, execute bash build.sh there, copy Crystal50Packed.lean there, and run

    LEAN_PATH="$PWD/.build" lean -j1 -o .build/Crystal50Packed.olean Crystal50Packed.lean

Crystal50Seam.lean formalizes initialMedium and seam for the actual infinite-line evolution. Compile it in the same way as Crystal50Packed.lean. The graph and seam modules do not declare wedge_all.
