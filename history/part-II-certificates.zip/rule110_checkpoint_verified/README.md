# Rule 110 boundary strips — verified Lean proof

For every natural time `t ≥ 300`, the dependency set of output cell 0
contains both strips below. Write `e(t) = t - floor(t / 3)`.

| Strip | Essential input sites | Width |
| --- | --- | ---: |
| Left | `-e(t) + k` for `0 ≤ k < 106` | 106 |
| Right | `t - k` for `0 ≤ k < 8` | 8 |

A site is essential when two initial configurations agree everywhere except
possibly at that site and produce different outputs at cell 0 at time `t`.
Different strip sites may use different witness configurations.

The theorem is `Rule110KernelCert.dual_boundary_strips_unconditional` in
`sharded/Rule110DualBoundary.lean`. The build prints its transitive axiom
dependencies as `[propext, Classical.choice, Quot.sound]`.

## Reproduce on Lean 4.35.0

```sh
cd sharded
lake clean
LEAN_NUM_THREADS=2 lake build
LEAN_NUM_THREADS=2 lake env leanchecker --fresh --verbose Rule110DualBoundary
```

The pinned toolchain is recorded in `sharded/lean-toolchain`.
The build needs only the Lean toolchain. Python is used to regenerate and
audit the proposed checkpoints.

## Proof structure

1. The generator proposes 1320-bit states. Per-phase Lean modules prove the
   initial equalities, 10- and 1-step transitions, and the resulting
   equalities with `ringEvolveBV`.
2. `Rule110CheckpointSoundness.lean` interprets each packed tile bit and
   background shift on the integer line. The single-defect bridge applies to
   the finite window through time 380. The periodic background bridge holds
   for all times.
3. The half-ray lemmas use the propagation bounds to extend finite tile
   recurrences to half-rays and then propagate them to all times `t ≥ 300`.
4. The coverage modules use a set bit in each verified union mask to select
   a concrete phase for each base coordinate. `strip_all` propagates that
   phase's output difference and translates the resulting one-bit witness
   to output cell 0.

The build uses 26 phase modules, six left coverage blocks of five base
times each, and one right coverage block. The generated finite checks use
`by decide`.

## Checked finite obligations

| Side | Phases | Initial values | Checkpoint transitions | Background shifts | Tile equalities | Coverage masks |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Left | 20 | 40 | 3,600 | 600 | 600 | 30 |
| Right | 6 | 12 | 1,320 | 240 | 240 | 40 |

## Logs and regeneration

- `logs/final-build.log` contains the clean build and the axiom report.
- `logs/toolchain.log` records the exact compiler version.
- `logs/theorem.log` gives the theorem type, the definition of an essential
  site, and the transitive axiom report from an import of the built module.
- `logs/kernel-replay.log` records a successful kernel replay of the final
  module and its dependencies in a fresh environment.
- `logs/python-audit.log` records a numerical cross-check of every
  checkpoint transition against a separate truth-table implementation.
- `logs/regeneration.log` records the byte-for-byte comparison of
  regenerated monolithic inputs and the sharded manifest verification.
- Earlier logs record the original elaboration limits and why the
  coverage proof was split into blocks.

The monolithic checkpoint sources at the archive root are generator
outputs. To regenerate the project from the archive root:

```sh
python3 generate_checkpoint_cert.py
python3 shard_lean_checkpoints.py
python3 audit_checkpoint_source.py
```
