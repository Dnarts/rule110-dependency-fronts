exec(open('generate.py').read().split('for phase,raw')[0].replace("inputs=open('cases.txt','w')",''))
for ps,raw in re.findall(r'\.p(\d+) => #\[([^\]]+)\]',data):
    p=int(ps);cm=[int(n,16) for n in raw.split(',')]
    b=sum(int('0000001001'[(i-H+p)%10])<<i for i in range(10))*(M//1023)
    y=b^(1<<H)
    for _ in range(2450):b,y=step(b),step(y)
    for x in range(-2430,-350):assert cut(y,H+x,1)==periodic(cm[0],x,1)
    old=cut(y,H-2450,1312)
    for n in range(50):
        t=2450+n
        for depth in range(1280,1312):
            x=-t+depth
            assert cut(y,H+x,1)==periodic(cm[n],x,1)
        b,y=step(b),step(y)
    assert cut(y,H-2500,1312)==old
    print('Verified base and 50-step return at depths 0..1311:',p)
