#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
python3 generate.py Crystal50Tables.zip
c++ -O3 search.cpp -o search
./search < cases.txt > exact.txt
python3 verify.py
python3 left.py Crystal50Tables.zip
python3 certgen.py
python3 compact.py
mkdir -p project
unzip -oq Crystal50Tables.zip -d project
cp Crystal50Seam.lean Crystal50Packed.lean project/
cd project
bash build.sh
export LEAN_PATH="$PWD/.build"
for module in Crystal50Seam Crystal50Packed; do
    lean -j1 -o ".build/$module.olean" "$module.lean"
done
