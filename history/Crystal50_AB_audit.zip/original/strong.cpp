#include <iostream>
#include <vector>
#include <unordered_set>
#include <string>
using namespace std;
int shrink(int v){return ((v>>1)|(v>>2))^(v&(v>>1)&(v>>2));}
struct Node{int s,j,par,r;};
int main(){int p,x,w,s,c[50];while(cin>>p>>x>>w>>s){for(int&i:c)cin>>i;
 vector<Node> nodes{{s,0,-1,-1}};unordered_set<int> seen{s};vector<int> stack{0};string path;bool bad=false;
 while(!stack.empty()&&!bad){int idx=stack.back();stack.pop_back();auto h=nodes[idx];int j=h.j,n=(j+1)%50;
 for(int r=0;r<2;r++){int v=shrink(shrink((c[j]&15)+(h.s<<4)+(r<<(4+w))));
 if((v&3)!=(c[j]>>4)){path+=char(48+r);for(int k=idx;nodes[k].par>=0;k=nodes[k].par)path+=char(48+nodes[k].r);bad=true;break;}
 int ns=(v>>1)&((1<<w)-1);if(seen.insert((n<<w)+ns).second){stack.push_back(nodes.size());nodes.push_back({ns,n,idx,r});}
 }}
 cout<<p<<" "<<x<<" "<<w<<" "<<(bad?"FAIL":"CLOSED")<<" "<<seen.size()<<" "<<string(path.rbegin(),path.rend())<<"\n";
}}
