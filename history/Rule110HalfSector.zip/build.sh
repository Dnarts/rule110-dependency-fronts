#!/usr/bin/env bash
set -eu
cd "$(dirname "$0")"
mkdir -p .build
export LEAN_PATH="$PWD/.build"
lean --version
for module in Rule110Complete Rule110Fin1320Bridge Rule110KernelCertificate Rule110BitVecBridge Rule110HalfRayClosure Rule110CheckpointSoundness Rule110Ether Rule110LocalWindow Base Bridge Rule110DomainWallA Rule110FrontGlue EtherWedge; do
  echo "Building $module"
  lean -j1 -o ".build/$module.olean" "$module.lean"
done
