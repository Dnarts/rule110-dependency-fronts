import CoreAudit
namespace Rails
open Rule110Complete Rule110Fin1320Bridge Rule110LocalWindow
theorem gapA (k : Nat) :
    evolve (4000+315*k) (flipZero (line Ainit)) 4 = evolve (4000+315*k) (line Ainit) 4 := by
  let t := 760+315*k
  rw [show 4000+315*k=t+3240 by dsimp [t]; omega,wedgeA2 t 4 (by omega) (by omega),Abackground]
  simp only [Am2,Am0]
  simp only [show t%7=4 by dsimp [t]; omega,show t%15=10 by dsimp [t]; omega]
  decide
theorem gapB (k : Nat) :
    evolve (4000+315*k) (flipZero (line Binit)) 4 = evolve (4000+315*k) (line Binit) 4 := by
  let t := 2234+315*k
  rw [show 4000+315*k=t+1766 by dsimp [t]; omega,wedgeB2 t 4 (by omega) (by omega),Bbackground]
  simp only [Bm2,Bm0]
  simp only [show t%7=1 by dsimp [t]; omega,show t%9=2 by dsimp [t]; omega]
  decide
#print axioms gapA
#print axioms gapB
end Rails
