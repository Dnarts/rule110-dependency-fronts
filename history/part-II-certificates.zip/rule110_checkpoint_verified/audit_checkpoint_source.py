#!/usr/bin/env python3
"""Independent Python audit of the claims generated into the Lean modules.
NOT a Lean compilation or a kernel proof.
"""
import json
from pathlib import Path
import importlib.util

ROOT = Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('g', ROOT/'generate_checkpoint_cert.py')
g=importlib.util.module_from_spec(spec);spec.loader.exec_module(g)


def bit_reverse(x, n):
    v=0
    for i in range(n):
        v|=((x>>i)&1) << (n-i-1)
    return v


def step_truth(s: int, n: int) -> int:
    """Apply the Rule 110 truth table to all cells in parallel."""
    mask = (1 << n) - 1
    columns = (((s << 1) | (s >> (n - 1))) & mask,
               s, (s >> 1) | ((s & 1) << (n - 1)))
    result = 0
    for code in range(8):
        if (110 >> code) & 1:
            match = mask
            for bit, column in zip((2, 1, 0), columns):
                match &= column if (code >> bit) & 1 else mask ^ column
            result |= match
    return result


def validate_side(side, phases, dt, depth, width):
    mask=(1<<g.RING)-1
    cov=[0]*dt
    checks={'init':0,'steps':0,'bg':0,'tile':0,'coverage':0}
    for word, ph in phases:
        b0,y0=g.init_state(word,ph)
        timesB,timesY=g.evolve_checkpoints(b0,y0,g.T0+2*dt)
        expected = sum(
            1 << ((g.CENTER + i) % g.RING)
            for i in range(g.RING)
            if word[(i + ph) % len(word)] == "1"
        )
        assert (b0, y0) == (expected, expected ^ (1 << g.CENTER))
        checks['init']+=2
        times=sorted(timesB)
        for a,b in zip(times,times[1:]):
            u=timesB[a];v=timesY[a]
            for _ in range(b-a):
                u = step_truth(u, g.RING)
                v = step_truth(v, g.RING)
            assert (u,v)==(timesB[b],timesY[b]),(side,word,ph,a,b)
            checks['steps']+=2
        for idx in range(dt):
            t=g.T0+idx
            b=timesB[t];bn=timesB[t+dt]
            y=timesY[t];yn=timesY[t+dt]
            if side=='left':
                shift=20
                shifted=((b<<shift)|(b>>(g.RING-shift)))&mask
                e=t-t//3
                assert ((yn >> (g.CENTER+e+20-depth+1))&((1<<depth)-1)) == ((y>>(g.CENTER+e-depth+1))&((1<<depth)-1))
                cov[idx] |= bit_reverse((b^y)>>(g.CENTER+e-width+1)&((1<<width)-1),width)
            else:
                shift=dt
                shifted=((b>>shift)|((b&((1<<shift)-1))<<(g.RING-shift)))&mask
                assert ((yn>>(g.CENTER-t-dt))&((1<<depth)-1))==((y>>(g.CENTER-t))&((1<<depth)-1))
                cov[idx] |= ((b^y)>>(g.CENTER-t))&((1<<width)-1)
            assert bn==shifted,(side,word,ph,t,'bg shift')
            checks['bg']+=1;checks['tile']+=1
    full=(1<<width)-1
    for i,row in enumerate(cov):assert row==full,(side,i,hex(row),hex(full));checks['coverage']+=1
    return checks


def main():
    left=[(w,p) for w in g.LEFT_WORDS for p in range(len(w))]
    right=list(g.RIGHT_SELECTED)
    checks={
        'left':validate_side('left',left,g.LEFT_DT,g.LEFT_CRYSTAL,g.LEFT_W),
        'right':validate_side('right',right,g.RIGHT_DT,g.RIGHT_W,g.RIGHT_W),
    }
    for name,counts in checks.items():print(name,counts)
    (ROOT/'checkpoint_audit.json').write_text(json.dumps(checks,indent=2)+'\n')

if __name__=='__main__':main()
