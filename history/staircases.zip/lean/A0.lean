import AMedia
namespace Rails
open Rule110Complete Rule110Fin1320Bridge Rule110LocalWindow
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option exponentiation.threshold 16384
def A0tab : Array Nat := #[
0x3e1ddf,
0x62ee3,
0x273bb2,
0x35aefb,
0x1ffb8e,
0x100ecb,
0x180bee,
0x3c0e3b,
0x60b2e,
0x270fbb,
0x2b11dc,
0x3f9976,
0x20dddf,
0x30f771,
0x389dd9,
0xcd77d,
0xefdc7,
0x2b8765,
0x3ec5f7,
0x23e71d,
0x246b2e,
0x367fbb,
0x1f40ee,
0x11e0bb,
0x1930ef,
0x3db8b8,
0x7ecec,
0x243ebe,
0x3623e3,
0x1f3232,
0x237677,
0x33df5d,
0x3a71f7,
0xf591d,
0x9fd97,
0x2d07dd,
0x3f8477,
0x20c65c,
0x30e776,
0x38b5df,
0x19fee3,
0x1d03b2,
0x1782fb,
0x3cc38e,
0x6e2cb,
0x27b3ee,
0x34fa3b,
0x1e8f2e,
0x13c9bb,
0x34dbdc,
0x3efe76,
0x3835f,
0x2c3f1,
0x23e219,
0x32331d,
0x3b3b97,
0x2faedd,
0x38fbf7,
0xc8e1d,
0x1d962e,
0x17df3b,
0x3c71ae,
0x659fb,
0x277d0f,
0x35c788,
0x1f64cc,
0x11f6ee,
0x191fbb,
0x3d90ee,
0xfb177,
0x8f9dd,
0x2c8d77,
0x3ecfdd,
0x23e877,
0x323c5d,
0x3b2677,
0xfb75c,
0x8fdf6,
0x2c871f,
0x3d8b23,
0x7cfb2,
0x2468fb,
0x367c8e,
0x1f46cb,
0x11e7ee,
0x19343b,
0x3dbe2e,
0x7e33b,
0x8675c,
0x2c75f6,
0x3e5f1f,
0x237191,
0x33d9d9,
0x3a7d7d,
0xf47c7,
0x9e465,
0x2d3677,
0x3fbf5d,
0x1c3ee,
0x21623b,
0x31f32e,
0x191bbb,
0x1d9eef,
0x17d3b8,
0x3c7aec,
0x64fbe,
0x2768e3,
0x35fcb2,
0x3e0df7,
0x230f1d,
0x338997,
0x3acddd,
0xfef77,
0x839dd,
0x2c2d77,
0x3e3fdc,
0x232076,
0x33b05f,
0x35f0e3,
0x1f18b2,
0x119cfb,
0x19d68e,
0x3d7fcb,
0x7c06e,
0x24607b,
0x36704e,
0x1f586b,
0x23f8fc,
0x320c86,
0x3b0ec7,
0xf8be5,
0x8ce37,
0x2ceb3d,
0x3ebfa7,
0x23e0f5,
0x32309f,
0x3b38d1,
0x1f59f2,
0x11fd1b,
0x19079e,
0x3d84d3,
0x7c6fb,
0x24678e,
0x3674cb,
0x1f5eee,
0x11f3bb,
0x191aee,
0x3b3f77,
0xfa1dd,
0x8f177,
0x2c99dd,
0x3edd77,
0x23f7dd,
0x321c77,
0x3b165c,
0xf9f76,
0x8d1df,
0x19f2e3,
0x3d1bb2,
0x79efb,
0x24d38e,
0x36facb,
0x1f8fee,
0x10c83b,
0x18ec2e,
0x3cbe3b,
0xdc65c,
0xf6776,
0x29f5df,
0x3d1f71,
0x2791d9,
0x34d97d,
0x3efdc7,
0x38765,
0x2c5f7,
0x23e71d,
0x246b2e,
0x367fbb,
0x1f40ee,
0x31e0bb,
0x1930ef,
0x1db8b8,
0x17ecec,
0x3c3ebe,
0x623e3,
0x273232,
0x2b7677,
0x3fdf5d,
0x2071f7,
0x30591d,
0x387d97,
0xc47dd,
0xe6477,
0x2b765c,
0x3fdf76,
0x2071df,
0x20b2e3,
0x30fbb2,
0x188efb,
0x1ccb8e,
0x16eecb,
0x3fbbee,
0xee3b,
0x20bb2e,
0x30efbb,
0x3171dc,
0x39d976,
0x2d7ddf,
0x3fc771,
0x65d9,
0x777d,
0x205dc7,
0x307765,
0x385df7,
0x2c771d,
0x3cbb2e,
0x6efbb,
0x7b8ee,
0x4ecbb,
0x26beef,
0x37e3b8,
0x1c32ec,
0x363bbe,
0x1f2ee3,
0x11bbb2,
0x33ddf7,
0x3a771d,
0xf5d97,
0x9f7dd,
0x2d1c77,
0x3f965d,
0x20df77,
0x30f1dc,
0x389976,
0xcdddf,
0x1deee3,
0x173bb2,
0x3daefb,
0x7fb8e,
0x240ecb,
0x360bee,
0x1f0e3b,
0x118b2e,
0x19cfbb,
0x3ad1dc,
0xff976,
0x80ddf,
0x2c0f71,
0x3e09d9,
0x230d7d,
0x338fc7,
0x3ac865,
0xfec77,
0x83e5d,
0x1846ee,
0x3c67bb,
0x674ee,
0x275ebb,
0x35f3ef,
0x1f1a38,
0x119f2c,
0x19d1be,
0x3d79e3,
0x7cd32,
0x8df77,
0x2cf1dd,
0x3e9977,
0x23dddd,
0x327777,
0x3b5ddd,
0xff777,
0x81ddc,
0x2c1776]
def A0 (t : Nat) (x : Int) := if x-(t:Int)*(-28)/273<(-372) then Am0 t x else if (-351)<x-(t:Int)*(-28)/273 then Am1 t x else cell A0tab[t%273]! (x-(t:Int)*(-28)/273-(-372))
theorem A0ret (t : Nat) (x : Int) : A0 (t+273) (x+(-28)) = A0 t x := by
  unfold A0
  simp only [show x+(-28)-((↑(t+273):Int)*(-28)/273) = x-((t:Int)*(-28)/273) by omega, show (t+273)%273=t%273 by omega, Am0ret273, Am1ret273]
private theorem A0check0 : ∀ r : Fin 8, ∀ j : Fin 26, let y := (-374:Int)+j.val+((r.val+0):Int)*(-28)/273; step (A0 (r.val+0)) y = A0 ((r.val+0)+1) y := by decide
private theorem A0check8 : ∀ r : Fin 8, ∀ j : Fin 26, let y := (-374:Int)+j.val+((r.val+8):Int)*(-28)/273; step (A0 (r.val+8)) y = A0 ((r.val+8)+1) y := by decide
private theorem A0check16 : ∀ r : Fin 8, ∀ j : Fin 26, let y := (-374:Int)+j.val+((r.val+16):Int)*(-28)/273; step (A0 (r.val+16)) y = A0 ((r.val+16)+1) y := by decide
private theorem A0check24 : ∀ r : Fin 8, ∀ j : Fin 26, let y := (-374:Int)+j.val+((r.val+24):Int)*(-28)/273; step (A0 (r.val+24)) y = A0 ((r.val+24)+1) y := by decide
private theorem A0check32 : ∀ r : Fin 8, ∀ j : Fin 26, let y := (-374:Int)+j.val+((r.val+32):Int)*(-28)/273; step (A0 (r.val+32)) y = A0 ((r.val+32)+1) y := by decide
private theorem A0check40 : ∀ r : Fin 8, ∀ j : Fin 26, let y := (-374:Int)+j.val+((r.val+40):Int)*(-28)/273; step (A0 (r.val+40)) y = A0 ((r.val+40)+1) y := by decide
private theorem A0check48 : ∀ r : Fin 8, ∀ j : Fin 26, let y := (-374:Int)+j.val+((r.val+48):Int)*(-28)/273; step (A0 (r.val+48)) y = A0 ((r.val+48)+1) y := by decide
private theorem A0check56 : ∀ r : Fin 8, ∀ j : Fin 26, let y := (-374:Int)+j.val+((r.val+56):Int)*(-28)/273; step (A0 (r.val+56)) y = A0 ((r.val+56)+1) y := by decide
private theorem A0check64 : ∀ r : Fin 8, ∀ j : Fin 26, let y := (-374:Int)+j.val+((r.val+64):Int)*(-28)/273; step (A0 (r.val+64)) y = A0 ((r.val+64)+1) y := by decide
private theorem A0check72 : ∀ r : Fin 8, ∀ j : Fin 26, let y := (-374:Int)+j.val+((r.val+72):Int)*(-28)/273; step (A0 (r.val+72)) y = A0 ((r.val+72)+1) y := by decide
private theorem A0check80 : ∀ r : Fin 8, ∀ j : Fin 26, let y := (-374:Int)+j.val+((r.val+80):Int)*(-28)/273; step (A0 (r.val+80)) y = A0 ((r.val+80)+1) y := by decide
private theorem A0check88 : ∀ r : Fin 8, ∀ j : Fin 26, let y := (-374:Int)+j.val+((r.val+88):Int)*(-28)/273; step (A0 (r.val+88)) y = A0 ((r.val+88)+1) y := by decide
private theorem A0check96 : ∀ r : Fin 8, ∀ j : Fin 26, let y := (-374:Int)+j.val+((r.val+96):Int)*(-28)/273; step (A0 (r.val+96)) y = A0 ((r.val+96)+1) y := by decide
private theorem A0check104 : ∀ r : Fin 8, ∀ j : Fin 26, let y := (-374:Int)+j.val+((r.val+104):Int)*(-28)/273; step (A0 (r.val+104)) y = A0 ((r.val+104)+1) y := by decide
private theorem A0check112 : ∀ r : Fin 8, ∀ j : Fin 26, let y := (-374:Int)+j.val+((r.val+112):Int)*(-28)/273; step (A0 (r.val+112)) y = A0 ((r.val+112)+1) y := by decide
private theorem A0check120 : ∀ r : Fin 8, ∀ j : Fin 26, let y := (-374:Int)+j.val+((r.val+120):Int)*(-28)/273; step (A0 (r.val+120)) y = A0 ((r.val+120)+1) y := by decide
private theorem A0check128 : ∀ r : Fin 8, ∀ j : Fin 26, let y := (-374:Int)+j.val+((r.val+128):Int)*(-28)/273; step (A0 (r.val+128)) y = A0 ((r.val+128)+1) y := by decide
private theorem A0check136 : ∀ r : Fin 8, ∀ j : Fin 26, let y := (-374:Int)+j.val+((r.val+136):Int)*(-28)/273; step (A0 (r.val+136)) y = A0 ((r.val+136)+1) y := by decide
private theorem A0check144 : ∀ r : Fin 8, ∀ j : Fin 26, let y := (-374:Int)+j.val+((r.val+144):Int)*(-28)/273; step (A0 (r.val+144)) y = A0 ((r.val+144)+1) y := by decide
private theorem A0check152 : ∀ r : Fin 8, ∀ j : Fin 26, let y := (-374:Int)+j.val+((r.val+152):Int)*(-28)/273; step (A0 (r.val+152)) y = A0 ((r.val+152)+1) y := by decide
private theorem A0check160 : ∀ r : Fin 8, ∀ j : Fin 26, let y := (-374:Int)+j.val+((r.val+160):Int)*(-28)/273; step (A0 (r.val+160)) y = A0 ((r.val+160)+1) y := by decide
private theorem A0check168 : ∀ r : Fin 8, ∀ j : Fin 26, let y := (-374:Int)+j.val+((r.val+168):Int)*(-28)/273; step (A0 (r.val+168)) y = A0 ((r.val+168)+1) y := by decide
private theorem A0check176 : ∀ r : Fin 8, ∀ j : Fin 26, let y := (-374:Int)+j.val+((r.val+176):Int)*(-28)/273; step (A0 (r.val+176)) y = A0 ((r.val+176)+1) y := by decide
private theorem A0check184 : ∀ r : Fin 8, ∀ j : Fin 26, let y := (-374:Int)+j.val+((r.val+184):Int)*(-28)/273; step (A0 (r.val+184)) y = A0 ((r.val+184)+1) y := by decide
private theorem A0check192 : ∀ r : Fin 8, ∀ j : Fin 26, let y := (-374:Int)+j.val+((r.val+192):Int)*(-28)/273; step (A0 (r.val+192)) y = A0 ((r.val+192)+1) y := by decide
private theorem A0check200 : ∀ r : Fin 8, ∀ j : Fin 26, let y := (-374:Int)+j.val+((r.val+200):Int)*(-28)/273; step (A0 (r.val+200)) y = A0 ((r.val+200)+1) y := by decide
private theorem A0check208 : ∀ r : Fin 8, ∀ j : Fin 26, let y := (-374:Int)+j.val+((r.val+208):Int)*(-28)/273; step (A0 (r.val+208)) y = A0 ((r.val+208)+1) y := by decide
private theorem A0check216 : ∀ r : Fin 8, ∀ j : Fin 26, let y := (-374:Int)+j.val+((r.val+216):Int)*(-28)/273; step (A0 (r.val+216)) y = A0 ((r.val+216)+1) y := by decide
private theorem A0check224 : ∀ r : Fin 8, ∀ j : Fin 26, let y := (-374:Int)+j.val+((r.val+224):Int)*(-28)/273; step (A0 (r.val+224)) y = A0 ((r.val+224)+1) y := by decide
private theorem A0check232 : ∀ r : Fin 8, ∀ j : Fin 26, let y := (-374:Int)+j.val+((r.val+232):Int)*(-28)/273; step (A0 (r.val+232)) y = A0 ((r.val+232)+1) y := by decide
private theorem A0check240 : ∀ r : Fin 8, ∀ j : Fin 26, let y := (-374:Int)+j.val+((r.val+240):Int)*(-28)/273; step (A0 (r.val+240)) y = A0 ((r.val+240)+1) y := by decide
private theorem A0check248 : ∀ r : Fin 8, ∀ j : Fin 26, let y := (-374:Int)+j.val+((r.val+248):Int)*(-28)/273; step (A0 (r.val+248)) y = A0 ((r.val+248)+1) y := by decide
private theorem A0check256 : ∀ r : Fin 8, ∀ j : Fin 26, let y := (-374:Int)+j.val+((r.val+256):Int)*(-28)/273; step (A0 (r.val+256)) y = A0 ((r.val+256)+1) y := by decide
private theorem A0check264 : ∀ r : Fin 8, ∀ j : Fin 26, let y := (-374:Int)+j.val+((r.val+264):Int)*(-28)/273; step (A0 (r.val+264)) y = A0 ((r.val+264)+1) y := by decide
private theorem A0check272 : ∀ r : Fin 1, ∀ j : Fin 26, let y := (-374:Int)+j.val+((r.val+272):Int)*(-28)/273; step (A0 (r.val+272)) y = A0 ((r.val+272)+1) y := by decide
theorem A0step : ∀ t x, step (A0 t) x = A0 (t+1) x := by
  apply propagate _ 273 (-28) (by decide) A0ret
  intro t ht x
  let z := x - (t:Int)*(-28)/273
  by_cases hl : z < (-372)-2
  · have h (j : Int) (hj : x-1≤j ∧ j≤x+1) : A0 t j = Am0 t j := by
      simp only [A0,ite_true,ite_false,show j-(t:Int)*(-28)/273<(-372) by dsimp [z] at hl; omega]
    rw [show step (A0 t) x = step (Am0 t) x by unfold step; rw [h _ (by omega),h _ (by omega),h _ (by omega)], Am0step]
    simp only [A0,ite_true,ite_false,show x-(↑(t+1):Int)*(-28)/273<(-372) by dsimp [z] at hl; omega]
  by_cases hr : (-351)+2 < z
  · have h (j : Int) (hj : x-1≤j ∧ j≤x+1) : A0 t j = Am1 t j := by
      have hh : (-351)<j-(t:Int)*(-28)/273 := by dsimp [z] at hr; omega
      simp only [A0,ite_true,ite_false,hh,show ¬ j-(t:Int)*(-28)/273<(-372) by omega]
    rw [show step (A0 t) x = step (Am1 t) x by unfold step; rw [h _ (by omega),h _ (by omega),h _ (by omega)], Am1step]
    have hh : (-351)<x-(↑(t+1):Int)*(-28)/273 := by dsimp [z] at hr; omega
    simp only [A0,ite_true,ite_false,hh,show ¬ x-(↑(t+1):Int)*(-28)/273<(-372) by omega]
  let k : Fin 26 := ⟨(z-(-374)).toNat, by omega⟩
  have tab : ∀ r : Fin 273, ∀ j : Fin 26, let y := (-374:Int)+j.val+(r.val:Int)*(-28)/273; step (A0 r.val) y = A0 (r.val+1) y := by
    intro r j
    by_cases h : r.val < 8
    ·   have h0 := A0check0 ⟨r.val-0, by omega⟩ j
        simpa only [show r.val-0+0=r.val by omega, show ((r.val-0:Nat):Int)+0=(r.val:Int) by omega] using h0
    by_cases h : r.val < 16
    ·   have h0 := A0check8 ⟨r.val-8, by omega⟩ j
        simpa only [show r.val-8+8=r.val by omega, show ((r.val-8:Nat):Int)+8=(r.val:Int) by omega] using h0
    by_cases h : r.val < 24
    ·   have h0 := A0check16 ⟨r.val-16, by omega⟩ j
        simpa only [show r.val-16+16=r.val by omega, show ((r.val-16:Nat):Int)+16=(r.val:Int) by omega] using h0
    by_cases h : r.val < 32
    ·   have h0 := A0check24 ⟨r.val-24, by omega⟩ j
        simpa only [show r.val-24+24=r.val by omega, show ((r.val-24:Nat):Int)+24=(r.val:Int) by omega] using h0
    by_cases h : r.val < 40
    ·   have h0 := A0check32 ⟨r.val-32, by omega⟩ j
        simpa only [show r.val-32+32=r.val by omega, show ((r.val-32:Nat):Int)+32=(r.val:Int) by omega] using h0
    by_cases h : r.val < 48
    ·   have h0 := A0check40 ⟨r.val-40, by omega⟩ j
        simpa only [show r.val-40+40=r.val by omega, show ((r.val-40:Nat):Int)+40=(r.val:Int) by omega] using h0
    by_cases h : r.val < 56
    ·   have h0 := A0check48 ⟨r.val-48, by omega⟩ j
        simpa only [show r.val-48+48=r.val by omega, show ((r.val-48:Nat):Int)+48=(r.val:Int) by omega] using h0
    by_cases h : r.val < 64
    ·   have h0 := A0check56 ⟨r.val-56, by omega⟩ j
        simpa only [show r.val-56+56=r.val by omega, show ((r.val-56:Nat):Int)+56=(r.val:Int) by omega] using h0
    by_cases h : r.val < 72
    ·   have h0 := A0check64 ⟨r.val-64, by omega⟩ j
        simpa only [show r.val-64+64=r.val by omega, show ((r.val-64:Nat):Int)+64=(r.val:Int) by omega] using h0
    by_cases h : r.val < 80
    ·   have h0 := A0check72 ⟨r.val-72, by omega⟩ j
        simpa only [show r.val-72+72=r.val by omega, show ((r.val-72:Nat):Int)+72=(r.val:Int) by omega] using h0
    by_cases h : r.val < 88
    ·   have h0 := A0check80 ⟨r.val-80, by omega⟩ j
        simpa only [show r.val-80+80=r.val by omega, show ((r.val-80:Nat):Int)+80=(r.val:Int) by omega] using h0
    by_cases h : r.val < 96
    ·   have h0 := A0check88 ⟨r.val-88, by omega⟩ j
        simpa only [show r.val-88+88=r.val by omega, show ((r.val-88:Nat):Int)+88=(r.val:Int) by omega] using h0
    by_cases h : r.val < 104
    ·   have h0 := A0check96 ⟨r.val-96, by omega⟩ j
        simpa only [show r.val-96+96=r.val by omega, show ((r.val-96:Nat):Int)+96=(r.val:Int) by omega] using h0
    by_cases h : r.val < 112
    ·   have h0 := A0check104 ⟨r.val-104, by omega⟩ j
        simpa only [show r.val-104+104=r.val by omega, show ((r.val-104:Nat):Int)+104=(r.val:Int) by omega] using h0
    by_cases h : r.val < 120
    ·   have h0 := A0check112 ⟨r.val-112, by omega⟩ j
        simpa only [show r.val-112+112=r.val by omega, show ((r.val-112:Nat):Int)+112=(r.val:Int) by omega] using h0
    by_cases h : r.val < 128
    ·   have h0 := A0check120 ⟨r.val-120, by omega⟩ j
        simpa only [show r.val-120+120=r.val by omega, show ((r.val-120:Nat):Int)+120=(r.val:Int) by omega] using h0
    by_cases h : r.val < 136
    ·   have h0 := A0check128 ⟨r.val-128, by omega⟩ j
        simpa only [show r.val-128+128=r.val by omega, show ((r.val-128:Nat):Int)+128=(r.val:Int) by omega] using h0
    by_cases h : r.val < 144
    ·   have h0 := A0check136 ⟨r.val-136, by omega⟩ j
        simpa only [show r.val-136+136=r.val by omega, show ((r.val-136:Nat):Int)+136=(r.val:Int) by omega] using h0
    by_cases h : r.val < 152
    ·   have h0 := A0check144 ⟨r.val-144, by omega⟩ j
        simpa only [show r.val-144+144=r.val by omega, show ((r.val-144:Nat):Int)+144=(r.val:Int) by omega] using h0
    by_cases h : r.val < 160
    ·   have h0 := A0check152 ⟨r.val-152, by omega⟩ j
        simpa only [show r.val-152+152=r.val by omega, show ((r.val-152:Nat):Int)+152=(r.val:Int) by omega] using h0
    by_cases h : r.val < 168
    ·   have h0 := A0check160 ⟨r.val-160, by omega⟩ j
        simpa only [show r.val-160+160=r.val by omega, show ((r.val-160:Nat):Int)+160=(r.val:Int) by omega] using h0
    by_cases h : r.val < 176
    ·   have h0 := A0check168 ⟨r.val-168, by omega⟩ j
        simpa only [show r.val-168+168=r.val by omega, show ((r.val-168:Nat):Int)+168=(r.val:Int) by omega] using h0
    by_cases h : r.val < 184
    ·   have h0 := A0check176 ⟨r.val-176, by omega⟩ j
        simpa only [show r.val-176+176=r.val by omega, show ((r.val-176:Nat):Int)+176=(r.val:Int) by omega] using h0
    by_cases h : r.val < 192
    ·   have h0 := A0check184 ⟨r.val-184, by omega⟩ j
        simpa only [show r.val-184+184=r.val by omega, show ((r.val-184:Nat):Int)+184=(r.val:Int) by omega] using h0
    by_cases h : r.val < 200
    ·   have h0 := A0check192 ⟨r.val-192, by omega⟩ j
        simpa only [show r.val-192+192=r.val by omega, show ((r.val-192:Nat):Int)+192=(r.val:Int) by omega] using h0
    by_cases h : r.val < 208
    ·   have h0 := A0check200 ⟨r.val-200, by omega⟩ j
        simpa only [show r.val-200+200=r.val by omega, show ((r.val-200:Nat):Int)+200=(r.val:Int) by omega] using h0
    by_cases h : r.val < 216
    ·   have h0 := A0check208 ⟨r.val-208, by omega⟩ j
        simpa only [show r.val-208+208=r.val by omega, show ((r.val-208:Nat):Int)+208=(r.val:Int) by omega] using h0
    by_cases h : r.val < 224
    ·   have h0 := A0check216 ⟨r.val-216, by omega⟩ j
        simpa only [show r.val-216+216=r.val by omega, show ((r.val-216:Nat):Int)+216=(r.val:Int) by omega] using h0
    by_cases h : r.val < 232
    ·   have h0 := A0check224 ⟨r.val-224, by omega⟩ j
        simpa only [show r.val-224+224=r.val by omega, show ((r.val-224:Nat):Int)+224=(r.val:Int) by omega] using h0
    by_cases h : r.val < 240
    ·   have h0 := A0check232 ⟨r.val-232, by omega⟩ j
        simpa only [show r.val-232+232=r.val by omega, show ((r.val-232:Nat):Int)+232=(r.val:Int) by omega] using h0
    by_cases h : r.val < 248
    ·   have h0 := A0check240 ⟨r.val-240, by omega⟩ j
        simpa only [show r.val-240+240=r.val by omega, show ((r.val-240:Nat):Int)+240=(r.val:Int) by omega] using h0
    by_cases h : r.val < 256
    ·   have h0 := A0check248 ⟨r.val-248, by omega⟩ j
        simpa only [show r.val-248+248=r.val by omega, show ((r.val-248:Nat):Int)+248=(r.val:Int) by omega] using h0
    by_cases h : r.val < 264
    ·   have h0 := A0check256 ⟨r.val-256, by omega⟩ j
        simpa only [show r.val-256+256=r.val by omega, show ((r.val-256:Nat):Int)+256=(r.val:Int) by omega] using h0
    by_cases h : r.val < 272
    ·   have h0 := A0check264 ⟨r.val-264, by omega⟩ j
        simpa only [show r.val-264+264=r.val by omega, show ((r.val-264:Nat):Int)+264=(r.val:Int) by omega] using h0
    have h0 := A0check272 ⟨r.val-272, by omega⟩ j
    simpa only [show r.val-272+272=r.val by omega, show ((r.val-272:Nat):Int)+272=(r.val:Int) by omega] using h0
  have h := tab ⟨t,ht⟩ k
  dsimp only at h
  rwa [show (-374:Int)+(k.val:Int)+(t:Int)*(-28)/273=x by dsimp [k,z]; omega] at h

end Rails
