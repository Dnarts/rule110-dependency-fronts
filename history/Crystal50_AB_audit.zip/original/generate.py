inputs=open('cases.txt','w')
from collections import Counter
from pathlib import Path
from zipfile import ZipFile
import sys,re
N=12000
H=N//2
M=(1<<N)-1
def step(s):
    left=(s<<1&M)|(s>>(N-1))
    right=(s>>1)|((s&1)<<(N-1))
    return (s|right)^(left&s&right)
def cut(s,k,w):
    return (s>>k)&((1<<w)-1)
def shrink(s):
    return ((s>>1)|(s>>2))^(s&(s>>1)&(s>>2))
def periodic(row,x,w):
    return cut(row|(row<<50)|(row<<100),x%50,w)
with ZipFile(sys.argv[1]) as z:
    data=z.read('Crystal50Data.lean').decode().split('def cmRows')[1].split('def bgRows')[0]
ether='11111000100110'
ew={sum(int(ether[(i+p)%14])<<i for i in range(14)) for p in range(14)}
maps=[]
for phase,raw in re.findall(r'\.p(\d+) => #\[([^\]]+)\]',data):
    p=int(phase)
    cm=[int(n,16) for n in raw.split(',')]
    b=sum(int('0000001001'[(i-H+p)%10])<<i for i in range(10))*(M//1023)
    y=b^(1<<H)
    for _ in range(2450):
        b,y=step(b),step(y)
    initial=y
    counts=Counter()
    for n in range(201):
        if n<50:assert cut(y,H-1500,50)==cm[n]
        if n%25==0:
            line=''
            for x in range(-350,921,12):
                a=cut(y,H+x,10)
                label=('.' if a==periodic(cm[n%50],x,10) else 'B' if a==cut(b,H+x,10) else 'E' if cut(y,H+x,14) in ew else '#')
                line+=label
            counts.update(line)
            maps.append(f'{p}\t{2450+n}\t{line}')
        b,y=step(b),step(y)
    for x in range(-350,-250):
        if cut(initial,H+x-60,60)!=periodic(cm[0],x-60,60):continue
        for w in [8,12,16,20]:
            print(p,x,w,cut(initial,H+x,w),*[periodic(cm[(2*j)%50],x-j-4,4)+16*periodic(cm[(2*j+2)%50],x-j-2,2) for j in range(50)],file=inputs)
Path('maps.tsv').write_text('phase\tt\tmap\n'+'\n'.join(maps)+'\n')
