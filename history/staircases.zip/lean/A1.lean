import AMedia
namespace Rails
open Rule110Complete Rule110Fin1320Bridge Rule110LocalWindow
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option exponentiation.threshold 16384
def A1tab : Array Nat := #[
0x2,
0x3,
0x23,
0x32,
0x1b,
0x3e,
0x3]
def A1 (t : Nat) (x : Int) := if x-(t:Int)*(0)/7<(-12) then Am1 t x else if (-7)<x-(t:Int)*(0)/7 then Am2 t x else cell A1tab[t%7]! (x-(t:Int)*(0)/7-(-12))
theorem A1ret (t : Nat) (x : Int) : A1 (t+7) (x+(0)) = A1 t x := by
  unfold A1
  simp only [show x+(0)-((↑(t+7):Int)*(0)/7) = x-((t:Int)*(0)/7) by omega, show (t+7)%7=t%7 by omega, Am1ret7, Am2ret7]
private theorem A1check0 : ∀ r : Fin 7, ∀ j : Fin 10, let y := (-14:Int)+j.val+((r.val+0):Int)*(0)/7; step (A1 (r.val+0)) y = A1 ((r.val+0)+1) y := by decide
theorem A1step : ∀ t x, step (A1 t) x = A1 (t+1) x := by
  apply propagate _ 7 (0) (by decide) A1ret
  intro t ht x
  let z := x - (t:Int)*(0)/7
  by_cases hl : z < (-12)-2
  · have h (j : Int) (hj : x-1≤j ∧ j≤x+1) : A1 t j = Am1 t j := by
      simp only [A1,ite_true,ite_false,show j-(t:Int)*(0)/7<(-12) by dsimp [z] at hl; omega]
    rw [show step (A1 t) x = step (Am1 t) x by unfold step; rw [h _ (by omega),h _ (by omega),h _ (by omega)], Am1step]
    simp only [A1,ite_true,ite_false,show x-(↑(t+1):Int)*(0)/7<(-12) by dsimp [z] at hl; omega]
  by_cases hr : (-7)+2 < z
  · have h (j : Int) (hj : x-1≤j ∧ j≤x+1) : A1 t j = Am2 t j := by
      have hh : (-7)<j-(t:Int)*(0)/7 := by dsimp [z] at hr; omega
      simp only [A1,ite_true,ite_false,hh,show ¬ j-(t:Int)*(0)/7<(-12) by omega]
    rw [show step (A1 t) x = step (Am2 t) x by unfold step; rw [h _ (by omega),h _ (by omega),h _ (by omega)], Am2step]
    have hh : (-7)<x-(↑(t+1):Int)*(0)/7 := by dsimp [z] at hr; omega
    simp only [A1,ite_true,ite_false,hh,show ¬ x-(↑(t+1):Int)*(0)/7<(-12) by omega]
  let k : Fin 10 := ⟨(z-(-14)).toNat, by omega⟩
  have tab : ∀ r : Fin 7, ∀ j : Fin 10, let y := (-14:Int)+j.val+(r.val:Int)*(0)/7; step (A1 r.val) y = A1 (r.val+1) y := by
    intro r j
    have h0 := A1check0 ⟨r.val-0, by omega⟩ j
    simpa only [show r.val-0+0=r.val by omega, show ((r.val-0:Nat):Int)+0=(r.val:Int) by omega] using h0
  have h := tab ⟨t,ht⟩ k
  dsimp only at h
  rwa [show (-14:Int)+(k.val:Int)+(t:Int)*(0)/7=x by dsimp [k,z]; omega] at h

end Rails
