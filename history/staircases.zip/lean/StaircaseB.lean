import Rule110FrontGlue
import BInit
import B0
import B1
import B2
namespace Rails
open Rule110Complete Rule110LocalWindow Rule110Fin1320Bridge Rule110FrontGlue
set_option exponentiation.threshold 16384
set_option maxRecDepth 100000
set_option maxHeartbeats 0
def Bcut (t : Nat) : Int := (-300)+(t:Int)*(-14)/60
def BcutR (t : Nat) : Int := (0)+(t:Int)*(-36)/513
def Brow (t : Nat) := splice (Bcut t) (B0 t) (splice (BcutR t) (B1 t) (B2 t))
theorem Browstep (t : Nat) : step (Brow t) = Brow (t+1) := by
  unfold Brow
  rw [step_splice (Bcut t) (Bcut (t+1)) _ _ (by unfold Bcut; omega) (by
    intro x hl hr
    unfold Bcut at hl hr
    simp only [splice,BcutR,B0,B1]
    simp (disch := omega) only [if_pos,if_neg])]
  rw [step_splice (BcutR t) (BcutR (t+1)) _ _ (by unfold BcutR; omega) (by
    intro x hl hr
    unfold BcutR at hl hr
    simp only [B1,B2]
    simp (disch := omega) only [if_pos,if_neg])]
  rw [funext (B0step t),funext (B1step t),funext (B2step t)]
theorem Browbase : evolve 1766 (flipZero (line Binit)) = Brow 0 := by
  funext x
  by_cases h : -1766≤x ∧ x≤1178
  · have hv : evolve 1766 (flipZero (line Binit)) x = line (run 1766 (defect Binit)) x := by
      apply local_obs <;> omega
    rw [hv,Byy1766eq]
    exact finite_interval (fun x => line Byy1766 x = Brow 0 x) (-1766) 2945 (by decide) x (by omega) (by omega)
  · rw [outer _ _ _ (by omega),← line_run,Bbg1766eq,Bbgread]
    by_cases hl : x < -1766 <;> simp (disch := omega) only [Brow,splice,Bcut,BcutR,B0,B2,if_pos,if_neg]
theorem Browall (t : Nat) : evolve (t+1766) (flipZero (line Binit)) = Brow t := by
  induction t with
  | zero => exact Browbase
  | succ t ih => exact (congrArg step ih).trans (Browstep t)
theorem Bbackground (t : Nat) : evolve (t+1766) (line Binit) = Bm0 t := by
  induction t with
  | zero => rw [Nat.zero_add,← line_run,Bbg1766eq]; exact funext Bbgread
  | succ t ih => exact (congrArg step ih).trans (funext (Bm0step t))
theorem Bmark0 (n q : Nat) : Bm0 (882*n+3*q) (758+378*(n:Int)+2*(q:Int)) = true := by
  have h (k : Nat) : Bm0 (882*k) (758+378*(k:Int)) = true := by
    induction k with
    | zero => decide
    | succ k ih =>
      rw [show 882*(k+1)=882*k+882 by omega,show 758+378*(↑(k+1):Int)=(758+378*(k:Int))+378 by omega,Bm0ret882]; exact ih
  induction q with
  | zero => simpa using h n
  | succ q ih =>
    rw [show 882*n+3*(q+1)=(882*n+3*q)+3 by omega,show 758+378*(n:Int)+2*(↑(q+1):Int)=(758+378*(n:Int)+2*(q:Int))+2 by omega,Bm0ret3]; exact ih
theorem Bmark2 (n q : Nat) : Bm2 (882*n+3*q) (758+378*(n:Int)+2*(q:Int)) = false := by
  have h (k : Nat) : Bm2 (882*k) (758+378*(k:Int)) = false := by
    induction k with
    | zero => decide
    | succ k ih =>
      rw [show 882*(k+1)=882*k+882 by omega,show 758+378*(↑(k+1):Int)=(758+378*(k:Int))+378 by omega,Bm2ret882]; exact ih
  induction q with
  | zero => simpa using h n
  | succ q ih =>
    rw [show 882*n+3*(q+1)=(882*n+3*q)+3 by omega,show 758+378*(n:Int)+2*(↑(q+1):Int)=(758+378*(n:Int)+2*(q:Int))+2 by omega,Bm2ret3]; exact ih
theorem Blate (n q : Nat) : Rule110KernelCert.EssentialAt ((882*n+3*q)+1766) (-(758+378*(n:Int)+2*(q:Int))) := by
  apply essential (line Binit)
  rw [Bbackground,Browall,Bmark0]
  have h : Brow (882*n+3*q) (758+378*(n:Int)+2*(q:Int)) = Bm2 (882*n+3*q) (758+378*(n:Int)+2*(q:Int)) := by
    simp only [Brow,splice,Bcut,BcutR,B2]
    simp (disch := omega) only [if_pos,if_neg]
  rw [h,Bmark2]; decide
theorem staircaseB (n q : Nat) : Rule110KernelCert.EssentialAt (884+882*n+3*q) (-(380+378*(n:Int)+2*(q:Int))) := by
  by_cases h0 : n=0
  · subst n; exact Bearly0 q
  simpa only [show (882*(n-1)+3*q)+1766=884+882*n+3*q by omega,show 758+378*(↑(n-1):Int)=380+378*(n:Int) by omega] using Blate (n-1) q
#print axioms staircaseB
end Rails
