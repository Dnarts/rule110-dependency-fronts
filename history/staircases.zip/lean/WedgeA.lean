import StaircaseA
namespace Rails
open Rule110Complete Rule110LocalWindow Rule110Fin1320Bridge Rule110FrontGlue
theorem wedgeA1 (t : Nat) (x : Int) (hl : -351+(t:Int)*(-28)/273<x) (hr : x < -12) : evolve (t+3240) (flipZero (line Ainit)) x = Am1 t x := by
  rw [Arowall]
  unfold Arow splice Acut AcutR
  by_cases cut : x ≤ Acut t <;> unfold Acut at cut <;> simp only [cut,ite_true,ite_false,A0,A1,A2]
  all_goals by_cases cut2 : x ≤ AcutR t <;> unfold AcutR at cut2 <;> simp (disch := omega) only [ite_eq_left,ite_eq_right] <;> omega
theorem essentialA1 (t : Nat) (x : Int) (hl : -351+(t:Int)*(-28)/273<x) (hr : x < -12) (hd : Am0 t x ≠ Am1 t x) : Rule110KernelCert.EssentialAt (t+3240) (-x) := by
  apply essential (line Ainit)
  rwa [Abackground,wedgeA1 t x hl hr]
#print axioms essentialA1
theorem wedgeA2 (t : Nat) (x : Int) (hl : -7<x) (hr : x<2084+(t:Int)*2/3) : evolve (t+3240) (flipZero (line Ainit)) x = Am2 t x := by
  rw [Arowall]
  unfold Arow splice Acut AcutR
  by_cases cut : x ≤ Acut t <;> unfold Acut at cut <;> simp only [cut,ite_true,ite_false,A0,A1,A2]
  all_goals by_cases cut2 : x ≤ AcutR t <;> unfold AcutR at cut2 <;> simp (disch := omega) only [ite_eq_left,ite_eq_right] <;> omega
theorem essentialA2 (t : Nat) (x : Int) (hl : -7<x) (hr : x<2084+(t:Int)*2/3) (hd : Am0 t x ≠ Am2 t x) : Rule110KernelCert.EssentialAt (t+3240) (-x) := by
  apply essential (line Ainit)
  rwa [Abackground,wedgeA2 t x hl hr]
#print axioms essentialA2
end Rails
