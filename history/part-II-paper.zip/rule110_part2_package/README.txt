Rule 110 — Part II, Russian academic draft, 18 November 2026

FILES
- Rule110_Preprint_Part_II_RU.pdf: typeset, 9-page A4 manuscript.
- Rule110_Preprint_Part_II_RU.md: complete editable Markdown source.
- Rule110_Preprint_Part_II_RU_section.tex: LaTeX fragment, suitable for editorial insertion after adaptation to the English-language Part I.
- Rule110_Preprint_Part_II_RU_standalone.tex: standalone XeLaTeX source using DejaVu Serif and STIX Math.
- SHA256SUMS.txt: checksums of four deliverables.

STATUS
- Includes the user-provided Lean build report for the dual-boundary theorem; it does not claim a new local Lean replay.
- The 66-ray certificates are treated as finite computational evidence plus a conditional mathematical half-ray lemma, not a separately Lean-verified result.
- Conjecture 4.1 remains open.
- No GitHub or Zenodo changes were made.

COMPILE (XeLaTeX):
  xelatex Rule110_Preprint_Part_II_RU_standalone.tex
  xelatex Rule110_Preprint_Part_II_RU_standalone.tex
