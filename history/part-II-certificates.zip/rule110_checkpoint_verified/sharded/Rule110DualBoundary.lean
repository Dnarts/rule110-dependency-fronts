import Rule110LeftCheckpoints
import Rule110RightCheckpoints

namespace Rule110KernelCert

open Rule110Fin1320Bridge

/-- At every time from 300 on, each site in the two input boundary strips
    can affect output cell zero by a single-bit change. -/
theorem dual_boundary_strips_unconditional (t : Nat) (ht : 300 ≤ t) :
    (∀ k : Nat, k < 106 → EssentialAt t (-(e t : Int) + k)) ∧
    (∀ k : Nat, k < 8 → EssentialAt t ((t : Int) - k)) := by
  constructor
  · intro k hk
    have h := strip_all leftPos 106 30 (by decide) LeftCheckpoints.strip_base t k ht hk
    rw [show -leftPos t k = -(e t : Int) + k by unfold leftPos; omega] at h
    exact h
  · intro k hk
    have h := strip_all rightPos 8 40 (by decide) RightCheckpoints.strip_base t k ht hk
    rw [show -rightPos t k = (t : Int) - k by unfold rightPos; omega] at h
    exact h

#print axioms dual_boundary_strips_unconditional

end Rule110KernelCert
