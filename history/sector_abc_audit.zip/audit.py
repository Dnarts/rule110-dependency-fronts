import re
from pathlib import Path
import sys

root = Path(sys.argv[1])
def media(family, index):
    source = (root / (family+'Media.lean')).read_text()
    table = re.search(r'def '+family+'m'+str(index)+r'tab.*?#\[(.*?)\]', source, re.S)[1]
    rows = [int(token,16) for token in re.findall(r'0x[0-9a-fA-F]+',table)]
    period = {'A':[10,14,14], 'B':[6,54,14]}[family][index]
    return lambda t,x: rows[t%len(rows)] >> (x%period) & 1

a,b,c = [(media(f,0),media(f,2),offset) for f,offset in [('A',760),('B',2234),('B',2235)]]
with Path('abc_holes.tsv').open('w') as output:
    print('t_minus_4000_mod315','x_mod210',sep='\t',file=output)
    for r in range(315):
        for x in range(210):
            if all(bg(k+r,x)==eth(k+r,x) for bg,eth,k in (a,b,c)):
                print(r,x,sep='\t',file=output)

for profiles in [(a,b),(a,b,c)]:
    holes=[(r,x) for r in range(315) for x in range(210)
           if all(bg(offset+r,x)==eth(offset+r,x) for bg,eth,offset in profiles)]
    print('profiles',len(profiles),'holes',len(holes),'first',holes[0])

N=30240
mask=2**N-1
def step(s):
    left=(s<<1 & mask)|(s>>(N-1))
    right=(s>>1)|((s&1)<<(N-1))
    return (s|right)^(left&s&right)

def pair(word,p):
    tile=sum(int(word[(j+p-N//2)%len(word)])<<j for j in range(len(word)))
    bg=tile*(mask//(2**len(word)-1))
    return bg,bg^(1<<(N//2))

words=['0000101111','0001111001','001011','000011','0000001001','1','11111000100110']
states=[pair(w,p) for w in words for p in range(len(w))]
extra_counts = [0, 0, 0, 0]
for t in range(9001):
    if 4000 <= t < 4315:
        r=t-4000
        missing=sum(1<<x for x in range(210) if all(bg(k+r,x)==eth(k+r,x) for bg,eth,k in (a,b,c)))
        one=(states[42][0]^states[42][1])>>(N//2)
        ether=0
        for bg,damage in states[43:]:
            ether|=(bg^damage)>>(N//2)
        for j,cover in enumerate((0,one,ether,one|ether)):
            extra_counts[j]+=(missing & ~cover).bit_count()
    if t>=4000:
        low=-(7*t//30)
        high=t-t//3-106
        coverage=0
        for bg,damage in states:
            coverage|=bg^damage
        holes=(~coverage>>(N//2+low))&((1<<(high-low+1))-1)
        if holes:
            print('57 phases first miss',t,low+(holes&-holes).bit_length()-1)
            break
    states=[(step(bg),step(damage)) for bg,damage in states]
else:
    print('57 phases cover through 9000')

print('ABC rectangle misses: before, with ones, with ether, with both',extra_counts)
