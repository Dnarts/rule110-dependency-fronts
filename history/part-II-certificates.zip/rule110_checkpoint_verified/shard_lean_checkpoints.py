#!/usr/bin/env python3
"""Split large proof-carrying Lean source files into separately compiled phase modules.
Uses generated source, preserving the exact phase declarations and proofs.
"""
from pathlib import Path
import re
import hashlib
import json
from generate_strip_proofs import phase_proofs, coverage_proofs, coverage_dispatch
from generate_checkpoint_cert import LEFT_DT, RIGHT_DT, T0

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'sharded'
OUT.mkdir(exist_ok=True)

common='''import Rule110KernelCertificate

namespace Rule110KernelCert

theorem ringEvolveBV_add (a b : Nat) (u : RingBV) :
    ringEvolveBV (a + b) u = ringEvolveBV a (ringEvolveBV b u) := by
  induction a with
  | zero => simp [ringEvolveBV]
  | succ a ih => simp [Nat.succ_add, ringEvolveBV, ih]

end Rule110KernelCert
'''
(OUT/'Rule110CheckpointCommon.lean').write_text(common)
options = """set_option exponentiation.threshold 2048
set_option maxRecDepth 10000
set_option maxHeartbeats 4000000

"""
files=['Rule110CheckpointCommon.lean']
coverage_modules = []
for side in ('Left','Right'):
    full=(ROOT/f'Rule110{side}Checkpoints.lean').read_text()
    ns=f'Rule110KernelCert.{side}Checkpoints'
    phases=list(re.finditer(r'^namespace Phase(\d+)\n(.*?)^end Phase\1\n',full,re.M|re.S))
    assert len(phases)==(20 if side=='Left' else 6),len(phases)
    for ph in phases:
        i=int(ph.group(1))
        fname=f'Rule110{side}Phase{i:02d}.lean'
        body = (f'import Rule110CheckpointCommon\nimport Rule110CheckpointSoundness\n\n{options}'
                f'namespace {ns}\n\nopen Rule110Fin1320Bridge\n\nnamespace Phase{i}\n'
                f'{ph.group(2)}{phase_proofs(side)}end Phase{i}\n\nend {ns}\n')
        (OUT/fname).write_text(body)
        files.append(fname)
    base_cov=full[phases[-1].end():].split(f'end {ns}')[0]
    imports='\n'.join(f'import Rule110{side}Phase{i:02d}' for i in range(len(phases)))
    period = LEFT_DT if side == 'Left' else RIGHT_DT
    block = 5 if side == 'Left' else period
    blocks = []
    for offset in range(0, period, block):
        times = range(T0 + offset, T0 + min(period, offset + block))
        rows = [line for line in base_cov.splitlines()
                if any(line.startswith(f'theorem base_cov_{t} :') for t in times)]
        assert len(rows) == len(times)
        module = f'Rule110{side}Coverage{offset:02d}'
        content = (f'{imports}\n\n{options}namespace {ns}\n\n'
                   + '\n'.join(rows) + '\n\n'
                   + coverage_proofs(side, len(phases), times) + f'end {ns}\n')
        (OUT/f'{module}.lean').write_text(content)
        files.append(f'{module}.lean')
        blocks.append(module)
        coverage_modules.append(module)
    imports = '\n'.join(f'import {module}' for module in blocks)
    aggregator = (f'{imports}\n\n{options}namespace {ns}\n\n'
                  f'{coverage_dispatch(side)}end {ns}\n')
    (OUT/f'Rule110{side}Checkpoints.lean').write_text(aggregator)
    files.append(f'Rule110{side}Checkpoints.lean')

manifest=[]
for x in files:
    data=(OUT/x).read_bytes()
    manifest.append({'name':x,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
(OUT/'sharded_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
(OUT/'lakefile.toml').write_text('''name = "rule110_checkpoint_sharded"
version = "0.1.0"
defaultTargets = ["Rule110DualBoundary"]

[[lean_lib]]
name = "Rule110Complete"
[[lean_lib]]
name = "Rule110Fin1320Bridge"
[[lean_lib]]
name = "Rule110KernelCertificate"
[[lean_lib]]
name = "Rule110BitVecBridge"
[[lean_lib]]
name = "Rule110HalfRayClosure"

[[lean_lib]]
name = "Rule110CheckpointCommon"
[[lean_lib]]
name = "Rule110CheckpointSoundness"
'''+''.join(f'\n[[lean_lib]]\nname = "Rule110{side}Phase{i:02d}"\n' for side,num in [('Left',20),('Right',6)] for i in range(num))+'''
[[lean_lib]]
name = "Rule110LeftCheckpoints"

[[lean_lib]]
name = "Rule110RightCheckpoints"

[[lean_lib]]
name = "Rule110DualBoundary"
'''+''.join(f'\n[[lean_lib]]\nname = "{module}"\n' for module in coverage_modules))
(OUT/'lean-toolchain').write_text('leanprover/lean4:v4.35.0\n')
print(f'Sharded {len(files)} Lean files into {OUT} ({sum(x["bytes"] for x in manifest):,} bytes)')
