import CoreGap

namespace Rails
open Rule110Complete Rule110Fin1320Bridge Rule110LocalWindow

set_option exponentiation.threshold 8192
set_option maxRecDepth 30000
set_option maxHeartbeats 8000000

def Cinit : V := input 6 48 3

private theorem bg23 : evolve 2 (line Cinit) = evolve 3 (line Binit) := by
  exact (line_run 2 Cinit).symm.trans
    ((congrArg line (show run 2 Cinit = run 3 Binit by decide)).trans (line_run 3 Binit))

private theorem defect23 :
    evolve 2 (flipZero (line Cinit)) = evolve 3 (flipZero (line Binit)) := by
  funext x
  by_cases h : -3 ≤ x ∧ x ≤ 3
  · exact finite_interval (fun j => evolve 2 (flipZero (line Cinit)) j =
        evolve 3 (flipZero (line Binit)) j) (-3) 7 (by decide) x (by omega) (by omega)
  · rw [outer _ 2 x (by omega), outer _ 3 x (by omega), bg23]

private theorem transport23 (u v : Config) (h : evolve 2 u = evolve 3 v)
    (t : Nat) (ht : 2 ≤ t) : evolve t u = evolve (t+1) v := by
  calc
    evolve t u = evolve ((t-2)+2) u := by rw [show t-2+2=t by omega]
    _ = evolve (t-2) (evolve 2 u) := evolve_add _ _ _
    _ = evolve (t-2) (evolve 3 v) := congrArg (evolve (t-2)) h
    _ = evolve ((t-2)+3) v := (evolve_add _ _ _).symm
    _ = evolve (t+1) v := by rw [show t-2+3=t+1 by omega]

theorem C_shift_B (t : Nat) (ht : 2 ≤ t) :
    evolve t (line Cinit) = evolve (t+1) (line Binit) ∧
    evolve t (flipZero (line Cinit)) = evolve (t+1) (flipZero (line Binit)) :=
  ⟨transport23 _ _ bg23 t ht, transport23 _ _ defect23 t ht⟩

theorem Crowall (t : Nat) : evolve (t+1765) (flipZero (line Cinit)) = Brow t := by
  rw [(C_shift_B _ (by omega)).2, show (t+1765)+1=t+1766 by omega, Browall]

theorem wedgeC2 (t : Nat) (x : Int)
    (hl : -108+(t:Int)*(-36)/513<x) (hr : x<1154+(t:Int)*2/3) :
    evolve (t+1765) (flipZero (line Cinit)) x = Bm2 t x := by
  rw [(C_shift_B _ (by omega)).2, show (t+1765)+1=t+1766 by omega]
  exact wedgeB2 t x hl hr

theorem essential_minus4_gap (k : Nat) :
    Rule110KernelCert.EssentialAt (4000+315*k) (-4) := by
  let t := 2235+315*k
  apply essential (line Cinit) _ 4
  rw [(C_shift_B _ (by omega)).1, (C_shift_B _ (by omega)).2,
    show 4000+315*k+1=t+1766 by dsimp [t]; omega,
    wedgeB2 t 4 (by omega) (by omega), Bbackground]
  simp only [Bm0,Bm2]
  simp only [show t%9=3 by dsimp [t]; omega, show t%7=2 by dsimp [t]; omega]
  decide

#print axioms C_shift_B
#print axioms Crowall
#print axioms wedgeC2
#print axioms essential_minus4_gap
end Rails
