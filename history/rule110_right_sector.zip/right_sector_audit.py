words={'0000101111':[3,5,6,9],'0001111001':[0,2,4,5,9],'001011':[0,5],'000011':[3,4]}
N=12000
m=(1<<N)-1
def step(s):
 l=(s<<1&m)|(s>>(N-1));r=(s>>1)|((s&1)<<(N-1))
 return (s|r)^(l&s&r)
rows=[0]*631
for w,ps in words.items():
 for p in ps:
  b=sum(int(w[(i-N//2+p)%len(w)])<<i for i in range(N));y=b^(1<<(N//2))
  for t in range(4631):
   if t>=4000:rows[t-4000]|=b^y
   b,y=step(b),step(y)
def holes(t,x,w):
 return ((1<<w)-1)^((rows[t-4000]>>(N//2+x))&((1<<w)-1))
for t0,x in [(4000,0),(4315,0),(4000,210),(4000,-210)]:
 n=0;first=None
 for t in range(t0,t0+315):
  h=holes(t,x,210);n+=h.bit_count()
  if h and first is None:first=(t,x+(h&-h).bit_length()-1)
 print(t0,x,n,first)
for t in range(4000,4631):
 x=-7*t//30;h=holes(t,x,t-t//3-106-x+1)
 if h:
  print('sector',t,x+(h&-h).bit_length()-1);break
